"""CPU-only block index/diff for saved readbacks; never executes a GPU."""
import argparse,hashlib,json,struct
from pathlib import Path
from portable_input_extension import CONTRACTS as INPUT_EXTENSION_CONTRACTS

SCHEMA='readback-block-index-v1'
CASE_WORDS=786432
CASE_SHAPES=(CASE_WORDS,1048576,1310720,1507328,1769472,1769856,2032000,2048912)
BLOCK_WORDS=1024


def digest(raw):return hashlib.sha256(raw).hexdigest()


def checked_hash(value):
    if not isinstance(value,str) or len(value)!=64 or any(c not in '0123456789abcdef' for c in value):raise ValueError('Expected lowercase SHA256')
    return value


def scan(path,expected_sha256,*,case_words=CASE_WORDS,include_case_hashes=False):
    if type(case_words) is not int or case_words not in CASE_SHAPES:raise ValueError('Unsupported readback case shape')
    checked_hash(expected_sha256);h=hashlib.sha256();case=hashlib.sha256();size=0;blocks=[];cases=[];case_position=0;case_bytes=case_words*4
    with Path(path).open('rb') as stream:
        while True:
            raw=stream.read(BLOCK_WORDS*4)
            if not raw:break
            h.update(raw);size+=len(raw);blocks.append(digest(raw))
            if include_case_hashes:
                start=0
                while start<len(raw):
                    take=min(len(raw)-start,case_bytes-case_position);case.update(raw[start:start+take]);start+=take;case_position+=take
                    if case_position==case_bytes:cases.append(case.hexdigest());case=hashlib.sha256();case_position=0
    if not size or size%(case_words*4) or h.hexdigest()!=expected_sha256:raise ValueError('Readback size or recorded SHA mismatch')
    result=dict(schema=SCHEMA,bytes=size,sha256=h.hexdigest(),case_words=case_words,block_words=BLOCK_WORDS,cases=size//(case_words*4),blocks=blocks)
    if include_case_hashes:result['case_sha256']=cases
    return result


def validate(index):
    if index['schema']!=SCHEMA or type(index['case_words']) is not int or index['case_words'] not in CASE_SHAPES or index['block_words']!=BLOCK_WORDS or type(index['cases']) is not int or index['cases']<=0 or index['bytes']!=index['cases']*index['case_words']*4 or len(index['blocks'])!=(index['bytes']+BLOCK_WORDS*4-1)//(BLOCK_WORDS*4):raise ValueError('Invalid fixed readback block index')
    checked_hash(index['sha256'])
    for value in index['blocks']:checked_hash(value)


# Failure-only product Lock On wire; successful/admission diagnostics are not
# interpreted as packet failures. Values describe a saved receipt, not a cause.
_PACKET_FAILURE_BASE=786416
_PACKET_FAILURE_FIELDS=('magic','site','row','packet','hit','hits','depth','epoch',
    'lock_snapshot','shot_count','when_low','when_high','queue_tail','queue_cursor','detail','status')
_PACKET_FAILURE_SITES={9001,9002,9003,9004,9005,9006,9010,9011,9012}


def _packet_failure(status,raw):
    words=struct.unpack('<16I',raw)
    if status!=64 or words[0]!=0x57504144 or words[1] not in _PACKET_FAILURE_SITES or words[15]!=status:
        return None
    return dict(zip(_PACKET_FAILURE_FIELDS,words,strict=True))


def compare(path,expected_sha256,index,*,sample_blocks=8):
    validate(index)
    if type(sample_blocks) is not int or not 0<=sample_blocks<=8:raise ValueError('At most eight sampled diagnostic blocks')
    actual=scan(path,expected_sha256,case_words=index['case_words'])
    if actual['bytes']!=index['bytes']:raise ValueError('Readback case count mismatch')
    changed=[i for i,(a,b) in enumerate(zip(actual['blocks'],index['blocks'],strict=True)) if a!=b]
    rows=[]
    # Recheck all bytes while extracting bounded samples; never trust a second
    # pass after the file changed between scan and sampling.
    h=hashlib.sha256()
    # Gather only status + diagnostic bytes during this same hash-checked pass.
    # This also handles case boundaries that are not aligned to 1024-word blocks.
    diagnostic=[] if index['case_words']!=2048912 else [(bytearray(),bytearray()) for _ in range(index['cases'])]
    case_bytes=index['case_words']*4
    with Path(path).open('rb') as stream:
        selected=set(changed[:sample_blocks])
        for i,want in enumerate(actual['blocks']):
            raw=stream.read(BLOCK_WORDS*4);h.update(raw)
            if digest(raw)!=want:raise ValueError('Readback changed while sampling')
            if diagnostic:
                first=i*BLOCK_WORDS*4;last=first+len(raw)
                for case in range(first//case_bytes,(last-1)//case_bytes+1):
                    base=case*case_bytes
                    for buffer,start,size in ((diagnostic[case][0],base,4),(diagnostic[case][1],base+_PACKET_FAILURE_BASE*4,64)):
                        lo=max(first,start);hi=min(last,start+size)
                        if lo<hi:buffer.extend(raw[lo-first:hi-first])
            if i in selected:rows.append(dict(block=i,case_index=i*BLOCK_WORDS//index['case_words'],case_word_offset=i*BLOCK_WORDS%index['case_words'],words=list(struct.unpack('<'+str(len(raw)//4)+'I',raw))))
        if stream.read(1) or h.hexdigest()!=actual['sha256']:raise ValueError('Readback changed while sampling')
    result=dict(schema='readback-block-diff-v1',reference_sha256=index['sha256'],actual_sha256=actual['sha256'],bytes=actual['bytes'],blocks=len(actual['blocks']),changed_blocks=changed,samples=rows,all_blocks_equal=not changed,gpu_calls=0,calculation_verified=False)
    if diagnostic:
        failures=[]
        for case,(status_raw,diagnostic_raw) in enumerate(diagnostic):
            if len(status_raw)!=4 or len(diagnostic_raw)!=64:raise ValueError('Incomplete saved diagnostic bytes')
            status=struct.unpack('<I',status_raw)[0]
            if status:failures.append(dict(case_index=case,status=status,packet_failure=_packet_failure(status,diagnostic_raw)))
        result['failure_diagnostics']=failures
        result['failure_diagnostic_scope']='Hash-checked saved values only; no source identity, root cause, or calculation certification'
    return result


def capture_fingerprints(folder,comparison_sha256,case_words):
    raw=(Path(folder)/'comparison.json').read_bytes()
    if digest(raw)!=checked_hash(comparison_sha256):raise ValueError('Comparison anchor SHA mismatch')
    report=json.loads(raw);entries=report['entries']
    if report.get('calculation_verified') is not True or report.get('mismatches')!=[] or type(report.get('input_count')) is not int or not isinstance(entries,list) or report['input_count']!=len(entries):raise ValueError('Expected a successful complete comparison')
    names=set()
    for row in entries:
        name=row['name']
        if not isinstance(name,str) or not name or name in names:raise ValueError('Invalid or duplicate case name')
        names.add(name)
        for key in ('input_sha256','native_sha256','output_sha256'):checked_hash(row[key])
    index=scan(Path(folder)/'readback.bin',report['output_sha256'],case_words=case_words,include_case_hashes=True)
    if index['cases']!=len(entries):raise ValueError('Comparison/readback case count mismatch')
    if [row['output_sha256'] for row in entries]!=index['case_sha256']:raise ValueError('Comparison case fingerprint differs from actual readback')
    return report,index


def retain(reference,reference_comparison_sha256,candidate,candidate_comparison_sha256,*,case_words=CASE_WORDS,reference_case_words=None,input_extension=None):
    """Rehash both complete files; compare retained cases by anchored name.

    This checks preserved bytes/input/native fingerprints, never recomputes a
    numerical oracle or converts a report's success flag into a GPU proof.
    """
    reference_words=case_words if reference_case_words is None else reference_case_words
    if reference_words not in CASE_SHAPES or reference_words>case_words:raise ValueError('Invalid retained prefix shape')
    old,old_index=capture_fingerprints(reference,reference_comparison_sha256,reference_words)
    new,new_index=capture_fingerprints(candidate,candidate_comparison_sha256,case_words)
    previous={r['name']:r for r in old['entries']};current={r['name']:r for r in new['entries']}
    equivalent={};extension_receipt=None
    if input_extension is not None:
        from portable_input_extension import verify_extension
        equivalent,extension_receipt=verify_extension(reference,old,candidate,new,input_extension)
    prefixes={}
    if reference_words!=case_words:
        whole=hashlib.sha256()
        with (Path(candidate)/'readback.bin').open('rb') as stream:
            for row in new['entries']:
                raw=stream.read(case_words*4);whole.update(raw)
                if len(raw)!=case_words*4 or digest(raw)!=row['output_sha256']:raise ValueError('Candidate changed during prefix comparison')
                prefixes[row['name']]=(digest(raw[:reference_words*4]),not any(raw[reference_words*4:]))
            if stream.read(1) or whole.hexdigest()!=new_index['sha256']:raise ValueError('Candidate changed during prefix comparison')
    missing=sorted(previous.keys()-current.keys());added=sorted(current.keys()-previous.keys());changed=[]
    for name,row in previous.items():
        if name not in current:continue
        fields=[key for key in ('input_sha256','native_sha256') if row[key]!=current[name][key]]
        if equivalent.get(name) and 'input_sha256' in fields:fields.remove('input_sha256')
        if reference_words==case_words:
            if row['output_sha256']!=current[name]['output_sha256']:fields.append('output_sha256')
        else:
            prefix,zero=prefixes[name]
            if prefix!=row['output_sha256']:fields.append('output_prefix_sha256')
            if not zero:fields.append('nonzero_appended_tail')
        if fields:changed.append(dict(name=name,fields=fields))
    result=dict(schema='readback-case-retention-v1',reference_comparison_sha256=reference_comparison_sha256,candidate_comparison_sha256=candidate_comparison_sha256,reference_readback_sha256=old_index['sha256'],candidate_readback_sha256=new_index['sha256'],case_words=case_words,reference_cases=len(previous),candidate_cases=len(current),retained_cases=len(previous)-len(missing)-len(changed),retained_output_bytes=(len(previous)-len(missing)-len(changed))*reference_words*4,missing=missing,added=added,changed=changed,all_reference_cases_retained=not missing and not changed,gpu_calls=0,calculation_verified=False)
    if reference_words!=case_words:result.update(schema='readback-case-prefix-retention-v1',reference_case_words=reference_words,appended_tail_required_zero=True)
    if extension_receipt is not None:result['verified_input_extension']=extension_receipt
    return result


def write(path,value):
    with Path(path).open('x',encoding='utf-8') as stream:json.dump(value,stream,separators=(',',':'));stream.write('\n')


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    for name in ('index','compare'):
        a=sub.add_parser(name);a.add_argument('--readback',type=Path,required=True);a.add_argument('--sha256',required=True);a.add_argument('--out',type=Path,required=True)
        if name=='compare':a.add_argument('--index',type=Path,required=True);a.add_argument('--index-sha256',required=True)
        else:a.add_argument('--case-words',type=int,choices=CASE_SHAPES,default=CASE_WORDS)
    a=sub.add_parser('retain');a.add_argument('--reference-capture',type=Path,required=True);a.add_argument('--reference-comparison-sha256',required=True);a.add_argument('--candidate-capture',type=Path,required=True);a.add_argument('--candidate-comparison-sha256',required=True);a.add_argument('--case-words',type=int,choices=CASE_SHAPES,default=CASE_WORDS);a.add_argument('--reference-case-words',type=int,choices=CASE_SHAPES);a.add_argument('--input-extension',choices=INPUT_EXTENSION_CONTRACTS);a.add_argument('--out',type=Path,required=True)
    a=p.parse_args(argv)
    if a.command=='index':result=scan(a.readback,a.sha256,case_words=a.case_words)
    elif a.command=='retain':result=retain(a.reference_capture,a.reference_comparison_sha256,a.candidate_capture,a.candidate_comparison_sha256,case_words=a.case_words,reference_case_words=a.reference_case_words,input_extension=a.input_extension)
    else:
        raw=a.index.read_bytes()
        if digest(raw)!=checked_hash(a.index_sha256):raise ValueError('Reference index SHA mismatch')
        result=compare(a.readback,a.sha256,json.loads(raw))
    write(a.out,result)
    print(json.dumps(dict(saved=str(a.out),sha256=digest(a.out.read_bytes()),gpu_calls=0,changed_blocks=len(result.get('changed_blocks',[])),all_blocks_equal=result.get('all_blocks_equal'),all_reference_cases_retained=result.get('all_reference_cases_retained'))))
    if a.command=='retain' and not result['all_reference_cases_retained']:raise SystemExit(2)


if __name__=='__main__':main()
