"""Source-bound dependency frontier, never a GPU support certificate.

Reuses the public model-gap audit and exact composed source/arena auditors.
It imports no native battle, compiler or GPU backend.
"""
import ast
import hashlib
import json
from pathlib import Path


def verify(root, overrides=None):
    from portable_model_gap_audit import verify as model_audit
    from portable_original_identity_inventory import inspect as inspect_original_identities
    from portable_arena_specs import audit_live_sources, audit_profile
    root = Path(root)
    overrides = overrides or {}
    model = model_audit(root, overrides)
    arena = {**audit_live_sources(root), **audit_profile('combined-v1')}
    assert arena['address_plan_verified'] and arena['runtime_connected']
    base = 'research/upstream/nikke-calc-master/calculator/'
    paths = [base + name for name in ('timeline.py', 'aim.py', 'boss_pattern.py')]
    paths += ['app/battle_attack_group_runtime.py', 'gpu/attack_group_runtime.slang',
              'gpu/coordinate_area_runtime.slang', 'research/world_projectile_native.py',
              'research/world_coordinate_physical_native.py', 'research/portable_coordinate_physical_cases.py',
              'research/world_coordinate_physical_common.py']
    texts = {p: overrides.get(p, (root / p).read_text()) for p in paths}
    def function(path, name):
        rows = [n for n in ast.walk(ast.parse(texts[path]))
                if isinstance(n, ast.FunctionDef) and n.name == name]
        assert len(rows) == 1, 'Canonical consumer changed: ' + name
        return ast.unparse(rows[0])
    pellet = function(base + 'timeline.py', '_coord_pellet')
    landing = function(base + 'aim.py', 'landing')
    geometry = function(base + 'boss_pattern.py', 'landing')
    # Bind the decomposition to the actual producers, not task prose.
    for token in ('L = geom.landing(ax, ay, R, grow)',
                  'body_f = max(0.0, 1.0 - sum(L.front) - L.core_open)',
                  'pcb = L.core_open / wb if wb > 1e-12 else 0.0',
                  "round(r['damage'] * q)", "round(r['damage'] * p)",
                  'sample_landing(ax, ay, R, random, angle=needs_angle(ax, ay, tg, geom.core))'):
        assert token in pellet, 'Coordinate packet contract changed: ' + token
    for token in ('for gx, gw in zip(_GL_X, _GL_W)',
                  'rho = R * (mid + half * gx) ** (1.0 / k)',
                  '_subtract(arcs, covered)', '_union(covered, arcs)',
                  'core_open=clip(c_open)', 'reach=tuple((clip(v) for v in reach))'):
        assert token in landing, 'Coordinate integration contract changed: ' + token
    assert 'round(ax, 6)' in geometry and 'self._cache[key] = landing(' in geometry
    producer = texts['app/battle_attack_group_runtime.py']
    assert 'Shot groups require plain logical normal packets' in producer
    assert 'Shot group model requires plain body/add world' in producer
    assert 'if any(not _is_normal(ev) or ev.to is not None or ev.rule or ev.split or ev.part_damage or ev.interrupt_damage for ev in answer):' in producer
    assert 'elif any(not _is_normal(ev) or ev.to is not None or ev.rule or ev.target or ev.extra or ev.split or ev.part_damage or ev.interrupt_damage for ev in answer):' in producer
    for token in ('coordinate_packets=False', 'Coordinate shot groups require expanded normal packets', "runtime.data['physical_receipts'].append"):
        assert token in producer, 'Coordinate receipt adapter drift: '+token
    legacy_observer = texts['research/world_projectile_native.py']
    assert 'len(answer)%muzzles==0 and len({h.damage for h in answer})==1' in legacy_observer
    assert 'actorPoolCount(s)!=1' in texts['gpu/attack_group_runtime.slang']
    assert 'Coordinate physical probability/parts routing is unconnected.' in texts['gpu/attack_group_runtime.slang']
    assert 'coordinateAreaContains' in texts['gpu/coordinate_area_runtime.slang']
    common_policy = texts['research/world_coordinate_physical_common.py']
    for token in ("patch.object(boss_pattern, 'landing', common_landing)",
                  "kwargs.get('config', {}).get('rng_mode') != 'expected'",
                  'result = native(case)', "REFERENCE_KIND = 'deterministic-common-cpu'"):
        assert token in common_policy, 'Common physical reference policy changed: ' + token
    from portable_slang_generation import source_hashes
    arc_sources = source_hashes(root, 'gpu/coordinate_arc_probe.slang')
    arc_sources = {name: hashlib.sha256(overrides[name].encode()).hexdigest()
                   if name in overrides else digest for name,digest in arc_sources.items()}
    arc_golden = json.loads((root/'research/portable-coordinate-arcs-short-expected.json').read_text())
    arc_source_matches = arc_golden['source_sha256'] == arc_sources
    scalar_sources=source_hashes(root,'gpu/coordinate_arc_scalar_probe.slang')
    scalar_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest()
                    if name in overrides else digest for name,digest in scalar_sources.items()}
    scalar_path=root/'research/portable-coordinate-arc-scalar-short-expected.json'
    # Other immutable suite packages may omit this separate primitive proof.
    # Absence is explicit; it must not become support or block new development.
    scalar_matches=(json.loads(scalar_path.read_text())['source_sha256']==scalar_sources
                    if scalar_path.is_file() else None)
    from portable_coordinate_numeric_v1 import PROFILE,contract_sha256,check_schema
    check_schema(root)
    numeric_sources=source_hashes(root,'gpu/coordinate_numeric_probe.slang')
    numeric_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest()
                     if name in overrides else digest for name,digest in numeric_sources.items()}
    numeric_path=root/'research/portable-coordinate-numeric-short-expected.json'
    numeric_matches=(json.loads(numeric_path.read_text())['source_sha256']==numeric_sources
                     if numeric_path.is_file() else None)
    geometry_sources=source_hashes(root,'gpu/coordinate_geometry_probe.slang')
    geometry_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest()
                      if name in overrides else digest for name,digest in geometry_sources.items()}
    geometry_path=root/'research/portable-coordinate-geometry-short-expected.json'
    geometry_matches=(json.loads(geometry_path.read_text())['source_sha256']==geometry_sources
                      if geometry_path.is_file() else None)
    landing_sources=source_hashes(root,'gpu/coordinate_landing_probe.slang')
    landing_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest()
                     if name in overrides else digest for name,digest in landing_sources.items()}
    landing_path=root/'research/portable-coordinate-landing-short-expected.json'
    landing_matches=(json.loads(landing_path.read_text())['source_sha256']==landing_sources
                     if landing_path.is_file() else None)
    physical_sources=source_hashes(root,'gpu/world_coordinate_physical_entry.slang')
    physical_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest()
                      if name in overrides else digest for name,digest in physical_sources.items()}
    physical_path=root/'research/portable-coordinate-physical-short-expected.json'
    physical_golden=json.loads(physical_path.read_text()) if physical_path.is_file() else None
    physical_matches=physical_golden['source_sha256']==physical_sources if physical_golden else None
    physical_entry=overrides.get('gpu/world_coordinate_physical_entry.slang',
                                 (root/'gpu/world_coordinate_physical_entry.slang').read_text())
    physical_runtime=overrides.get('gpu/coordinate_physical_runtime.slang',
                                   (root/'gpu/coordinate_physical_runtime.slang').read_text())
    assert '#define WEAPON_TYPED_DAMAGE(s,who,w,coefficient,when,legacy) coordinatePhysicalSample(s,who,w,coefficient,when)' in physical_entry
    assert '#define WEAPON_BODY_AMOUNT(s,who,legacy) coordinatePhysicalDeliver(s,who,legacy)' in physical_entry
    assert 'if(commands[s.inputBase+104402]!=0' in physical_runtime
    assert 'notifyWorldTeamFraction(s,who,0,actorNumber(bank+4)' in physical_runtime
    quantity_path=root/'research/portable-coordinate-quantity-short-expected.json'
    quantity_golden=json.loads(quantity_path.read_text()) if quantity_path.is_file() else None
    quantity_matches=quantity_golden['source_sha256']==physical_sources if quantity_golden else None
    emission_path=root/'research/portable-coordinate-accum-emission-short-expected.json'
    emission_golden=json.loads(emission_path.read_text()) if emission_path.is_file() else None
    emission_matches=emission_golden['source_sha256']==physical_sources if emission_golden else None
    core_sources=source_hashes(root,'gpu/world_coordinate_core_entry.slang')
    core_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in core_sources.items()}
    core_path=root/'research/portable-coordinate-core-short-expected.json'
    core_golden=json.loads(core_path.read_text()) if core_path.is_file() else None
    core_matches=core_golden['source_sha256']==core_sources if core_golden else None
    cache_sources=source_hashes(root,'gpu/world_coordinate_cache_entry.slang')
    cache_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in cache_sources.items()}
    cache_path=root/'research/portable-coordinate-cache-short-expected.json'
    cache_golden=json.loads(cache_path.read_text()) if cache_path.is_file() else None
    cache_matches=cache_golden['source_sha256']==cache_sources if cache_golden else None
    matrix_path=root/'research/portable-coordinate-matrix-short-expected.json'
    matrix_golden=json.loads(matrix_path.read_text()) if matrix_path.is_file() else None
    matrix_matches=matrix_golden['source_sha256']==cache_sources if matrix_golden else None
    from portable_coordinate_aim_wire import LAYOUT as aim_layout,check_schema as check_aim_schema
    check_aim_schema(root)
    aim_sources=source_hashes(root,'gpu/world_coordinate_aim_entry.slang')
    aim_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in aim_sources.items()}
    aim_path=root/'research/portable-coordinate-aim-short-expected.json'
    aim_golden=json.loads(aim_path.read_text()) if aim_path.is_file() else None
    aim_matches=aim_golden['source_sha256']==aim_sources if aim_golden else None
    control_sources=source_hashes(root,'gpu/world_coordinate_control_entry.slang')
    control_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in control_sources.items()}
    control_path=root/'research/portable-coordinate-control-short-expected.json'
    control_golden=json.loads(control_path.read_text()) if control_path.is_file() else None
    control_matches=control_golden['source_sha256']==control_sources if control_golden else None
    from portable_coordinate_group_frontier import verify as group_frontier
    group_plan=group_frontier(root)
    from portable_coordinate_route_audit import verify as route_audit
    route_policy=route_audit(root,overrides)
    group_sources=source_hashes(root,'gpu/world_coordinate_group_entry.slang')
    group_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in group_sources.items()}
    group_path=root/'research/portable-coordinate-group-short-expected.json'
    group_golden=json.loads(group_path.read_text()) if group_path.is_file() else None
    group_matches=group_golden['source_sha256']==group_sources if group_golden else None
    mixed_sources=source_hashes(root,'gpu/world_coordinate_mixed_entry.slang')
    mixed_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in mixed_sources.items()}
    mixed_path=root/'research/portable-coordinate-mixed-short-expected.json'
    mixed_golden=json.loads(mixed_path.read_text()) if mixed_path.is_file() else None
    mixed_matches=mixed_golden['source_sha256']==mixed_sources if mixed_golden else None
    sample_sources=source_hashes(root,'gpu/coordinate_sample_probe.slang')
    sample_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in sample_sources.items()}
    sample_path=root/'research/portable-coordinate-sample-short-expected.json'
    sample_golden=json.loads(sample_path.read_text()) if sample_path.is_file() else None
    sample_matches=sample_golden['source_sha256']==sample_sources if sample_golden else None
    sampled_battle_sources=source_hashes(root,'gpu/world_coordinate_sampling_entry.slang')
    sampled_battle_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in sampled_battle_sources.items()}
    sampled_battle_path=root/'research/portable-coordinate-sampled-battle-short-expected.json'
    sampled_battle_golden=json.loads(sampled_battle_path.read_text()) if sampled_battle_path.is_file() else None
    sampled_battle_matches=sampled_battle_golden['source_sha256']==sampled_battle_sources if sampled_battle_golden else None
    sampled_parent_sources=source_hashes(root,'gpu/world_coordinate_sampling_parent_entry.slang')
    sampled_parent_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in sampled_parent_sources.items()}
    sampled_parent_path=root/'research/portable-coordinate-sampled-parent-short-expected.json'
    sampled_parent_golden=json.loads(sampled_parent_path.read_text()) if sampled_parent_path.is_file() else None
    sampled_parent_matches=sampled_parent_golden['source_sha256']==sampled_parent_sources if sampled_parent_golden else None
    sampled_skill_sources=source_hashes(root,'gpu/world_coordinate_sampling_skill_entry.slang')
    sampled_skill_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in sampled_skill_sources.items()}
    sampled_skill_path=root/'research/portable-coordinate-sampled-skill-short-expected.json'
    sampled_skill_golden=json.loads(sampled_skill_path.read_text()) if sampled_skill_path.is_file() else None
    sampled_skill_matches=sampled_skill_golden['source_sha256']==sampled_skill_sources if sampled_skill_golden else None
    sampled_burst_sources=source_hashes(root,'gpu/world_coordinate_sampling_burst_entry.slang')
    sampled_burst_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in sampled_burst_sources.items()}
    sampled_burst_path=root/'research/portable-coordinate-sampled-burst-short-expected.json'
    sampled_burst_golden=json.loads(sampled_burst_path.read_text()) if sampled_burst_path.is_file() else None
    sampled_burst_matches=sampled_burst_golden['source_sha256']==sampled_burst_sources if sampled_burst_golden else None
    sampled_vital_sources=source_hashes(root,'gpu/world_coordinate_sampling_vital_entry.slang')
    sampled_vital_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in sampled_vital_sources.items()}
    sampled_vital_path=root/'research/portable-coordinate-sampled-vital-short-expected.json'
    sampled_vital_golden=json.loads(sampled_vital_path.read_text()) if sampled_vital_path.is_file() else None
    sampled_vital_matches=sampled_vital_golden['source_sha256']==sampled_vital_sources if sampled_vital_golden else None
    sampled_delivery_path=root/'research/portable-coordinate-sampled-delivery-short-expected.json'
    sampled_delivery_golden=json.loads(sampled_delivery_path.read_text()) if sampled_delivery_path.is_file() else None
    sampled_delivery_matches=sampled_delivery_golden['source_sha256']==sampled_vital_sources if sampled_delivery_golden else None
    manual_sources=source_hashes(root,'gpu/world_coordinate_manual_entry.slang')
    manual_path=root/'research/portable-coordinate-manual-short-expected.json'
    manual_golden=json.loads(manual_path.read_text()) if manual_path.is_file() else None
    manual_matches=manual_golden['source_sha256']==manual_sources if manual_golden else False
    policy_sources=source_hashes(root,'gpu/world_coordinate_policy_entry.slang')
    policy_path=root/'research/portable-coordinate-policy-short-expected.json'
    policy_golden=json.loads(policy_path.read_text()) if policy_path.is_file() else None
    policy_matches=policy_golden['source_sha256']==policy_sources if policy_golden else None
    squad_sources=source_hashes(root,'gpu/world_coordinate_squad_entry.slang')
    squad_path=root/'research/portable-coordinate-squad-short-expected.json'
    squad_golden=json.loads(squad_path.read_text()) if squad_path.is_file() else None
    squad_matches=squad_golden['source_sha256']==squad_sources if squad_golden else None
    squad_mode_sources=source_hashes(root,'gpu/world_coordinate_squad_mode_entry.slang')
    squad_mode_path=root/'research/portable-coordinate-squad-mode-short-expected.json'
    squad_mode_golden=json.loads(squad_mode_path.read_text()) if squad_mode_path.is_file() else None
    squad_mode_matches=squad_mode_golden['source_sha256']==squad_mode_sources if squad_mode_golden else None
    burst_control_sources=source_hashes(root,'gpu/world_coordinate_burst_control_entry.slang') if (root/'gpu/world_coordinate_burst_control_entry.slang').is_file() else {}
    burst_control_path=root/'research/portable-coordinate-burst-control-short-expected.json'
    burst_control_golden=json.loads(burst_control_path.read_text()) if burst_control_path.is_file() else None
    burst_control_matches=burst_control_golden['source_sha256']==burst_control_sources if burst_control_golden else None
    mode_action_sources=source_hashes(root,'gpu/world_coordinate_mode_actions_entry.slang') if (root/'gpu/world_coordinate_mode_actions_entry.slang').is_file() else {}
    mode_action_path=root/'research/portable-coordinate-mode-actions-short-expected.json'
    mode_action_golden=json.loads(mode_action_path.read_text()) if mode_action_path.is_file() else None
    mode_action_matches=mode_action_golden['source_sha256']==mode_action_sources if mode_action_golden else None
    auto_reload_sources=source_hashes(root,'gpu/world_coordinate_auto_reload_entry.slang') if (root/'gpu/world_coordinate_auto_reload_entry.slang').is_file() else {}
    auto_reload_path=root/'research/portable-coordinate-auto-reload-short-expected.json'
    auto_reload_golden=json.loads(auto_reload_path.read_text()) if auto_reload_path.is_file() else None
    auto_reload_matches=auto_reload_golden['source_sha256']==auto_reload_sources if auto_reload_golden else None
    healing_sources=source_hashes(root,'gpu/world_coordinate_healing_entry.slang') if (root/'gpu/world_coordinate_healing_entry.slang').is_file() else {}
    healing_path=root/'research/portable-coordinate-healing-short-expected.json'
    healing_golden=json.loads(healing_path.read_text()) if healing_path.is_file() else None
    healing_matches=healing_golden['source_sha256']==healing_sources if healing_golden else None
    original_sources=source_hashes(root,'gpu/world_coordinate_original_entry.slang') if (root/'gpu/world_coordinate_original_entry.slang').is_file() else {}
    original_path=root/'research/portable-coordinate-original-short-expected.json'
    original_golden=json.loads(original_path.read_text()) if original_path.is_file() else None
    original_matches=original_golden['source_sha256']==original_sources if original_golden else None
    periodic_original_path=root/'research/portable-coordinate-original-periodic-short-expected.json'
    periodic_original_golden=json.loads(periodic_original_path.read_text()) if periodic_original_path.is_file() else None
    lifecycle_original_path=root/'research/portable-coordinate-original-lifecycle-short-expected.json'
    lifecycle_original_golden=json.loads(lifecycle_original_path.read_text()) if lifecycle_original_path.is_file() else None
    revival_original_path=root/'research/portable-coordinate-original-revival-short-expected.json'
    revival_original_golden=json.loads(revival_original_path.read_text()) if revival_original_path.is_file() else None
    burst_revival_sources=source_hashes(root,'gpu/world_coordinate_original_clock_entry.slang') if (root/'gpu/world_coordinate_original_clock_entry.slang').is_file() else {}
    burst_revival_path=root/'research/portable-coordinate-original-burst-revival-short-expected.json'
    burst_revival_golden=json.loads(burst_revival_path.read_text()) if burst_revival_path.is_file() else None
    resource_original_sources=source_hashes(root,'gpu/world_coordinate_original_resource_entry.slang') if (root/'gpu/world_coordinate_original_resource_entry.slang').is_file() else {}
    resource_original_path=root/'research/portable-coordinate-original-resources-short-expected.json'
    resource_original_golden=json.loads(resource_original_path.read_text()) if resource_original_path.is_file() else None
    ammo_original_sources=source_hashes(root,'gpu/world_coordinate_original_ammo_entry.slang') if (root/'gpu/world_coordinate_original_ammo_entry.slang').is_file() else {}
    ammo_original_path=root/'research/portable-coordinate-original-ammo-short-expected.json'
    ammo_original_golden=json.loads(ammo_original_path.read_text()) if ammo_original_path.is_file() else None
    stack_original_sources=source_hashes(root,'gpu/world_coordinate_original_stack_entry.slang') if (root/'gpu/world_coordinate_original_stack_entry.slang').is_file() else {}
    stack_original_path=root/'research/portable-coordinate-original-stacks-short-expected.json'
    stack_original_golden=json.loads(stack_original_path.read_text()) if stack_original_path.is_file() else None
    cleanse_original_sources=source_hashes(root,'gpu/world_coordinate_original_cleanse_entry.slang') if (root/'gpu/world_coordinate_original_cleanse_entry.slang').is_file() else {}
    cleanse_original_path=root/'research/portable-coordinate-original-cleanse-short-expected.json'
    cleanse_original_golden=json.loads(cleanse_original_path.read_text()) if cleanse_original_path.is_file() else None
    slot_original_sources=source_hashes(root,'gpu/world_coordinate_original_slot_entry.slang') if (root/'gpu/world_coordinate_original_slot_entry.slang').is_file() else {}
    slot_original_path=root/'research/portable-coordinate-original-source-short-expected.json'
    slot_original_golden=json.loads(slot_original_path.read_text()) if slot_original_path.is_file() else None
    forced_original_sources=source_hashes(root,'gpu/world_coordinate_original_reload_entry.slang') if (root/'gpu/world_coordinate_original_reload_entry.slang').is_file() else {}
    forced_original_path=root/'research/portable-coordinate-original-reload-short-expected.json'
    forced_original_golden=json.loads(forced_original_path.read_text()) if forced_original_path.is_file() else None
    ratio_sources=source_hashes(root,'gpu/packet_ratio_probe.slang')
    ratio_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in ratio_sources.items()}
    ratio_path=root/'research/portable-packet-ratio-short-expected.json'
    ratio_golden=json.loads(ratio_path.read_text()) if ratio_path.is_file() else None
    ratio_matches=ratio_golden['source_sha256']==ratio_sources if ratio_golden else None
    round_sources=source_hashes(root,'gpu/coordinate_round_probe.slang')
    round_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in round_sources.items()}
    round_path=root/'research/portable-coordinate-round-short-expected.json'
    round_matches=json.loads(round_path.read_text())['source_sha256']==round_sources if round_path.is_file() else None
    integer_sources=source_hashes(root,'gpu/packet_integer_probe.slang')
    integer_sources={name:hashlib.sha256(overrides[name].encode()).hexdigest() if name in overrides else digest for name,digest in integer_sources.items()}
    integer_path=root/'research/portable-packet-integer-short-expected.json'
    integer_matches=json.loads(integer_path.read_text())['source_sha256']==integer_sources if integer_path.is_file() else None
    assert 'bm.accumulate_damage' in function(base+'timeline.py','_land_boss')
    assert 'bm.accumulate_damage' not in function(base+'timeline.py','_land_target')
    from portable_coordinate_landing_v1 import TARGETS,CUTS,OUTPUT as LANDING_OUTPUT
    dependencies = [
        dict(id='landing-probability', classification='gpu_port_gap',
             native='Geometry.landing -> aim.landing',
             work='Shared binary64 arcs, ordered occlusion, radial quadrature and cache-key rounding',
             verified_primitives=['interval-union', 'interval-intersection', 'interval-subtraction'],
             depends_on=['numeric-policy']),
        dict(id='physical-packet-expansion', classification='gpu_port_gap',
             native='CharState._coord_pellet',
             work='Per-pellet body/front/reach packets, conditional core probability, per-target damage rounding',
             private_expected_entry='gpu/world_coordinate_physical_entry.slang',
             private_expected_packets_connected=True,
             remaining_scope='Public frontend admission and unrestricted compositions; not absence of private implementations',
             private_sampling=dict(suite='coordinate-sampled-battle',
                 source='gpu/world_coordinate_sampling_entry.slang',
                 proof_available=sampled_battle_golden is not None,
                 sealed_source_matches_current=sampled_battle_matches),
             remaining=[
                        'public-sampling-rng-admission','uncovered-mixed-scenes','complete-original-definition-coverage'],
             depends_on=['landing-probability', 'physical-native-observation']),
        dict(id='coordinate-shot-groups', classification='gpu_port_gap',
             native='battle_attack_group_runtime.Producer.wrap_fire / packet_scope',
             work='Bind actual expanded coordinate packet receipts to GPU group collection/seal',
             native_coordinate_packet_adapter_available=True,
             native_reference_cli='coordinate-group-common',
             default_plain_packet_policy_preserved=True,
             physical_gpu_group_receipts_connected=True,
             group_runtime_source='gpu/world_coordinate_group_entry.slang',
             depends_on=['physical-packet-expansion', 'physical-native-observation']),
        dict(id='physical-native-observation', classification='reference_adapter',
             native='world_projectile_native.capture_projectile_shots',
             replacement_observer='research/world_coordinate_physical_native.py',
             reference_tests='tests/test_coordinate_physical_reference.py',
             scope='Expected mode authored worlds; no GPU or group proof',
             legacy_equal_packet_observer_preserved=True,
             common_policy_observer='research/world_coordinate_physical_common.py',
             common_policy_reference_cli='coordinate-physical-common',
             common_policy_is_historical_native_equivalence=False,
             depends_on=[]),
        dict(id='physical-rng', classification='gpu_port_gap',
             native='CharState._coord_pellet -> sample_landing',
             work='Preserve random draw count/order, angle requirement, front-most and reach routing',
             private_physical_executor_implemented=True,shared_scalar_condition_rng_implemented=True,
             admission_scope='Public frontend only; private sampled skill and parent suites are separate evidence',
             private_sampled_skill=dict(suite='coordinate-sampled-skill',source='gpu/world_coordinate_sampling_skill_entry.slang',
                 proof_available=sampled_skill_golden is not None,sealed_source_matches_current=sampled_skill_matches),
             private_sampled_parent=dict(suite='coordinate-sampled-parent',source='gpu/world_coordinate_sampling_parent_entry.slang',
                 proof_available=sampled_parent_golden is not None,sealed_source_matches_current=sampled_parent_matches),
             sampled_damage_skills_admitted=False,parent_quantity_admitted=False,
             native_reference_cli='coordinate-sampled-battle-common',
             depends_on=['physical-packet-expansion', 'numeric-policy']),
        dict(id='manual-coordinate-aim', classification='gpu_port_gap',
             native='CharState._aim_point / simulate._resolve_aims',
             work='Authored coordinate waypoints and frame camera arbitration',
             common_policy_reference_cli='coordinate-aim-common',
             static_authored_aim_ir_available=True,shared_gpu_aim_hooks_implemented=True,
             sealed_shared_gpu_aim_source_matches_current=aim_matches,
             aim_query_phases=['prior-frame aim for pre-arbitration skill handlers','resolved current-frame aim for physical ticks'], depends_on=[]),
        dict(id='numeric-policy', classification='gpu_numeric_implementation_gap',
             work='Implement selected deterministic shared numeric contract; retain native host disagreement evidence',
             user_decision_required=False, implementation_required=True, depends_on=[]),
    ]
    return dict(schema=1, passed=True, scope='Source audit and dependency plan only',
                native_model_available=True, public_gpu_admitted=False,
                private_composed_arena_verified=True, private_physical_scope='legacy-composed-body-only; separate coordinate-physical expected profile',
                coordinate_physical_expected=dict(suite='coordinate-physical',
                    source_sha256=physical_sources,proof_available=physical_golden is not None,
                    sealed_source_matches_current=physical_matches,
                    requires_new_metal_proof=not physical_matches,
                    input_count=len(physical_golden['entries']) if physical_golden else None,
                    reference_kind='deterministic-common-cpu',
                    runtime_connected=True,group_owner_mask_required=0,
                    physical_packet_capture_before_notifications=True,
                    physical_delivery_after_notifications=True,
                    live_core_nodes_connected=False,manual_aim_connected=False,
                    expanded_full_charge_parent_quantity_in_physical23_proof=False,
                    rng_connected=False,all_characters_certified=False,
                    public_gpu_admitted=False),
                coordinate_packet_quantity=dict(suite='coordinate-quantity',
                    proof_available=quantity_golden is not None,sealed_source_matches_current=quantity_matches,
                    input_count=len(quantity_golden['entries']) if quantity_golden else None,
                    source_sha256=physical_sources,reference_kind='deterministic-common-cpu',
                    packet_sum='unsigned128',packet_terms=128,multiplier_max=1024,
                    exact_integer_bound_bits=80,binary64_rounding='once after exact sum and multiplication',
                    expanded_full_charge_parent_quantity_connected=True,
                    native_creation_and_landing_times_distinguished=True,
                    integer_probe=dict(suite='packet-integer',sealed_source_matches_current=integer_matches,
                                       source_sha256=integer_sources),
                    public_gpu_admitted=False),
                coordinate_target_accumulation=dict(classification='native_reference_exclusion',
                    direct_target_consumer=False,reference_suite='coordinate-accumulation-policy',
                    game_rule_verified=False,extra_gpu_collection_required_for_parity=False,
                    coordinate_accumulation_emission_connected=True),
                coordinate_accumulation_emission=dict(suite='coordinate-accum-emission',
                    proof_available=emission_golden is not None,sealed_source_matches_current=emission_matches,
                    requires_new_metal_proof=not emission_matches,
                    input_count=len(emission_golden['entries']) if emission_golden else None,
                    source_sha256=physical_sources,reference_kind='deterministic-common-cpu',
                    body_only_receipt_connected=True,shared_queue_and_lifetime_core=True,
                    excluded_coordinate_scenarios=['ADD sharing','enemy attack nodes'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_live_core=dict(suite='coordinate-core',
                    proof_available=core_golden is not None,sealed_source_matches_current=core_matches,
                    requires_new_metal_proof=not core_matches,
                    input_count=len(core_golden['entries']) if core_golden else None,
                    source_sha256=core_sources,reference_kind='deterministic-common-cpu',
                    runtime_connected=True,graph_lifetime_reused=True,
                    winner='greatest diameter; newest start then declaration on equal diameter',
                    default_auto_aim_tracks_selected_core=True,base_core_at_origin=True,
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_geometry_cache=dict(suite='coordinate-cache',
                    proof_available=cache_golden is not None,sealed_source_matches_current=cache_matches,
                    requires_new_metal_proof=not cache_matches,
                    input_count=len(cache_golden['entries']) if cache_golden else None,
                    source_sha256=cache_sources,reference_kind='deterministic-common-cpu',
                    runtime_connected=True,shared_across_shooters=True,
                    key='CPython-compatible decimal-six nearest-even; signed-zero keys canonicalized',
                    value='first exact landing result for an equal key in the same Geometry',
                    entries_no_targets=4096,entries_127_targets=231,hash_slots=8192,
                    overflow='explicit rejection; no eviction',
                    duplicate_target_labels='binding/reference boundary; not admitted',
                    round_probe=dict(suite='coordinate-round',sealed_source_matches_current=round_matches),
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_area_matrix=dict(suite='coordinate-matrix',
                    proof_available=matrix_golden is not None,sealed_source_matches_current=matrix_matches,
                    input_count=len(matrix_golden['entries']) if matrix_golden else None,
                    profile='coordinate-area-matrix-common-v1',reference_kind='deterministic-common-cpu',
                    shared_numeric_profile=PROFILE,host_transcendentals_in_input=False,
                    static_authored_rotation_lowering=True,shared_cache_executor=True,
                    native_area_distance_scoped_to_common_reference=True,
                    historical_cpu_profile_retained=True,
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_authored_aim=dict(suite='coordinate-aim',proof_available=aim_golden is not None,
                    sealed_source_matches_current=aim_matches,requires_new_metal_proof=not aim_matches,
                    source_sha256=aim_sources,input_count=len(aim_golden['entries']) if aim_golden else None,
                    reference_cli='coordinate-aim-common',reference_kind='deterministic-common-cpu',
                    shared_runtime_hooks_implemented=True,persistent_point_bank=True,
                    pre_arbitration_skill_aim_retained=True,post_arbitration_physical_aim=True,
                    state_begin=aim_layout['STATE'],state_end=aim_layout['STATE']+aim_layout['STATE_WORDS'],
                    authored_entries_per_owner=8,window_kinds=4,anchor_kinds=5,
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_control_compositions=dict(suite='coordinate-control',
                    source_sha256=control_sources,proof_available=control_golden is not None,
                    sealed_source_matches_current=control_matches,requires_new_metal_proof=not control_matches,
                    input_count=len(control_golden['entries']) if control_golden else None,
                    base_weapon_reload_time_in_control_queries=True,
                    live_reload_fraction_controls_clip_classification=True,
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_group_integration=group_plan,
                coordinate_route_policy=route_policy,
                coordinate_mixed_world=dict(suite='coordinate-mixed',source_sha256=mixed_sources,
                    proof_available=mixed_golden is not None,sealed_source_matches_current=mixed_matches,
                    requires_new_metal_proof=not mixed_matches,input_count=len(mixed_golden['entries']) if mixed_golden else None,
                    reference_cli='coordinate-mixed-common',reference_kind='deterministic-common-cpu',
                    scoped_nodes=['buff','shield','vanish','move','groggy','direct boss attack'],
                    split_damage_routing_implemented=True,split_rounding='ordered binary64 reciprocal/multiply; nearest-even integer',
                    direct_part_skill_trace_uses_native_body_slot=True,
                    source_seal_is_not_cuda_execution=True,
                    remaining_scope='This unsampled mixed-world suite; later sampled/original suites are separate private evidence',
                    remaining=['sampling-rng','summon attack payloads','debuff payloads','original-definitions'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_gpu_shot_groups=dict(suite='coordinate-group',source_sha256=group_sources,
                    proof_available=group_golden is not None,sealed_source_matches_current=group_matches,
                    requires_new_metal_proof=not group_matches,input_count=len(group_golden['entries']) if group_golden else None,
                    expanded_packet_receipts_connected=True,relocated_complete_stride=1507328,
                    compact_history_words_retained=186528,public_gpu_admitted=False,all_characters_certified=False),
                coordinate_skill_shape_contains_is_physical_landing=False,
                angular_interval_algebra=dict(suite='coordinate-arcs',
                    sealed_source_matches_current=arc_source_matches, source_sha256=arc_sources,
                    requires_new_metal_proof=not arc_source_matches,
                    operands_capacity=512, output_capacity=1024,
                    whole_geometry_capacity_certified=False, battle_connected=False),
                angular_scalar_arithmetic=dict(suite='coordinate-arc-scalar',
                    proof_available=scalar_matches is not None,
                    sealed_source_matches_current=scalar_matches,
                    source_sha256=scalar_sources, battle_connected=False,
                    operations=['positive-modulo','arc-wrap','arc-shift','compensated-measure'],
                    zero_width_arc_preserved=True, existing_runtime_sum_reused=True,
                    does_not_include=['acos','atan2','radial-quadrature']),
                deterministic_numeric_primitives=dict(suite='coordinate-numeric',
                    contract=PROFILE,contract_sha256=contract_sha256(),
                    proof_available=numeric_matches is not None,sealed_source_matches_current=numeric_matches,
                    source_sha256=numeric_sources,reference_kind='deterministic-common-cpu',
                    operations=['sincos-degrees','sincos-bounded-radians','atan2','acos','sqrt'],
                    battle_connected=False,full_numeric_policy_implemented=False,
                    native_host_disagreement_evidence_preserved=True),
                deterministic_shape_geometry=dict(suite='coordinate-geometry',
                    contract=PROFILE,proof_available=geometry_matches is not None,
                    sealed_source_matches_current=geometry_matches,source_sha256=geometry_sources,
                    authored_angles_consumed_on_gpu=True,rotation_matrix_precomputed_on_cpu=False,
                    operations=['distance','contains','circle-arcs','halfplane-arcs','grown-rotated-rectangle-arcs','radial-breaks'],
                    nonfinite_intermediate_rejected=True,denominator_underflow_rejected=True,
                    battle_connected=False,radial_integrator_connected=False,
                    whole_geometry_capacity_certified=False),
                deterministic_radial_landing=dict(suite='coordinate-landing',
                    proof_available=landing_matches is not None,sealed_source_matches_current=landing_matches,
                    source_sha256=landing_sources,reference_kind='deterministic-common-cpu',
                    unit_power_contract='coordinate-unit-power-v1',quadrature_contract='coordinate-gauss-legendre-10-v1',
                    targets_capacity=TARGETS,cuts_capacity=CUTS,output_words=LANDING_OUTPUT,
                    prepared_frame_values_on_gpu=True,all_cuts_retained=True,
                    operations=['front-probability','reach-probability','core-open','core-under'],
                    battle_connected=False,sampling_rng_connected=False,cache_key_rounding_connected=False,
                    whole_geometry_capacity_certified=False),
                deterministic_sample_points=dict(suite='coordinate-sample',
                    source_sha256=sample_sources,proof_available=sample_golden is not None,
                    sealed_source_matches_current=sample_matches,input_count=len(sample_golden['entries']) if sample_golden else None,
                    existing_integer_mt_reused=True,uniform_bits=53,mt_words_per_uniform=2,
                    no_angle_uniforms=1,angle_uniforms=2,complete_mt_state_compared=True,
                    native_reference_cli='coordinate-sampling-common',native_sampled_pellet_observation_available=True,
                    battle_connected=False,critical_sampling_connected=False,
                    remaining=['physical RNG state separate from boss target stream','per-pellet damage/critical and notification order','variable packet bank and parent quantity','shared group receipt delivery'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_sampled_battles=dict(suite='coordinate-sampled-battle',source_sha256=sampled_battle_sources,
                    proof_available=sampled_battle_golden is not None,sealed_source_matches_current=sampled_battle_matches,
                    input_count=len(sampled_battle_golden['entries']) if sampled_battle_golden else None,
                    reference_kind='deterministic-common-cpu',native_reference_cli='coordinate-sampled-battle-common',
                    physical_rng_separate_from_boss=True,per_pellet_snapshots=True,
                    ordered_auto_and_charge_notifications=True,condition_rng=['not_core','prob'],
                    reused_expected_only_scratch=True,logical_pellet_capacity=1024,target_capacity=127,
                    admitted_definition_kinds=['buff'],sampled_damage_skills_admitted=False,parent_quantity_admitted=False,
                    group_receipt_functions_reused=True,group_owner_examples_verified=False,
                    remaining=['non-buff effects including weapon changes, healing, sampled damage/queue effects','parent reference quantity integer division','group-owner sampled worlds','original definitions and public admission'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_sampled_parent=dict(suite='coordinate-sampled-parent',source_sha256=sampled_parent_sources,
                    proof_available=sampled_parent_golden is not None,sealed_source_matches_current=sampled_parent_matches,
                    input_count=len(sampled_parent_golden['entries']) if sampled_parent_golden else None,
                    reference_kind='deterministic-common-cpu',native_reference_cli='coordinate-sampled-parent-common',
                    admitted_definition_kinds=['buff','dealt_fixed_damage'],
                    parent_quantity='exact uint128 created physical packet sum / muzzle; one nearest-even binary64 rounding',
                    whole_battle_integer_damage='persistent uint128 BODY/PART credits; ordered binary64 diagnostic retained',
                    parent_children_consume_rng=False,extra_runtime_bytes=0,extra_output_words=0,
                    group_owner_examples_verified=False,
                    remaining=['ordinary damage skill RNG','weapon changes and healing in sampled battles','group-owner sampled worlds','original definitions and public admission'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_sampled_skills=dict(suite='coordinate-sampled-skill',source_sha256=sampled_skill_sources,
                    proof_available=sampled_skill_golden is not None,sealed_source_matches_current=sampled_skill_matches,
                    input_count=len(sampled_skill_golden['entries']) if sampled_skill_golden else None,
                    reference_kind='deterministic-common-cpu',native_reference_cli='coordinate-sampled-skill-common',
                    admitted_definition_kinds=['buff','ordinary damage','dealt_fixed_damage'],
                    critical_uniform_per_body_hit=1,critical_uniforms_at_zero_and_unit_rate=True,
                    target_packets_reuse_body_critical=True,cast_factors_frozen_across_children=True,
                    queue_and_named_hit_context_reused=True,depth_capacity=32,extra_runtime_bytes=0,extra_output_words=0,
                    remaining=['deferred burst skill sampling','weapon changes and healing in sampled battles','sampled group-owner and mixed effect worlds','original definitions and public admission'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_sampled_bursts=dict(suite='coordinate-sampled-burst',source_sha256=sampled_burst_sources,
                    proof_available=sampled_burst_golden is not None,sealed_source_matches_current=sampled_burst_matches,
                    input_count=len(sampled_burst_golden['entries']) if sampled_burst_golden else None,
                    reference_kind='deterministic-common-cpu',native_reference_cli='coordinate-sampled-burst-common',
                    pending_modes=['legacy-bonus','land-in-full-burst'],legacy_per_hit_critical=True,
                    legacy_generation_before_optin_and_landing=True,optin_count_latched_at_cast=True,
                    optin_stats_requeried_at_entry=True,optin_named_critical_context=True,
                    pending_entries=512,hits_per_entry=256,output_words=1769472,
                    retained_output_prefix_words=1507328,additional_output_bytes=1048576,additional_runtime_bytes=0,
                    remaining=['weapon changes and healing in sampled battles','sampled group-owner and mixed effect worlds','original definitions and public admission'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_sampled_vital=dict(suite='coordinate-sampled-vital',source_sha256=sampled_vital_sources,
                    proof_available=sampled_vital_golden is not None,sealed_source_matches_current=sampled_vital_matches,
                    input_count=len(sampled_vital_golden['entries']) if sampled_vital_golden else None,
                    reference_kind='deterministic-common-cpu',native_reference_cli='coordinate-sampled-vital-common',
                    shared_weapon_modes=True,shared_body_cover_healing=True,shared_current_hp_reduce=True,
                    live_mode_muzzles=True,first_coefficient=True,legacy_and_optin_pending=True,
                    automatic_reload_cover_repair=True,manual_cover_controls_packed=False,
                    input_words=109528,output_words=1769472,additional_runtime_bytes=0,
                    remaining=['sampled group-owner and mixed effect worlds','further weapon-mode flags and control combinations','manual cover/control composition packing','further health/storage/instant combinations','original definitions and public admission'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_sampled_delivery=dict(suite='coordinate-sampled-delivery',source_sha256=sampled_vital_sources,
                    proof_available=sampled_delivery_golden is not None,sealed_source_matches_current=sampled_delivery_matches,
                    input_count=len(sampled_delivery_golden['entries']) if sampled_delivery_golden else None,
                    reference_kind='deterministic-common-cpu',native_reference_cli='coordinate-sampled-delivery-common',
                    skill_damage_modes=True,normal_group_excludes_skill_mode=True,
                    typed_body_add_receipt_groups=True,parts_not_logical_group_members=True,
                    retired_add_child_handles=True,shared_gpu_source='coordinate-sampled-vital',
                    manual_cover_controls_packed=False,
                    remaining=['manual cover/control composition packing','further health/storage/instant combinations','mixed actor payloads and original definitions','public admission and all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_manual_actions=dict(suite='coordinate-manual',source_sha256=manual_sources,
                    proof_available=manual_golden is not None,sealed_source_matches_current=manual_matches,
                    input_count=len(manual_golden['entries']) if manual_golden else None,
                    reference_kind='deterministic-common-cpu',common_runtime_connected=True,
                    explicit_cover_hold_literals_packed=True,computed_cpu_action_schedule=False,
                    charging_visibility_separate_from_phase=True,partial_reload_cancel=True,
                    conditional_policies_connected=False,cover_all_connected=False,
                    input_words=109528,output_words=1769472,additional_runtime_bytes=0,
                    remaining=['conditional cover/reload/burst policies and cover_all','post-delay, zero-listener, knockdown and storage combinations','mixed actor payloads and original definitions','CUDA execution and public all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_cover_policies=dict(suite='coordinate-policy',source_sha256=policy_sources,
                    proof_available=policy_golden is not None,sealed_source_matches_current=policy_matches,
                    input_count=len(policy_golden['entries']) if policy_golden else None,
                    reference_kind='deterministic-common-cpu',common_runtime_connected=True,
                    own_full_burst_cover=True,reload_policies=['before_fb_end','into_fb','finish_by_fb_end','finish_by_own_buff_end'],
                    shared_anchor_and_prediction_clock=True,computed_cpu_action_schedule=False,
                    if_dry_connected=True,one_time_anchor_rollback=True,cover_all_connected=False,
                    input_words=109656,output_words=1769856,extra_runtime_bytes=0,reentry_capacity_per_owner=16,
                    remaining=['cover_all and forced burst action producers','post-delay, zero-listener, knockdown and storage combinations','mixed actors and original definitions','CUDA execution and public all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_squad_actions=dict(suite='coordinate-squad',source_sha256=squad_sources,
                    proof_available=squad_golden is not None,sealed_source_matches_current=squad_matches,
                    input_count=len(squad_golden['entries']) if squad_golden else None,
                    reference_kind='deterministic-common-cpu',common_manual_runtime_connected=True,
                    authored_actions=['focus','cover_all'],computed_cpu_action_schedule=False,
                    live_owner_excluded=True,cover_all_requests_camera=False,stable_equal_time_order=True,
                    input_words=109792,output_words=1769856,extra_runtime_bytes=0,extra_output_words=0,
                    squad_sequence_capacity=16,output_padding_owned_words=48,
                    remaining=['exact physical mode-exit tick boundary','burst delay, own-cooldown wait, pattern and prediction composition','down, healing storage and mixed actor original definitions','CUDA execution and public all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_squad_mode_state=dict(suite='coordinate-squad-mode',source_sha256=squad_mode_sources,
                    proof_available=squad_mode_golden is not None,sealed_source_matches_current=squad_mode_matches,
                    input_count=len(squad_mode_golden['entries']) if squad_mode_golden else None,
                    reference_kind='deterministic-common-cpu',character_mode_lifetime_connected=True,
                    busy_state_shared_by=['squad cover_all','pre-arbitration cover/reload policies'],
                    full_pre_pump_state_fingerprints=True,reload_callback_mode_entry_connected=True,
                    same_frame_reload_entry_wait=True,shared_revive_handler_admitted=True,
                    input_words=109792,output_words=1769856,extra_runtime_bytes=0,extra_output_words=0,
                    wire_version=2,character_flag_count=5,
                    remaining=['burst delay, own-cooldown wait, pattern and prediction composition','explicit mode-sequence, post-delay, healing storage and mixed actor originals','current CUDA execution and warm cache performance','public admission and all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_burst_controls=dict(suite='coordinate-burst-control',source_sha256=burst_control_sources,
                    proof_available=burst_control_golden is not None,sealed_source_matches_current=burst_control_matches,
                    input_count=len(burst_control_golden['entries']) if burst_control_golden else None,
                    reference_kind='deterministic-common-cpu',shared_candidate_selection_and_prediction=True,
                    gpu_owned_stage_open_and_completed_cycles=True,tick_entry_stage_snapshot=True,
                    operations=['delay','wait_own_cooldown','pattern','burst_sequence'],
                    computed_cpu_action_schedule=False,full_post_tick_state_fingerprints=True,
                    cover_down_ordering_receipts=True,input_words=109968,output_words=1769856,
                    extra_runtime_bytes=0,extra_output_words=0,output_padding_owned_words=18,
                    remaining=['explicit mode-sequence, post-delay, healing storage and mixed actor originals',
                        'current CUDA execution and warm cache performance','public admission and all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_mode_actions=dict(suite='coordinate-mode-actions',source_sha256=mode_action_sources,
                    proof_available=mode_action_golden is not None,sealed_source_matches_current=mode_action_matches,
                    input_count=len(mode_action_golden['entries']) if mode_action_golden else None,
                    reference_kind='deterministic-common-cpu',shared_manual_weapon_executor=True,
                    explicit_hold_cover_during_mode=True,base_charge_cover_cancels_post_delay=True,
                    canonical_static_base_clock_checked=True,computed_cpu_action_schedule=False,
                    input_words=109968,output_words=1769856,extra_runtime_bytes=0,extra_output_words=0,
                    remaining=['automatic reload notification and effect-expiry combinations',
                        'healing storage and mixed actor original definitions',
                        'current CUDA execution and warm cache performance','public admission and all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_automatic_reload=dict(suite='coordinate-auto-reload',source_sha256=auto_reload_sources,
                    proof_available=auto_reload_golden is not None,sealed_source_matches_current=auto_reload_matches,
                    input_count=len(auto_reload_golden['entries']) if auto_reload_golden else None,
                    reference_kind='deterministic-common-cpu',shared_post_delay_phase=True,
                    pending_survives_ineligible_shot=True,session_change_clears_pending=True,
                    exact_notification_damage_and_final_latch_compared=True,computed_cpu_action_schedule=False,
                    input_words=109968,output_words=1769856,extra_runtime_bytes=0,extra_output_words=0,
                    remaining=['automatic reload with down/revival and callback session changes',
                        'healing storage and mixed actor original definitions','current CUDA execution and warm cache performance',
                        'public admission and all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_healing=dict(suite='coordinate-healing',source_sha256=healing_sources,
                    proof_available=healing_golden is not None,sealed_source_matches_current=healing_matches,
                    input_count=len(healing_golden['entries']) if healing_golden else None,
                    reference_kind='deterministic-common-cpu',shared_storage_share_discharge_handlers=True,
                    native_lifecycle_and_active_pool_compared=True,computed_cpu_action_schedule=False,
                    input_words=109968,output_words=1769856,extra_runtime_bytes=0,extra_output_words=0,
                    remaining=['complete original character profiles with original weapon/control metadata',
                        'down/revival and callback session combinations','current CUDA execution and warm cache performance',
                        'public admission and all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_original=dict(suite='coordinate-original',source_sha256=original_sources,
                    proof_available=original_golden is not None,sealed_source_matches_current=original_matches,
                    input_count=len(original_golden['entries']) if original_golden else None,
                    reference_kind='deterministic-common-cpu',complete_original_roster_bridge=True,
                    original_effects_weapons_controls_preserved=True,shared_named_removal_handler=True,
                    retained_history_capacity=dict(team=1024,fractional=2048,projectile=2048),
                    omissions_must_match_native=True,computed_cpu_action_schedule=False,
                    remaining=['original weapon multi-target group routing',
                        'down/revival and callback session combinations','current CUDA execution and warm cache performance',
                        'public admission and all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_original_periodic=dict(suite='coordinate-original-periodic',source_sha256=original_sources,
                    proof_available=periodic_original_golden is not None,
                    sealed_source_matches_current=periodic_original_golden['source_sha256']==original_sources if periodic_original_golden else None,
                    input_count=len(periodic_original_golden['entries']) if periodic_original_golden else None,
                    reference_kind='deterministic-common-cpu',original_periodic_definitions_preserved=True,
                    duplicate_periodic_labels_supported=True,stable_owner_and_registration_identity=True,
                    nonperiodic_damage_labels_must_be_unique=True,
                    remaining=['dead-enemy-specific infection predicate and spread recipients',
                        'current CUDA execution and public all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_original_lifecycle=dict(suite='coordinate-original-lifecycle',source_sha256=original_sources,
                    proof_available=lifecycle_original_golden is not None,
                    sealed_source_matches_current=lifecycle_original_golden['source_sha256']==original_sources if lifecycle_original_golden else None,
                    input_count=len(lifecycle_original_golden['entries']) if lifecycle_original_golden else None,
                    reference_kind='deterministic-common-cpu',original_definitions_weapons_preserved=True,
                    alternate_source_activation_counts_checked=True,same_label_tick_phase_preserved=True,
                    death_predicate_scope='current target state; not dead-enemy identity',
                    remaining=['dead-enemy-specific spread and non-BODY infection recipients',
                        'armed summon attack and self-destruct payloads','current CUDA execution',
                        'public admission and all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_original_revival=dict(suite='coordinate-original-revival',source_sha256=original_sources,
                    proof_available=revival_original_golden is not None,
                    sealed_source_matches_current=revival_original_golden['source_sha256']==original_sources if revival_original_golden else None,
                    input_count=len(revival_original_golden['entries']) if revival_original_golden else None,
                    original_definitions_weapons_preserved=True,reference_kind='deterministic-common-cpu',
                    shared_revival_trace_comparator=True,original_condition_removal_checked=True,
                    remaining=['other original revival characters and random candidates',
                        'enemy healing-received payload blocks Anne complete roster',
                        'current CUDA execution and public all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_original_burst_revival=dict(suite='coordinate-original-burst-revival',source_sha256=burst_revival_sources,
                    proof_available=burst_revival_golden is not None,
                    sealed_source_matches_current=burst_revival_golden['source_sha256']==burst_revival_sources if burst_revival_golden else None,
                    input_count=len(burst_revival_golden['entries']) if burst_revival_golden else None,
                    original_definitions_weapons_preserved=True,reference_kind='deterministic-common-cpu',
                    existing_shared_remaining_clock_handler=True,admitted_kind=22,
                    revival_attempts_and_successes_checked_separately=True,multiple_actual_dead_candidates=True,
                    remaining=['other original resource/stack/ammo operation admission',
                        'Anne complete roster enemy heal_received_pct payload',
                        'current CUDA execution and public all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_original_resources=dict(suite='coordinate-original-resources',source_sha256=resource_original_sources,
                    proof_available=resource_original_golden is not None,
                    sealed_source_matches_current=resource_original_golden['source_sha256']==resource_original_sources if resource_original_golden else None,
                    input_count=len(resource_original_golden['entries']) if resource_original_golden else None,
                    original_definitions_weapons_preserved=True,reference_kind='deterministic-common-cpu',
                    shared_gauge_handlers=True,admitted_kinds=[9,10],shared_slang_cpu_kind_declaration=True,
                    checked=['stored values and base caps','actual charge/consume dispatch counts','cap-dependent callbacks','no spurious step notifications'],
                    remaining=['positive gauge-step notifications in original rosters','other resource and ammo operation admission',
                        'current CUDA execution and public all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_original_ammo=dict(suite='coordinate-original-ammo',source_sha256=ammo_original_sources,
                    proof_available=ammo_original_golden is not None,
                    sealed_source_matches_current=ammo_original_golden['source_sha256']==ammo_original_sources if ammo_original_golden else None,
                    input_count=len(ammo_original_golden['entries']) if ammo_original_golden else None,
                    original_definitions_weapons_preserved=True,reference_kind='deterministic-common-cpu',
                    shared_ammo_handlers=True,admitted_kinds=[13,14],shared_slang_cpu_kind_declaration=True,
                    checked=['actual percentage and flat dispatches','effective capacity and upper clipping',
                        'negative percentage drain','positive original gauge-step reward and final resources'],
                    remaining=['other original stack and resource operations','enemy healing and original weapon group model',
                        'current CUDA execution and public all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_original_stacks=dict(suite='coordinate-original-stacks',source_sha256=stack_original_sources,
                    proof_available=stack_original_golden is not None,
                    sealed_source_matches_current=stack_original_golden['source_sha256']==stack_original_sources if stack_original_golden else None,
                    input_count=len(stack_original_golden['entries']) if stack_original_golden else None,
                    original_definitions_weapons_preserved=True,reference_kind='deterministic-common-cpu',
                    shared_stack_mutation_and_notice_handlers=True,admitted_kinds=[16,17,19],
                    checked=['actual original dispatch counts','all final stack carriers and lifetime/membership',
                        'current-stack increase and duration refresh','cap and missing-carrier no-ops','consumption and later recharge'],
                    remaining=['other original stack operations and enemy mutation','removal and other unadmitted kinds',
                        'current CUDA execution and public all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_original_cleanse=dict(suite='coordinate-original-cleanse',source_sha256=cleanse_original_sources,
                    proof_available=cleanse_original_golden is not None,
                    sealed_source_matches_current=cleanse_original_golden['source_sha256']==cleanse_original_sources if cleanse_original_golden else None,
                    input_count=len(cleanse_original_golden['entries']) if cleanse_original_golden else None,
                    original_definitions_weapons_preserved=True,reference_kind='deterministic-common-cpu',
                    shared_resident_and_world_overlay_handlers=True,admitted_kinds=[26],
                    shared_recipient_and_sampled_mt=True,integer_draw_receipts_and_full_mt_state_checked=True,
                    checked=['empty actual cleanse','partial shared-carrier cleanse with three allies retained',
                        'all-allied actual removal','enemy beneficial dispel and irremovable retention'],
                    remaining=['boss attack debuff payload is unconnected','other original stack/resource operations',
                        'current CUDA execution and public all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_original_source_operations=dict(suite='coordinate-original-source',source_sha256=slot_original_sources,
                    proof_available=slot_original_golden is not None,
                    sealed_source_matches_current=slot_original_golden['source_sha256']==slot_original_sources if slot_original_golden else None,
                    input_count=len(slot_original_golden['entries']) if slot_original_golden else None,
                    original_definitions_weapons_preserved=True,reference_kind='deterministic-common-cpu',
                    shared_source_slot_and_duration_handlers=True,admitted_kinds=[15,33],
                    checked=['actual original forced skill-slot definitions','real part destruction then original duration extensions',
                        'DoT damage after the old deadline','final carrier expiration and DoT next tick','nonempty periodic grid during extension',
                        'original staged DoT damage and stack-only coefficient override','wide enemy DoT duration membership'],
                    initial_force_clock_scope='Empty initial grid, not a nonempty-clock witness',
                    remaining=['other original duration recipients and forced-slot combinations',
                        'current CUDA execution and public all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                coordinate_original_forced_reload=dict(suite='coordinate-original-reload',source_sha256=forced_original_sources,
                    proof_available=forced_original_golden is not None,
                    sealed_source_matches_current=forced_original_golden['source_sha256']==forced_original_sources if forced_original_golden else None,
                    input_count=len(forced_original_golden['entries']) if forced_original_golden else None,
                    original_definitions_weapons_preserved=True,shared_reload_observer_and_reader=True,admitted_kinds=[23],
                    checked=['actual charge-hold force request with original character defaults','actual state-end force request',
                        'actual burst-cast force request','complete force/start/finish trace and final clocks'],
                    remaining=['other original recipient and reload/weapon mixtures','current CUDA execution and public all-character certification'],
                    public_gpu_admitted=False,all_characters_certified=False),
                sampled_vital_kind_preflight=dict(shared_generated_guard=True,scope='definition kinds only',
                    rejects_before_native_and_gpu=True,explicit_subsets_respected=True,expected_rejections_preserved=True,
                    full_gpu_admission_verified=False),
                static_original_entry_inventory=dict(command='entry-inventory --out UNIQUE.json',
                    scope='All default-growth/no-cube original coordinate input packing and literal kind catalog',
                    battle_and_gpu_forbidden=True,gpu_admission_verified=False),
                original_damage_identity_inventory=inspect_original_identities(),
                packet_integer_ratio=dict(suite='packet-ratio',source_sha256=ratio_sources,
                    proof_available=ratio_golden is not None,sealed_source_matches_current=ratio_matches,
                    input_count=len(ratio_golden['entries']) if ratio_golden else None,
                    numerator_bits=128,divisor_min=1,divisor_max=1024,rounding='single nearest even'),
                logical_pellets_equal_emitted_packets=False, dependencies=dependencies,
                source_sha256={p: hashlib.sha256(t.encode()).hexdigest() for p, t in texts.items()},
                model_gap_audit=model, gpu_calls=0, native_battle_calls=0,
                calculation_verified=False, full_goal_complete=False)
