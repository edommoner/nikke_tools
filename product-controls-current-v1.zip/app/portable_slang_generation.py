"""Paired Slang code generation, independent of CUDA/Metal execution transports."""
import hashlib,os,platform,re,subprocess,tempfile
from pathlib import Path


def source_hashes(root,source):
    found = {}
    def visit(path):
        key = path.relative_to(root).as_posix()
        if key in found:
            return
        raw = path.read_bytes()
        found[key] = hashlib.sha256(raw).hexdigest()
        for include in re.findall(rb'^\s*#include\s+"([^"]+)"', raw, re.M):
            visit((path.parent/include.decode()).resolve())
    visit(root/source)
    return found

def build(root,source,entry):
    compiler_root = Path(os.environ.get('NIKKE_SLANG_ROOT', root/f'.tools/slang-2026.20-{platform.system()}-{platform.machine()}'))
    compiler_root=compiler_root.resolve()
    compiler = compiler_root/'bin'/('slangc.exe' if os.name == 'nt' else 'slangc')
    hashes = source_hashes(root,source)
    resident=any(re.search(rb'^\s*#define\s+PORTABLE_RESIDENT_RUNTIME(?:\s|$)',(root/name).read_bytes(),re.M) for name in hashes)
    directory = root/'research/portable-build'
    directory.mkdir(parents=True, exist_ok=True)
    generation_cache=os.environ.get('NIKKE_SLANG_GENERATION_CACHE')
    generation_required=os.environ.get('NIKKE_SLANG_GENERATION_REQUIRED','0')
    if generation_required not in ('0','1') or generation_required=='1' and not generation_cache:
        raise ValueError('Required Slang generation cache directory missing or invalid')
    if generation_cache:
        if not resident:raise ValueError('Slang generation cache requires paired resident reflection')
        from portable_generation_cache import get_or_generate
        return get_or_generate(root,compiler_root,source,entry,hashes,directory,Path(generation_cache),
            lambda staging:_build_resident(root,compiler,source,entry,hashes,staging),required=generation_required=='1')
    if resident:
        return _build_resident(root,compiler, source, entry, hashes, directory)
    outputs = {}
    for target, suffix in [('cuda', 'cu'), ('metal', 'metal')]:
        output = directory/f'{Path(source).stem}.{suffix}'
        process = subprocess.run([str(compiler), str(root/source), '-entry', entry,
                                  '-target', target, '-fp-mode', 'precise', '-line-directive-mode', 'none',
                                  ], capture_output=True, timeout=90)
        if process.returncode:
            raise RuntimeError(process.stderr.decode('utf-8', 'replace'))
        # Multiple application requests may build the same immutable shader.
        # Publish atomically so another Swift process never reads a partial file.
        with tempfile.NamedTemporaryFile(dir=directory,delete=False) as temporary:
            temporary.write(process.stdout);temporary_path=Path(temporary.name)
        temporary_path.replace(output)
        outputs[target] = output
    if source_hashes(root,source) != hashes:
        raise RuntimeError('GPU sources changed during build; discard generated outputs')
    return outputs, hashes

def _build_resident(root,compiler,source,entry,hashes,directory):
    """Validate fresh paired code/reflection before publishing any resident output."""
    from portable_resident_layout import reflection_plan,cuda_layout_assertions
    temporary_root=None
    if platform.system()=='Windows':
        # The bounded child intentionally redirects TEMP into its capture. Slang
        # can be denied native writes in Documents even when Python can publish
        # there. Keep compiler scratch in the user's OS temp, without changing
        # the child/parent environment or Windows security settings.
        local=os.environ.get('LOCALAPPDATA')
        if not local or not Path(local).is_absolute():raise ValueError('Missing absolute LOCALAPPDATA for Slang scratch')
        temporary_root=Path(local)/'Temp'
        if not temporary_root.is_dir():raise ValueError('Windows Slang scratch directory missing')
    with tempfile.TemporaryDirectory(prefix='nikke-resident-build-', dir=temporary_root) as tmp:
        staged={}
        for target,suffix in [('cuda','cu'),('metal','metal')]:
            output=Path(tmp)/(Path(source).stem+'.'+suffix)
            reflection=Path(str(output)+'.reflection.json')
            process=subprocess.run([str(compiler),str(root/source),'-entry',entry,
                '-target',target,'-fp-mode','precise','-line-directive-mode','none',
                '-o',str(output),'-reflection-json',str(reflection)],capture_output=True,timeout=90)
            diagnostic=process.stderr.decode('utf-8','replace').strip()
            if process.returncode:
                raise RuntimeError('Slang resident '+target+' generation failed: '+diagnostic)
            for path in (output,reflection):
                if not path.is_file() or not path.stat().st_size:
                    raise RuntimeError('Slang resident '+target+' artifact missing or empty: '+path.name+'; '+diagnostic)
            staged[target]=output
        plan=reflection_plan(staged,entry)
        if b'actorStateQueryScopeSnapshot_' in staged['cuda'].read_bytes():
            from portable_scope_snapshot_audit import audit as audit_scope_snapshot
            audit_scope_snapshot(staged['cuda'].read_bytes(),staged['metal'].read_bytes())
        if b'markEntry_' in staged['cuda'].read_bytes() or b'initializeHPWatches_' in staged['cuda'].read_bytes():
            from portable_scope_snapshot_audit import audit_resident_appends
            audit_resident_appends(staged['cuda'].read_bytes(),staged['metal'].read_bytes())
        staged['cuda'].write_bytes(cuda_layout_assertions(staged['cuda'].read_bytes(),plan))
        if source_hashes(root,source)!=hashes:
            raise RuntimeError('GPU sources changed during build; discard generated outputs')
        outputs={}
        for target,path in staged.items():
            output=directory/path.name
            # Python publishes on the destination filesystem, including when
            # the checkout and OS temp are on different volumes.
            for candidate,destination in ((Path(str(path)+'.reflection.json'),Path(str(output)+'.reflection.json')),(path,output)):
                with tempfile.NamedTemporaryFile(dir=directory,delete=False) as temporary:
                    temporary.write(candidate.read_bytes());temporary_path=Path(temporary.name)
                temporary_path.replace(destination)
            outputs[target]=output
    return outputs,hashes
