"""Prepare comparison of an single masked comparison for the two physical boolean stat identities after all current gates/transfer terminate.

Initial unlocalized Metal finding stays recorded. Production is unchanged by this tool. Every candidate output is
compared byte-for-byte/hash with its control; a mismatch is captured and stops.
"""
import array,copy,hashlib,importlib.util,io,json,statistics,struct,subprocess,sys,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/'research';SOURCE='7492d8b191471f820989dc760bc4adc91494cf6a'
sys.path[:0]=[str(R/'app'),str(R/'scripts')]
import portable_runtime as runtime
from portable_specs import ABI,LIMITS as L
class Captured(BaseException):pass
def load(n):return json.loads((P/(n+'.json')).read_text())
def save(n,x):(P/(n+'.json')).write_text(json.dumps(x,indent=2)+'\n')
def prepare(variant):
 folder=P/'portable-build'/('attack-flag-'+variant);folder.mkdir(parents=True,exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',SOURCE,'gpu'],cwd=R))) as archive:archive.extractall(folder,filter='data')
 if variant=='candidate':
  path=folder/'gpu/event_runtime.slang';source=path.read_text()
  from portable_damage_specs import STATS
  assert STATS['pierce_enabled']==36 and STATS['armor_break_enabled']==52
  old='if(d.stat==S_pierce_enabled || d.stat==S_armor_break_enabled)'
  assert source.count(old)==1
  source=source.replace(old,'if((d.stat & 0xffffffefU)==S_pierce_enabled)')
  path.write_text(source)
 wrapper=folder/('attack_flag_'+variant+'_runtime.slang');wrapper.write_text('#include "gpu/event_runtime.slang"\n');return wrapper.relative_to(R).as_posix()
def save_input(path,items):
 with path.open('wb') as stream:
  stream.write(struct.pack('<I',len(items)))
  for words,_ in items:
   block=array.array('I',words)
   if sys.byteorder!='little':block.byteswap()
   stream.write(block.tobytes())
def file_sha(path):
 digest=hashlib.sha256()
 with path.open('rb') as stream:
  while chunk:=stream.read(8*1024*1024):digest.update(chunk)
 return digest.hexdigest()
def main():
 assert ABI==0x5045566F
 barrier=load('portable-attack-flags-timing-order');broad=load('portable-attack-flags-broad-validation');current=load('portable-combat-metal')
 assert barrier['passed'] and barrier['windows_execution_and_transfer_terminal'] and not barrier['verification_processes']
 assert broad['passed'] and broad['all_current_gates_passed'] and broad['source_commit']==SOURCE and broad['mac_gates']==37 and current['passed']
 subprocess.run(['git','diff','--exit-code',SOURCE,'--','app','scripts','gpu','tests'],cwd=R,check=True,stdout=subprocess.DEVNULL)
 spec=importlib.util.spec_from_file_location('attack_flag_benchmark_core',R/'scripts/verify-portable-combat.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
 programs=[]
 def collect(p,**kwargs):programs.extend(p);raise Captured()
 report=P/'portable-combat-metal.json';saved=report.read_bytes();oldargv=sys.argv;sys.argv=[sys.argv[0],'--backend','metal'];v.run_programs=collect
 try:
  try:v.main()
  except Captured:pass
 finally:report.write_bytes(saved);sys.argv=oldargv
 assert len(programs)==2950
 paths={name:prepare(name) for name in ('control','candidate')};one,many=runtime.execute,runtime.execute_batches
 def run(name,items):
  def single(source,*args,**kwargs):
   assert source=='gpu/event_runtime.slang';return one(paths[name],*args,**kwargs)
  def sequence(source,*args,**kwargs):
   assert source=='gpu/event_runtime.slang';return many(paths[name],*args,**kwargs)
  runtime.execute=single;runtime.execute_batches=sequence
  try:return runtime.dispatch_programs(items,backend='metal')
  finally:runtime.execute=one;runtime.execute_batches=many
 hp_current=load('portable-health-runtime-metal')
 hp_cases=json.loads((R/'tests/fixtures/portable-health-runtime.json').read_text())['cases']
 hp_programs=[v.compile_case(c) for c in hp_cases];assert len(hp_programs)==20
 parity={}
 for name in paths:
  folder=P/'portable-build'/('attack-flag-full-'+name);folder.mkdir(parents=True,exist_ok=False)
  save_input(folder/'input.bin',programs)
  assert file_sha(folder/'input.bin')==current['input_sha256']
  raw,e=run(name,programs)
  (folder/'readback.bin').write_bytes(raw)
  (folder/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
  if e['input_sha256']!=current['input_sha256'] or e['output_sha256']!=current['output_sha256']:
   fail=P/'portable-build'/('attack-flag-'+name+'-nonmatching.bin');fail.write_bytes(raw);save('portable-attack-flags-candidate-failure',dict(passed=False,variant=name,evidence=e,raw_path=str(fail)));raise RuntimeError('Candidate/control output mismatch captured; no retry')
  parity[name]=e;del raw
  save_input(folder/'health-input.bin',hp_programs)
  assert file_sha(folder/'health-input.bin')==hp_current['input_sha256']
  hp_raw,hp_e=run(name,hp_programs)
  (folder/'health-readback.bin').write_bytes(hp_raw)
  (folder/'health-evidence.json').write_text(json.dumps(hp_e,indent=2)+'\n')
  if hp_e['input_sha256']!=hp_current['input_sha256'] or hp_e['output_sha256']!=hp_current['output_sha256']:
   save('portable-attack-flags-candidate-failure',dict(passed=False,variant=name,health_runtime=True,evidence=hp_e,captured=str(folder)));raise RuntimeError('HP candidate/control mismatch captured;no retry')
  parity[name]['additional_health_runtime']=hp_e;del hp_raw
 save('portable-attack-flags-candidate-parity',dict(passed=True,source_commit=SOURCE,programs=2950,additional_health_cases=20,all_additional_health_input_output_bytes_equal=True,all_input_and_output_bytes_equal=True,parity=parity))
 fixtures={c['name']:c for c in v.fixtures()}
 workloads={'ordinary':fixtures['auto-magazine-reload'],
            'self-flag':fixtures['attack-flag-presence-0-pierce_enabled-1-self'],
            'allies-flag':fixtures['attack-flag-presence-4-armor_break_enabled-2-all_allies'],
            'duplicate-flags':fixtures['attack-flag-alias-pierce_enabled-1-all_allies'],
            'both-shotgun':fixtures['attack-flag-both-SG'],
            'weapon-change':fixtures['attack-flag-mode-0'],
            'pellet-parent':fixtures['attack-flag-pellet-parent-3'],
            'conditional-hp':next(c for c in hp_cases if c['name']=='conditional-hp-0-hp_caster_based_pct-all_allies')}



 rows={}
 for label,c in workloads.items():
  items=[v.compile_case(c)]*1024;samples={name:[] for name in paths};baseline=None
  for sample in range(4):
   for name in (list(paths) if sample%2==0 else list(reversed(paths))):
    raw,e=run(name,items)
    if baseline is None:baseline=raw
    if raw!=baseline:
     fail=P/'portable-build'/('attack-flag-'+label+'-'+name+'-nonmatching.bin');fail.write_bytes(raw);fail.with_suffix('.baseline.bin').write_bytes(baseline);save_input(fail.with_suffix('.input.bin'),items);save('portable-attack-flags-candidate-failure',dict(passed=False,workload=label,variant=name,sample=sample,evidence=e,raw_path=str(fail)));raise RuntimeError('Workload mismatch captured; no retry')
    samples[name].append(dict(warmup=sample==0,**e));print(label,sample,name,e['transport']['gpu_seconds'],flush=True)
  medians={name:statistics.median(x['transport']['gpu_seconds'] for x in a[1:]) for name,a in samples.items()};ranges={name:[min(x['transport']['gpu_seconds'] for x in a[1:]),max(x['transport']['gpu_seconds'] for x in a[1:])] for name,a in samples.items()}
  rows[label]=dict(programs=1024,median_gpu_seconds=medians,ranges=ranges,candidate_to_control_ratio=medians['candidate']/medians['control'],samples=samples)
 save('portable-attack-flags-benchmark',dict(passed=True,source_commit=SOURCE,all_2950_input_output_bytes_equal=True,all_additional20_health_input_output_bytes_equal=True,production_change_adopted=False,parity=parity,workloads=rows,timing_order=barrier,tool_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),initial_metal_finding_open=True,scope='Alternating variant order,warmup plus3 samples per variant,1024 programs per workload on Apple M5. Initial unlocalized raw mismatch remains documented. No CUDA-speed/full-roster/physical-peak-memory claim; desktop GPU activity not excluded.'))
if __name__=='__main__':main()
