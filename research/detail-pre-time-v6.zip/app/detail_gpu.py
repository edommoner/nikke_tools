"""Strict CUDA effect interpreter and CPU-oracle verification boundary.
Supports autonomous five-member squads within the fail-closed compiled subset.
No effect is silently omitted. Scenario scripts contain external input events, never
CPU-calculated buff states, weapon transitions, damage, or shot times.
"""
from __future__ import annotations
import array,ctypes as C,math,re,time
from pathlib import Path
from gpu_combat import STAT as COARSE_STAT
STAT={**COARSE_STAT,'crit_rate_skill':24,'crit_dmg_skill':25,'atk_caster_based_pct':26,'split_dmg_pct':27,'stun':28,'fullburst_duration':29,'attack_speed_pct':30,'mg_warmup_speed_pct':31}
EVENT={'battle_start':0,'passive':0,'full_burst_start':1,'full_burst_end':2,'burst_cast':3,'burst_enter':4,'enemy_spawn':5,'every':6,'on_attack':7,'hit_count':8,'stack_reach':9,'full_charge':10,'full_charge_fire':11,'full_charge_hit':12,'burst_cast_count':13,'last_bullet':14,'inactive':15,'event:heal_received':16,'event:cover_healed':17,'event:shield_applied':18,'event:full_reload':19,'pellet_hit':20,'last_bullet_fire':21,'crit_hit':22,'core_hit':23,'squad_ammo_consume':26,'pellet_hit_in_shot':27,'event:enemy_spawn':5,'received_hit':32,'enemy_death':33,'event:part_destroy':34,'event:projectile_destroy':35,'event:cover_hit':36,'event:lethal_hit':37,'event:self_down':38}
EXTRA={'burst_cooldown':32,'max_ammo_flat':33,'charge_time_flat':34,'pierce_dmg_pct':35,'pierce_enabled':36,'charge_speed_caster_based_pct':37,'max_hp_pct':38,'hp_caster_based_pct':39,'hp_only_caster_based_pct':40,'max_hp_only_pct':41,'heal_received_pct':42,'lifesteal_pct':44,'shield_from_max_hp_pct':45,'def_caster_based_pct':46,'pellet_count':47,'pellet_count_fixed':48,'reload_ratio_pct':49,'dot_dmg_pct':50,'armor_break_dmg_pct':51,'armor_break_enabled':52,'charge_time_fixed':53,'part_dmg_pct':54,'intercept_dmg_pct':55,'burst_dmg_aoe_pct':56,'burst_dmg_single_pct':57}
# These named states cannot affect outgoing damage in the static, unharmed-boss model.
INERT={'max_hp_pct','hp_only_caster_based_pct','hp_caster_based_pct','def_pct','decoy','taunt','cover_hp_pct','cover_def_pct','heal_received_pct','lifesteal_pct','damage_reduction_pct','force_move','invincible'}
NE,EW,CW,OW=128,224,40,48
NT,TD,TS=8,145,7
DETAIL_ABI='detail_stackops_v6'
class UnsupportedDetail(ValueError):
 def __init__(self,issues):
  self.issues=issues if isinstance(issues,list) else [{'reason':str(issues)}]
  super().__init__(str(self.issues))

def compile_effects(chars,effects):
 if len(chars)!=5 or len({c.get('name') for c in chars})!=5:raise ValueError('Detailed squads require five distinct characters')
 names=[c['name'] for c in chars];states={}
 def state(name):
  if name not in states:states[name]=len(states)
  return states[name]
 from calculator.buff_manager import _has_runtime_cond,_is_cond_finite_passive,_STAT_TO_BUFF
 stat_codes={name:i for i,name in enumerate(sorted({e.get('stat','') for e,n in effects if isinstance(e.get('stat',''),str)}))}
 rows=[];compiled=[];problems=[];groups={};equipment_states={}
 for eff,caster in effects:
  try:
   owner=names.index(caster);c=chars[owner];kind=eff.get('type');stat=eff.get('stat','');q=[0.0]*EW;q[0]=owner;q[3]=state(eff.get('name',''));q[10]=-1;q[43]=-1;q[57]=eff.get('max_trigger',-1);q[58]=len(rows);q[62]=eff.get('duration_bullets',-1);q[61]=1;q[64]=-1;q[65]=-1;q[136]=-1;q[35]=int(bool(eff.get('name','')))
   if not isinstance(q[57],int) or q[57]<-1:raise UnsupportedDetail('invalid maximum trigger count')
   allowed={'source','name','type','stat','target','trigger','values','fixed_value','max_stack','duration','duration_values','trigger_values','max_trigger','gauge_id','gauge_max','hit_count_gauge_ref','hits_parts','tick_interval','tick_start','duration_bullets','damage_formula','scaling','scaling_ref','target_effect','remove_scope','event_scope','weapon_type','damage_coeff','max_ammo','core_dmg_mult','note','polarity','favorite','_source_tag','_quant_group'}
   if set(eff)-allowed:raise UnsupportedDetail('effect fields: '+', '.join(sorted(set(eff)-allowed)))
   if 'remove_scope' in eff and not (kind=='instant' and stat=='remove_named_buff'):raise UnsupportedDetail('removal scope on a non-removal effect')
   if eff.get('event_scope','squad') not in ('squad','recipients'):raise UnsupportedDetail('unknown named event audience')
   q[201]=int(eff.get('event_scope')=='recipients');q[203]=q[204]=-1;q[206]=stat_codes.get(stat,-1);q[207]=int(stat in _STAT_TO_BUFF or stat=='atk_caster_based_pct')
   base_stat=stat.split(':')[0] if isinstance(stat,str) else stat
   if q[62]!=-1 and (kind!='buff' or not isinstance(q[62],int) or q[62]<1):raise UnsupportedDetail('bullet lifetime requires a positive buff counter')
   if stat in ('gauge_charge','gauge_consume','gauge_consume_as_ammo','gauge_max_add'):
    if kind!=('buff' if stat=='gauge_max_add' else 'instant') or not isinstance(eff.get('gauge_id'),str) or not eff['gauge_id']:raise UnsupportedDetail('invalid gauge definition')
    q[1]={'gauge_charge':9,'gauge_consume':10,'gauge_consume_as_ammo':11,'gauge_max_add':12}[stat];q[64]=state(eff['gauge_id']);q[65]=eff.get('gauge_max',-1);q[70]=eff.get('fixed_value',0)
    if not isinstance(q[65],(int,float)) or not math.isfinite(q[65]) or 'gauge_max' in eff and q[65]<0:raise UnsupportedDetail('invalid gauge cap')
   elif 'gauge_id' in eff or 'gauge_max' in eff:raise UnsupportedDetail('gauge fields on a nongauge effect')
   elif kind=='instant' and stat in ('buff_stack_add','buff_stack_remove','buff_stack_init','debuff_stack_add','debuff_stack_remove'):
    if not isinstance(eff.get('target_effect',''),str):raise UnsupportedDetail('invalid stack state name')
    q[1]={'buff_stack_add':16,'buff_stack_remove':17,'buff_stack_init':18,'debuff_stack_add':20,'debuff_stack_remove':21}[stat];q[36]=state(eff.get('target_effect',''));q[212]=int(bool(eff.get('target_effect')))
   elif kind=='buff' and stat=='buff_max_stack_add':q[1]=19
   elif kind=='buff' and stat=='stack_change_immune':q[1]=4;q[211]=1
   elif kind=='buff' and stat=='':q[1]=4
   elif kind=='buff' and stat in EXTRA:q[1]=0;q[2]=EXTRA[stat]
   elif kind=='buff' and stat in INERT:
    q[1]=4
    if stat=='def_pct' and isinstance(eff.get('target'),str) and (eff['target'] in ('target','boss','all_enemies','enemy','target_body','same_target') or eff['target'].startswith('enemies_')):q[1]=0;q[2]=2
   elif kind=='instant' and stat=='cover_heal_pct':q[1]=7
   elif kind=='instant' and stat=='heal_hp_pct':q[1]=6
   elif kind=='instant' and stat=='current_hp_reduce':q[1]=8
   elif kind=='instant' and stat in ('ammo_charge_pct','ammo_charge_flat'):q[1]=13 if stat=='ammo_charge_pct' else 14
   elif kind=='buff' and stat=='element_bonus_pct':q[1]=0;q[2]=17
   elif kind=='instant' and stat=='burst_cooldown_reduce':q[1]=5
   elif kind=='buff' and stat in STAT and stat not in ('crit_rate_skill','crit_dmg_skill'):q[1]=0;q[2]=STAT[stat]
   elif kind=='instant' and stat=='remove_named_buff':
    if not isinstance(eff.get('target_effect'),str):raise UnsupportedDetail('named removal requires a state name')
    if eff.get('remove_scope','global') not in ('global','target'):raise UnsupportedDetail('unknown named removal scope')
    q[1]=1;q[36]=state(eff['target_effect']);q[142]=int(eff.get('remove_scope')=='target')
   elif kind=='instant' and stat=='named_buff_duration_extend':
    if not isinstance(eff.get('target_effect'),str):raise UnsupportedDetail('duration extension requires a state name')
    q[1]=15
    # Exact name plus space-delimited child names, as in the pinned CPU engine.
    prefix=eff['target_effect'];words=[0]*4
    if prefix:
     for other,who in effects:
      name=other.get('name','')
      if name==prefix or name.startswith(prefix+' '):
       index=state(name)
       if index>=NE:raise UnsupportedDetail('named duration extension exceeds state capacity')
       words[index//32]|=1<<(index%32)
    for slot,word in zip((36,47,142,143),words):q[slot]=word
   elif kind=='weapon_change':
    if eff.get('weapon_type')!='MG' or eff.get('max_ammo')!=-1:raise UnsupportedDetail('only timed infinite-ammo MG weapon mode currently verified')
    q[1]=2
    if eff.get('core_dmg_mult',200)!=c['_weapon'].get('core_dmg_mult',200):raise UnsupportedDetail('changed core multiplier')
   elif kind=='damage' and base_stat in ('damage','bonus_damage','burst_damage','split_damage','dot_damage','auto_damage','armor_break_damage','armor_break_burst_damage','sequential_damage','projectile_attachment_damage','projectile_explosion_damage','pierce_damage','core_damage'):
    q[1]=3;q[39]={'burst_damage':1,'split_damage':16,'dot_damage':128,'armor_break_damage':512,'armor_break_burst_damage':513,'sequential_damage':2,'projectile_attachment_damage':4,'projectile_explosion_damage':8,'pierce_damage':64,'core_damage':16384}.get(base_stat,0)
    if ':' in stat:
     suffix=stat.split(':',1)[1]
     if suffix.lstrip('-').isdigit():
      if not -256<=int(suffix)<=256:raise UnsupportedDetail('skill hit count exceeds bounds')
      q[61]=int(suffix)
     elif suffix:q[136]=state(suffix);q[137]=1
     else:raise UnsupportedDetail('empty skill hit count reference')
    if base_stat=='dot_damage' and not eff.get('tick_interval'):raise UnsupportedDetail('dot damage requires its periodic timer')
   else:raise UnsupportedDetail('effect type/stat: '+str(kind)+' / '+stat)
   if 'hit_count_gauge_ref' in eff:
    if kind!='damage' or not isinstance(eff['hit_count_gauge_ref'],str) or not eff['hit_count_gauge_ref']:raise UnsupportedDetail('invalid hit count gauge reference')
    q[136]=state(eff['hit_count_gauge_ref']);q[137]=2
   if 'hits_parts' in eff:
    if kind!='damage' or not isinstance(eff['hits_parts'],bool):raise UnsupportedDetail('invalid part-hit marker')
    if eff['hits_parts'] and c.get('_detail_has_parts',False):q[39]=int(q[39])|1024
   if kind=='damage' and int(q[39])&1:
    target=eff.get('target','self')
    if target=='all_enemies':q[39]=int(q[39])|4096
    elif isinstance(target,str) and target.startswith('enemies_') and target.endswith(':1'):q[39]=int(q[39])|8192
   interval=eff.get('tick_interval',0)
   if interval:
    if kind not in ('instant','damage') or not isinstance(interval,(int,float)) or not math.isfinite(interval) or interval<=0:raise UnsupportedDetail('invalid periodic timer')
    q[59]=interval;q[60]=int(eff.get('tick_start')=='immediate') if kind=='damage' else 2 if eff.get('duration')==-1 else 0
   elif 'tick_start' in eff:raise UnsupportedDetail('tick phase without an interval')
   if eff.get('damage_formula'):
    if kind!='damage' or eff['damage_formula']!='normal_attack':raise UnsupportedDetail('unknown skill damage formula')
    q[39]=int(q[39])|256|(8 if c['_weapon'].get('weapon_type')=='RL' else 0)
   target=eff.get('target','self')
   if target=='self':q[4]=0
   elif target=='all_allies':q[4]=1
   elif target=='all_allies_burst_casted':q[4]=9
   elif target=='all_allies_burst_not_casted':q[4]=10
   elif target=='all_allies_excl_self':q[4]=8;q[48]=31^(1<<owner)
   elif isinstance(target,str) and (target in ('target','boss','all_enemies','enemy','target_body','same_target') or target.startswith('enemies_')):q[4]=4
   elif isinstance(target,str) and re.fullmatch(r'allies_top_atk(_excl)?:[1-5]',target):q[4]=5;q[5]=int(target.split(':')[1]);q[49]=int('_excl' in target)
   elif isinstance(target,str) and re.fullmatch(r'allies_lowest_cover_hp:[1-5]',target):
    # Static boss mode never damages cover; all intact covers tie at 100%.
    q[4]=8;q[48]=(1<<int(target.split(':')[1]))-1
   elif isinstance(target,str) and re.fullmatch(r'allies_top_def:[1-5]',target):q[4]=6;q[5]=int(target.split(':')[1])
   elif isinstance(target,str) and re.fullmatch(r'allies_lowest_hp(_excl)?:[1-5]',target):q[4]=7;q[5]=int(target.split(':')[1]);q[49]=int('_excl' in target)
   elif isinstance(target,str) and target.startswith(('allies_weapon:','allies_code:')):
    key,v=target.split(':');field='weapon_type' if key=='allies_weapon' else 'element_code';q[4]=8;q[48]=sum(1<<i for i,ch in enumerate(chars) if ch['_weapon'].get(field)==v)
   elif re.fullmatch(r'allies_right:[1-5]',target):q[4]=2;q[5]=int(target.split(':')[1])
   elif re.fullmatch(r'allies_adjacent:[1-5]',target):q[4]=3;q[5]=int(target.split(':')[1])

   elif isinstance(target,str) and target.startswith(('allies_class:','allies_code_excl_self:','allies_weapon_excl_self:','allies_code_weapon:','allies_code_weapon_leftmost:','allies_top_base_charge_time:','allies:')) or target in ('allies_squad','allies_burst3'):
    parts=target.split(':');selected=list(range(5));prefix=parts[0]
    lengths={'allies_class':(2,3),'allies_code_excl_self':(2,),'allies_weapon_excl_self':(2,),'allies_code_weapon':(3,),'allies_code_weapon_leftmost':(4,),'allies_top_base_charge_time':(2,),'allies':(2,),'allies_squad':(1,),'allies_burst3':(1,)}
    if len(parts) not in lengths[prefix]:raise UnsupportedDetail('malformed static target')
    count_index=2 if prefix=='allies_class' and len(parts)==3 else 3 if prefix=='allies_code_weapon_leftmost' else 1 if prefix in ('allies_top_base_charge_time','allies') else None
    if count_index is not None and not parts[count_index].isdigit():raise UnsupportedDetail('invalid static target count')

    if prefix=='allies_class':selected=[i for i,ch in enumerate(chars) if ch['_weapon'].get('class')==parts[1]];selected=selected[:int(parts[2])] if len(parts)>2 else selected
    elif prefix in ('allies_code_excl_self','allies_weapon_excl_self'):
     key='element_code' if prefix=='allies_code_excl_self' else 'weapon_type';selected=[i for i,ch in enumerate(chars) if i!=owner and ch['_weapon'].get(key)==parts[1]]
    elif prefix.startswith('allies_code_weapon'):
     selected=[i for i,ch in enumerate(chars) if ch['_weapon'].get('element_code')==parts[1] and ch['_weapon'].get('weapon_type')==parts[2]]
     if prefix=='allies_code_weapon_leftmost':selected=selected[:int(parts[3])]
    elif prefix=='allies_squad':
     squad=c['_weapon'].get('squad');selected=[i for i,ch in enumerate(chars) if i==owner or squad and ch['_weapon'].get('squad')==squad]
    elif prefix=='allies_burst3':selected=[i for i,ch in enumerate(chars) if str(ch.get('burst_stage') or ch['_weapon'].get('burst_stage'))=='3']
    elif prefix=='allies_top_base_charge_time':
     selected=[i for i,ch in enumerate(chars) if (ch['_weapon'].get('charge_time') or 0)>0];selected.sort(key=lambda i:-chars[i]['_weapon']['charge_time']);selected=selected[:int(parts[1])];q[141]=1;q[140]=sum((i+1)<<(3*k) for k,i in enumerate(selected))
    elif prefix=='allies':selected=selected[:int(parts[1])]
    q[4]=8;q[48]=sum(1<<i for i in selected)
   elif isinstance(target,str) and not ':' in target:
    from calculator.buff_manager import _NIKKE
    if target not in _NIKKE:raise UnsupportedDetail('target: '+target)
    q[4]=8;q[48]=1<<names.index(target) if target in names else 0
   else:raise UnsupportedDetail('target: '+str(target))
   if q[1] in (6,7,8) and q[4]==4:raise UnsupportedDetail('enemy heal target')
   c=chars[owner];lv=str(c.get('skill_levels',{}).get(eff.get('source','')[-1:],c.get('skill_level',10)))
   q[6]=1 if stat in ('stun','pierce_enabled','armor_break_enabled','charge_time_fixed') else eff.get('fixed_value',eff.get('values',{}).get(lv,0));duration=eff.get('duration');duration=(eff.get('duration_values') or {}).get(lv,(eff.get('duration_values') or {}).get('10',0)) if kind=='buff' and duration is None and 'duration_values' in eff else duration;q[7]=-1 if duration is None else duration;q[9]=eff.get('max_stack',1)
   q[208]=-1 if eff.get('duration') is None else eff['duration'];q[209]=1 if str(eff.get('polarity','')).startswith('beneficial') else 2 if eff.get('polarity')=='harmful' else 3 if eff.get('polarity')=='harmful_irremovable' else 0;q[210]=int(kind=='buff');q[215]=-1;q[216]=q[4]
   if q[1] in (16,17,18,19,20,21):q[6]=eff.get('fixed_value',(eff.get('values') or {}).get(lv,(eff.get('values') or {}).get('10',1 if q[1]==19 else 0)))
   if stat=='charge_time_fixed':q[138]=eff.get('fixed_value',0);q[139]=int('fixed_value' in eff)
   scaling=eff.get('scaling')
   if kind=='instant' and stat=='heal_hp_pct' and scaling=='max_hp':q[50]=1
   if scaling and not (kind=='instant' and stat in ('cover_heal_pct','heal_hp_pct') and scaling=='max_hp'):
    if scaling!='stack_count' or not eff.get('scaling_ref') and not (kind=='damage' and base_stat=='dot_damage'):raise UnsupportedDetail('scaling: '+str(scaling))
    if 'duration_values' in eff:raise UnsupportedDetail('stack snapshot with level-dependent duration not yet verified')
    q[10]=state(eff['scaling_ref']) if eff.get('scaling_ref') else -2
    if kind=='damage' and base_stat!='dot_damage' and ':' not in stat and 'hit_count_gauge_ref' not in eff and eff.get('scaling_ref'):q[136]=state(eff['scaling_ref']);q[137]=1
   seen_timings=set();period=None
   for timing in eff.get('trigger',{}).get('timing',[]):
    q[46]=0;q[37]=-1;q[38]=0;q[71]=-1;stage=-1
    if '{0}' in timing:
     threshold=eff.get('trigger_values',{}).get(lv)
     if threshold is None:raise UnsupportedDetail('missing level-dependent trigger value')
     timing=timing.replace('{0}',str(threshold))
    if timing in ('full_charge','on_attack','hit_count','pellet_hit','core_hit','crit_hit','last_bullet','last_bullet_fire','event:full_reload','squad_ammo_consume'):q[63]=1
    if timing=='passive':q[11]=1
    if timing.startswith('every:'):
     code=6;arg=0;q[44]=float(timing.split(':')[1].rstrip('s'))
     if q[44]<=0:raise UnsupportedDetail('period must be positive')
     if period is not None and period!=q[44]:raise UnsupportedDetail('multiple timer periods require independent schedules')
     period=q[44]
    elif timing.startswith(('full_burst_start_count:','full_burst_end_count:','full_burst_start_exact:')):
     key,threshold=timing.split(':');code=1 if key.startswith('full_burst_start') else 2;arg=int(threshold);q[46]=3 if key.endswith('_exact') else 2
    elif timing.startswith(('full_charge_fire_count:','full_charge_count:','full_charge_hit_count:','burst_cast_count:')):
     key,threshold=timing.split(':');code={'full_charge_fire_count':11,'full_charge_count':11,'full_charge_hit_count':12,'burst_cast_count':3}[key];arg=int(threshold);q[46]=2 if key=='burst_cast_count' else 1
    elif timing.startswith('burst_enter_count:'):
     _,raw_stage,threshold=timing.split(':');code=4;stage=int(raw_stage);arg=int(threshold);q[46]=2
    elif timing.startswith('burst_enter:'):code=4;arg=int(timing.split(':')[1]);stage=arg
    elif timing.startswith(('pellet_hit_count:','pellet_hit:','crit_hit_count:','core_hit_count:','core_hit:','squad_ammo_consume:','received_hit_count:','received_hit:')):
     key,threshold=timing.split(':');code={'pellet_hit_count':20,'pellet_hit':20,'crit_hit_count':22,'core_hit_count':23,'core_hit':23,'squad_ammo_consume':26,'received_hit_count':32,'received_hit':32}[key];arg=int(threshold);q[46]=1
    elif timing.startswith('pellet_hit_in_shot:'):code=27;arg=int(timing.split(':')[1])
    elif timing.startswith('hit_count:'):code=8;arg=int(timing.split(':')[1])
    elif timing.startswith('on_attack_count:'):code=7;arg=int(timing.split(':')[1])
    elif timing.startswith('event:state_end:'):code=29;arg=0;q[37]=state(timing[len('event:state_end:'):])
    elif timing.startswith('every_stack:'):
     _,name,step=timing.split(':');code=30;arg=int(step);q[37]=state(name)
     if arg<=0:raise UnsupportedDetail('gauge crossing step must be positive')
    elif timing.startswith('stack_reach:'):
     _,name,count=timing.split(':');code=9;arg=0;q[37]=state(name);q[38]=int(count)
    elif timing in EVENT:code=EVENT[timing];arg=1 if code in (7,8) else 0
    elif timing.startswith('event:'):code=31;arg=0;q[71]=state(timing[len('event:'):])
    else:raise UnsupportedDetail('timing: '+timing)
    if (code in (7,8,27) or q[46]>0) and arg<1:raise UnsupportedDetail('counter threshold must be positive')
    tag=q[37] if code in (9,29,30) else q[71] if code==31 else -1
    descriptor=(code,arg,q[46],tag,q[38] if code==9 else 0,int(timing=='passive'),stage)
    index=int(q[144])
    if index>=NT:raise UnsupportedDetail('more than eight trigger descriptors')
    q[TD+index*TS:TD+(index+1)*TS]=descriptor;q[144]=index+1
    # Legacy fields are retained for low-event introspection and burst extension.
    if code<32:q[72+code*2]=arg;q[73+code*2]=q[46];q[12]=int(q[12])|1<<code
    q[13]=arg
   if not q[144]:raise UnsupportedDetail('missing trigger')
   cond=eff.get('trigger',{}).get('condition',[])
   if len(cond)>3:raise UnsupportedDetail('more than three conditions')
   q[14]=len(cond)
   if cond and q[11] and q[7]>=0:
    if kind!='buff' or q[62]>=0:raise UnsupportedDetail('finite conditional passive requires a timed buff')
    q[69]=1
   for j,condition in enumerate(cond):
    typ=0;name=0;arg=0
    if condition.startswith(('gauge_above:','gauge_below:','gauge_eq:','gauge_mod:')):
     parts=condition.split(':');typ={'gauge_above':18,'gauge_below':19,'gauge_eq':20,'gauge_mod':21}[parts[0]];name=state(parts[1]);arg=float(parts[2])
     if typ==21:
      if not arg.is_integer() or arg<=0:raise UnsupportedDetail('invalid gauge modulus')
      q[66+j]=int(parts[3])
    elif condition=='during_full_burst':typ=1
    elif condition=='not_during_full_burst':typ=2
    elif condition.startswith('self_state:'):typ=3;name=state(condition[len('self_state:'):])
    elif condition.startswith('not_self_state:'):typ=4;name=state(condition[len('not_self_state:'):])
    elif condition.startswith('self_stack_above:'):
     _,s,threshold=condition.split(':');typ=5;name=state(s);arg=int(threshold)
    elif condition.startswith('self_hp_above:'):typ=9;arg=float(condition.split(':')[1])
    elif condition.startswith('self_hp_below:'):typ=10;arg=float(condition.split(':')[1])
    elif condition=='self_hp_max':typ=11
    elif condition.startswith('target_state:'):typ=16;name=state(condition[len('target_state:'):])
    elif condition.startswith('not_target_state:'):typ=17;name=state(condition[len('not_target_state:'):])
    elif condition=='during_shield':typ=12
    elif condition=='not_self_caused_heal':typ=13
    elif condition=='burst_casted':typ=14
    elif condition=='burst_not_casted':typ=15
    elif condition=='front_row':raise UnsupportedDetail('front_row has no pinned CPU implementation')
    elif condition=='back_row':typ=7
    elif condition.startswith('self_stat_above:'):
     _,key,threshold=condition.split(':');typ=8;name=STAT[key];arg=float(threshold)
    else:raise UnsupportedDetail('condition: '+condition)
    q[15+j*3:18+j*3]=[typ,name,arg]
   if kind=='weapon_change':
    from calculator.timeline import _MECHANICS,_DELAYS,_pick
    defaults=_MECHANICS['weapon_type_defaults']['MG'];over=_DELAYS.get('_weapon_change',{}).get(caster,{}).get(eff.get('name'),{})
    rate=c['_weapon'].get('weapon_change_fire_rate',{}).get(eff.get('source'));cdn={'fire_rate':rate,'fire_rate_max':rate} if rate else {}
    q[26]=eff['damage_coeff'][lv];q[27]=eff['max_ammo'];q[28]=float(_pick('fire_rate',over,eff,cdn,defaults,default=defaults.get('fire_rate_min',1)))
    q[24]=float(_pick('fire_rate_max',over,eff,cdn,defaults,default=q[28]));q[25]=int(_pick('pellets',over,eff,defaults,default=1));q[29]=int(_pick('muzzles',over,eff,default=1))
    q[30]=c.get('_detail_mg_optimal',c.get('_optimal',False));q[40]=float(_pick('warmup_bullets',over,eff,defaults,default=1));q[41]=defaults.get('cooldown_time',1);q[42]=float(over.get('entry_delay',0))
    if not q[28] or not 1<=q[25]<=64 or not 1<=q[29]<=8:raise UnsupportedDetail('invalid MG mode mechanics')
   group=(caster,eff.get('_source_tag'),eff.get('_quant_group') or len(rows))
   if group not in groups:groups[group]=len(groups)
   q[45]=groups[group]
   # Pinned CPU merges identical named equipment states and retains the first definition.
   # This includes distinct overload groups; compatibility is not an in-game correctness claim.
   if eff.get('_source_tag')=='equipment' and kind=='buff' and not cond:
    alias=(owner,eff.get('name'),stat,str(target),q[9])
    if alias in equipment_states:q[43]=equipment_states[alias]
    else:equipment_states[alias]=len(rows)
   q[217]=int(_has_runtime_cond(eff.get('trigger',{}).get('condition',[]),math.inf,q[62]))
   q[205]=int(kind=='buff' and q[62]<0 and not _has_runtime_cond(eff.get('trigger',{}).get('condition',[]),math.inf if q[7]<0 else 0) and not _is_cond_finite_passive(eff))
   rows.append(q);compiled.append((eff,caster))
  except (UnsupportedDetail,KeyError,TypeError,ValueError) as error:problems.append({'character':caster,'effect':eff.get('name','?'),'reason':str(error)})
 def subscribed(code,tag):
  return any(int(r[TD+a*TS])==code and (code not in (9,29,30,31) or int(r[TD+a*TS+3])==tag) for r in rows for a in range(int(r[144])))
 for q,(eff,caster) in zip(rows,compiled):
  name=eff.get('name','');text='event:'+name
  if text in EVENT:code,tag=EVENT[text],-1
  elif text.startswith('event:state_end:'):code,tag=29,states.get(text[len('event:state_end:'):],-1)
  else:code,tag=31,int(q[3])
  if name and subscribed(code,tag):q[202]=code+1;q[203]=tag
  tag=states.get('stat_applied:'+eff.get('stat',''),-1)
  if eff.get('stat') in ('dot_dmg_pct','split_dmg_pct') and tag>=0 and subscribed(31,tag):q[204]=tag
 for q in rows:
  if q[1]==18:
   q[215]=next((i for i,r in enumerate(rows) if r[0]==q[0] and r[3]==q[36] and r[210]>0),-1)
 if len(states)>NE:problems.append({'reason':'more than 128 named states'})
 if len(rows)>NE:problems.append({'reason':'more than 128 effects'})
 if problems:raise UnsupportedDetail(problems)
 return {'effects':rows,'states':states,'chars':chars}

def weapon_rows(chars,base_stats):
 rows=[]
 for c in chars:
  w=c['_weapon'];r=[0.0]*CW;r[0]=base_stats[c['name']]['atk'];r[1]=w['damage_coeff'];r[2]=w['max_ammo'];r[4]=w['fire_rate'];r[12]=w.get('core_dmg_mult',200);r[13]=w.get('spread_end',10);r[14]=c.get('_optimal',False);r[15]=c.get('_element_match',False)
  from calculator.timeline import CharState
  st=CharState(c,r[0],None);r[3]=w['reload_time'];r[5]=st.fire_rate_max or st.fire_rate;r[6]=st.warmup_bullets;r[7]=st.post_reload_delay;r[8]=2 if st.fire_mode=='auto_warmup' else 1;r[9]=st.spread_start;r[10]=st._spread_shots_needed;r[11]=st.mech.get('cooldown_time',1);r[8]=3 if st.fire_mode=='charge' else r[8];r[16]=st.charge_time_base;r[17]=st.post_fire_delay;r[18]=st._min_fire_cycle;r[19]=w.get('full_charge_mult',100);r[20]=int(c.get('_detail_stage',0));r[21]=w.get('burst_cooldown',40);r[22]=c.get('_detail_pattern',0);r[23]=c.get('_detail_wait',0);r[24]=c.get('_detail_delay',0);r[25]=c.get('burst_regen_time',2);r[26]=w.get('weapon_type')=='RL';r[27]=c.get('_detail_burst_candidate',True);r[28]=base_stats[c['name']].get('hp',1);r[29]=w.get('charge_time') or 0;r[30]=base_stats[c['name']].get('def',0);r[31]=st.cover_during_delay;r[32]=st.pellets;r[33]=st.muzzles;r[34]=st.clip_count
  # Five exact 32-bit words encode explicitly prioritized cycles 1..160.
  for cycle in c.get('_detail_pattern_cycles',[]):
   word,bit=divmod(cycle-1,32);r[35+word]=int(r[35+word])|(1<<bit)
  rows.extend(r)
 return rows

def module_image(device,backend='auto'):
 """Use a hash-checked architecture-specific binary; never compile on request."""
 import json,hashlib
 if backend not in ('auto','ptx','native'):raise ValueError('Invalid detailed module backend')
 root=Path(__file__).parent;cap=getattr(device,'compute_capability',None)
 if backend!='ptx' and cap:
  sm=cap[0]*10+cap[1];binary=root/f'detail_effects-sm{sm}.cubin';manifest=binary.with_suffix('.json')
  try:
   meta=json.loads(manifest.read_text(encoding='utf-8'));blob=binary.read_bytes()
   if meta.get('abi')==DETAIL_ABI and meta['sm']==sm and meta['source_sha256']==hashlib.sha256((root/'detail_effects.cu').read_bytes()).hexdigest() and meta['binary_sha256']==hashlib.sha256(blob).hexdigest():return blob,hashlib.sha256(blob).hexdigest(),f'cubin-sm{sm}'
  except (OSError,ValueError,KeyError):pass
 if backend=='native':raise UnsupportedDetail('No matching current native GPU module')
 try:
  raw=(root/'detail_effects.ptx').read_bytes();meta=json.loads((root/'detail_effects-build.json').read_text(encoding='utf-8'))
  if meta.get('abi')!=DETAIL_ABI or meta['source_sha256']!=hashlib.sha256((root/'detail_effects.cu').read_bytes()).hexdigest() or meta['ptx_sha256']!=hashlib.sha256(raw).hexdigest():raise ValueError('stale detailed PTX')
 except (OSError,ValueError,KeyError) as error:raise UnsupportedDetail('Detailed PTX build is missing or does not match the current source') from error
 blob=raw+b'\0';return blob,hashlib.sha256(blob).hexdigest(),'ptx'

def run(device,programs,script,enemies,base_stats,module_backend='auto'):
 if not programs or len(programs)>2048 or len(script)>65536:raise ValueError('Detailed GPU bounds exceeded')
 if len(enemies)!=len(programs) or len(base_stats)!=len(programs):raise ValueError('Detailed batch input lengths differ')
 for p in programs:
  if len(p['chars'])!=5 or len(p['effects'])>NE:raise ValueError('Invalid detailed program size')
  for r in p['effects']:
   if len(r)!=EW or not all(isinstance(v,(int,float)) and math.isfinite(v) for v in r) or not 0<=r[0]<5 or not 0<=r[2]<58:raise ValueError('Invalid compiled detailed effect')
   if int(r[144])!=r[144] or not 0<=r[144]<=NT:raise ValueError('Invalid detailed trigger descriptor count')
   for a in range(int(r[144])):
    d=r[TD+a*TS:TD+(a+1)*TS]
    if any(int(v)!=v for v in d) or not 0<=d[0]<128 or d[2] not in (0,1,2,3) or not -1<=d[3]<NE or d[5] not in (0,1):raise ValueError('Invalid detailed trigger descriptor')
    if (d[2]>0 or d[0] in (7,8,27,30)) and d[1]<1:raise ValueError('Invalid detailed trigger threshold')
 for en in enemies:
  if len(en)!=2 or not all(isinstance(v,(int,float)) and math.isfinite(v) and v>=0 for v in en):raise ValueError('Invalid detailed enemy')
 n=len(programs);nq=sum(row[1]==2 for row in script)
 if not nq or sorted(int(row[5]) for row in script if row[1]==2)!=list(range(nq)):raise ValueError('Query indices must be contiguous')
 if any(len(row)!=8 or not all(isinstance(v,(int,float)) and math.isfinite(v) for v in row) or not 0<=row[0]<=180 or row[1] not in (0,1,2,3,4,5) or not 0<=row[3]<5 or row[1]==0 and (not 0<=row[2]<128 or int(row[2])!=row[2]) for row in script):raise ValueError('Invalid event program')
 if any(b[0]<a[0] for a,b in zip(script,script[1:])):raise ValueError('Event times must be monotonic')
 if len(programs)*nq*OW*8>256*1024*1024:raise ValueError('Detailed trace exceeds 256 MiB; use smaller batches')
 for p in programs:
  for who in ({0,1,2,3,4} if any(row[1]==4 for row in script) else {int(row[3]) for row in script if row[1]==3}):
   from calculator.timeline import CharState
   char=p['chars'][who];st=CharState(char,1,None)
   if st.fire_mode not in ('auto','auto_warmup','charge') or not (1<=st.pellets<=64 and 1<=st.muzzles<=8 and 1<=st.clip_count<=32):raise UnsupportedDetail('Autonomous weapon mechanics exceed verified bounds')
 import hashlib
 init_started=time.perf_counter();blob,digest,module_format=module_image(device,module_backend)
 cached=getattr(device,'_detail_cached_module',None)
 if cached and cached[:2]==(digest,device.ctx.value):module,fn,state_bytes=cached[2:]
 else:
  if cached and cached[1]==device.ctx.value:
   unload=device.lib.cuModuleUnload;unload.argtypes=[C.c_void_p];unload.restype=C.c_int;device.call('cuModuleUnload',cached[2])
  module=C.c_void_p();fn=C.c_void_p();device.call('cuModuleLoadData',C.byref(module),C.cast(C.c_char_p(blob),C.c_void_p));device.call('cuModuleGetFunction',C.byref(fn),module,DETAIL_ABI.encode())
  get_global=device.lib.cuModuleGetGlobal_v2
  get_global.argtypes=[C.POINTER(C.c_uint64),C.POINTER(C.c_size_t),C.c_void_p,C.c_char_p];get_global.restype=C.c_int
  symbol=C.c_uint64();symbol_size=C.c_size_t();layout=C.c_uint()
  device.call('cuModuleGetGlobal_v2',C.byref(symbol),C.byref(symbol_size),module,b'detail_state_bytes_v6')
  if symbol_size.value!=C.sizeof(layout):raise RuntimeError('Invalid GPU detail workspace layout symbol')
  device.call('cuMemcpyDtoH_v2',C.cast(C.byref(layout),C.c_void_p),symbol,C.sizeof(layout))
  state_bytes=layout.value
  if not 1024<=state_bytes<=2*1024*1024:raise RuntimeError('Invalid GPU detail workspace size')
  device._detail_cached_module=(digest,device.ctx.value,module,fn,state_bytes)
 initialization_ms=round((time.perf_counter()-init_started)*1000,3)
 limit=device.lib.cuCtxSetLimit;limit.argtypes=[C.c_int,C.c_size_t];limit.restype=C.c_int
 if limit(0,131072):raise RuntimeError('CUDA detail stack limit setup failed')
 start=len(device.buffers);started=time.perf_counter()
 try:
  inputs=[array.array('d',(v for p,bs in zip(programs,base_stats) for v in weapon_rows(p['chars'],bs))),array.array('d',(v for p in programs for row in p['effects']+[[0]*EW]*(NE-len(p['effects'])) for v in row)),array.array('i',(len(p['effects']) for p in programs)),array.array('d',(v for enemy in enemies for v in enemy)),array.array('d',(v for row in script for v in row))]
  queries=array.array('d',[0])*(n*nq*OW);totals=array.array('d',[0])*(n*5);status=array.array('i',[0])*n
  # Each squad owns one State. The kernel initializes all live fields.
  workspace=C.c_uint64();device.call('cuMemAlloc_v2',C.byref(workspace),n*state_bytes);device.buffers.append(workspace)
  ptrs=[device.upload(x) for x in inputs];outptrs=[device.upload(x) for x in (queries,totals,status)]
  args=[*ptrs,C.c_int(len(script)),C.c_int(nq),C.c_int(n),*outptrs,workspace];params=(C.c_void_p*len(args))(*(C.cast(C.byref(x),C.c_void_p) for x in args))
  device.call('cuLaunchKernel',fn,(n+31)//32,1,1,32,1,1,0,None,params,None);device.call('cuCtxSynchronize')
  for a,ptr in zip((queries,totals,status),outptrs):device.call('cuMemcpyDtoH_v2',C.cast((C.c_char*(len(a)*a.itemsize)).from_buffer(a),C.c_void_p),ptr,len(a)*a.itemsize)
  if any(status):raise RuntimeError('GPU detail event or active-instance capacity exceeded; result rejected')
  return {'queries':[[list(queries[(i*nq+j)*OW:(i*nq+j+1)*OW]) for j in range(nq)] for i in range(n)],'totals':[list(totals[i*5:i*5+5]) for i in range(n)],'backend':'cuda','detailed_subsystem':True,'full_simulation_verified':False,'initialization_ms':initialization_ms,'module_backend':module_format,'workspace_bytes':n*state_bytes,'elapsed_ms':round((time.perf_counter()-started)*1000,3)}
 finally:
  for ptr in device.buffers[start:]:
   # After a fatal device error, preserve the original error; the caller discards the context.
   device.lib.cuMemFree_v2(ptr)
  del device.buffers[start:]
  # Cached module is released with its owning CUDA context.



def compile_full(prepared,stats,body,policy,requested_policy):
 """Compile validated owned/growth data. No CPU simulation or event trace is used."""
 import copy
 from calculator.buff_manager import BuffManager
 from calculator.timeline import CharState,DEFAULT_CONFIG,DEFAULT_ENEMY
 from gpu_combat import ELEMENT
 config={**DEFAULT_CONFIG,**prepared.config};enemy={**DEFAULT_ENEMY,**prepared.enemy};chars=copy.deepcopy(prepared.squad)
 unsupported=[]
 for k in ('burst_sequence','no_burst_char','max_burst_count'):
  if config.get(k) is not None:unsupported.append({'effect':k,'reason':'special burst control'})
 if config.get('burst_gauge_mode','fixed')!='fixed':unsupported.append({'reason':'accumulated burst gauge is not supported'})
 if config.get('first_burst_time',3)!=3 or config.get('burst_switch_delay',.1)!=.1:unsupported.append({'reason':'nondefault burst clock'})
 bs={c['name']:stats(c) for c in chars}
 for c in chars:
  st=CharState(c,bs[c['name']]['atk'],enemy['code']);w=st.weapon;c['_weapon']=copy.deepcopy(w)
  if st.reload_cancel_on_full:unsupported.append({'character':c['name'],'reason':'manual ammo reload cancellation not yet implemented'})
  stage=str(c.get('burst_stage') or w.get('burst_stage'))
  if stage not in ('1','2','3'):unsupported.append({'character':c['name'],'reason':'multiple or special burst stages'})
  else:c['_detail_stage']=int(stage)
  pattern=config.get('burst_pattern',{}).get(c['name'])
  if pattern is not None:
   if isinstance(pattern,str) and re.fullmatch(r'every:[1-9][0-9]*',pattern):c['_detail_pattern']=int(pattern.split(':')[1])
   elif isinstance(pattern,list) and all(type(cycle) is int and 1<=cycle<=160 for cycle in pattern):
    c['_detail_pattern']=-1;c['_detail_pattern_cycles']=list(pattern)
   else:unsupported.append({'character':c['name'],'reason':'burst pattern requires every:N or a list of cycles 1..160'})
  c['_detail_delay']=config.get('burst_delay',{}).get(c['name'],0)
  c['_detail_wait']=((c.get('control') or {}).get('burst') or {}).get('wait_own_cooldown',0) or 0
  lo,hi=w.get('optimal_range',[0,0]);distance=enemy.get('distance')
  c['_optimal']=lo<=distance<=hi if distance is not None else st.weapon_type in enemy.get('optimal_range_weapons',[])
  c['_element_match']=ELEMENT.get(w.get('element_code'))==enemy['code']
  c['_detail_has_parts']=bool(enemy.get('has_parts',False))
  from calculator.buff_manager import in_optimal_range
  c['_detail_mg_optimal']=in_optimal_range(enemy,c['name'],'MG',{})
  if st.fire_mode not in ('auto','auto_warmup','charge') or not (1<=st.pellets<=64 and 1<=st.muzzles<=8 and 1<=st.clip_count<=32):unsupported.append({'character':c['name'],'reason':'weapon mode or pellet/muzzle/clip count exceeds GPU bounds'})
 if unsupported:raise UnsupportedDetail(unsupported)
 for c in chars:
  stage=c['_detail_stage'];peers=[x for x in chars if x['_detail_stage']==stage]
  c['_detail_burst_candidate']=stage==3 or c is peers[0] or any(x.get('_detail_pattern') or x.get('burst_stage') is not None for x in peers)
 bm=BuffManager(chars,state={'base_stats':bs,'enemy':enemy,'full_burst':False,'rng_acc':{}})
 # B3 bonus damage is deferred by the CPU engine; never accept it as immediate damage.
 program=compile_effects(chars,bm._effects)
 for i,((eff,owner),row) in enumerate(zip(bm._effects,program['effects'])):
  if eff.get('type')=='damage' and eff.get('stat')=='bonus_damage' and 'burst_cast' in eff['trigger']['timing'] and next(c for c in chars if c['name']==owner)['_detail_stage']==3:
   row[51]=1
   later={e.get('name') for e,n in bm._effects[i+1:] if n==owner and e.get('type')=='buff' and 'burst_cast' in e['trigger']['timing']}
   for j,(e,n) in enumerate(bm._effects):
    if n==owner and e.get('name') in later:row[52+j//32]=int(row[52+j//32])|1<<(j%32)
 # Distinct burst-recipient sets are independent CPU buff instances and can overlap.
 # Keep original row indices stable for deferred-hit exclusion bitsets.
 import itertools
 pools=[[i for i,c in enumerate(chars) if c['_detail_stage']==stage and c['_detail_burst_candidate']] for stage in (1,2,3)]
 cast_masks=sorted({sum(1<<i for i in indices) for indices in itertools.product(*pools)})
 expanded=[]
 for i,row in enumerate(program['effects']):
  if row[4] not in (9,10):continue
  if any(int(row[TD+i*TS]) not in (1,2) for i in range(int(row[144]))):raise UnsupportedDetail('burst-recipient targets outside full-burst boundary')
  variants=[]
  for mask in cast_masks:
   recipient=mask if row[4]==9 else 31^mask
   if recipient:
    clone=list(row);clone[4]=8;clone[48]=recipient;clone[56]=mask+1;variants.append(clone)
  if not variants:raise UnsupportedDetail('burst-recipient target has no complete burst chain')
  row[:]=variants[0]
  expanded.extend((i,clone) for clone in variants[1:])
 for original,clone in expanded:
  index=len(program['effects']);program['effects'].append(clone)
  if index>=NE:raise UnsupportedDetail('more than 128 effects including burst-recipient instances')
  for row in program['effects']:
   if int(row[52+original//32])&(1<<(original%32)):row[52+index//32]=int(row[52+index//32])|1<<(index%32)
 # Charge-cover automatic reload is executed by the GPU state machine.
 return {'program':program,'base_stats':bs,'enemy':[enemy['def'],enemy['core_px']], 'prepared':prepared,'policy':policy,'requested_policy':requested_policy,'body':body}


def evaluate_full(device,compiled,module_backend='auto'):
 from types import SimpleNamespace
 import engine_worker as adapter
 prepared=compiled['prepared'];body=compiled['body'];duration=float(body.get('duration',180));script=[]
 for i in range(5):script.append([0,0,0,i,0,-1,0,0])
 for i in range(5):script.append([0,0,5,i,0,-1,0,0])
 t=0.0
 while t<=duration:
  script.append([t,4,0,0,0,-1,0,0]);t+=1/60
 # Log readback is data produced by GPU, not CPU-selected burst times.
 script.append([duration,5,0,0,0,-1,0,0])
 for i in range(256):script.append([duration,2,100,0,i,i,0,0])
 for i in range(5):script.append([duration,2,101,i,0,256+i,0,0])
 result=run(device,[compiled['program']],script,[compiled['enemy']],[compiled['base_stats']],module_backend=module_backend)
 totals=result['totals'][0];names=[c['name'] for c in compiled['program']['chars']]
 fake=SimpleNamespace(squad_total=sum(totals),char_total=dict(zip(names,totals)),duration=duration,log=None,boss_unmodeled={})
 payload=adapter.sim.payload(prepared,fake)
 logs=result['queries'][0];count=int(logs[0][3]);timeline=[]
 for row in logs[:count]:
  event=int(row[1]);who=int(row[2]);timeline.append({'time':round(row[0],3),'event':f'stage:{event} 사용' if event<4 else 'full_burst 시작' if event==4 else 'full_burst 종료','character':names[who] if who>=0 else ''})
 payload.update(base_stats=compiled['base_stats'],burst_policy=compiled['policy'],requested_burst_policy=compiled['requested_policy'],burst_patterns=prepared.config.get('burst_pattern',{}),burst_timeline=timeline,engine_revision=adapter.REVISION,hypothetical=any(any(body['profile']['chars'][n].get('equip_skills',{}).get(k)!=patch.get('equip_skills',{}).get(k) for k in patch.get('equip_skills',{})) for n,patch in body.get('patches',{}).items() if n in names) or any(any(v for v in f.values()) for f in body.get('stat_deltas',{}).values()),app_warnings=['固定条件の静止ボス・オート射撃を仮定した参考値です。ボス固有パターンと生存は未検証です。'],compute={'requested':'cuda_detail','backend':'cuda_detail','device':device.name,'elapsed_ms':result['elapsed_ms'],'initialization_ms':result['initialization_ms'],'module_backend':result['module_backend'],'workspace_bytes':result['workspace_bytes'],'scope':'five-member autonomous detailed simulation','parity':'regression-tested supported mechanics; not all characters'})
 payload['compute']['final_hp']={n:{'hp':logs[256+i][0],'hp_pct':logs[256+i][1],'max_hp':logs[256+i][2]} for i,n in enumerate(names)}
 if any(r[4]==4 and r[1]==0 and r[2] not in (2,3,12,27) for r in compiled['program']['effects']):payload['app_warnings'].append('敵対象の能力変化も固定CPU版の集計規則に合わせています。CPUとの一致は実機の正しさを保証しません。')
 if compiled['requested_policy']=='mast3' and compiled['policy']=='auto':payload['app_warnings'].append('マスト不在のため全員オートで計算しました。')
 if payload['hypothetical']:payload['app_warnings'].append('育成変更・仮ステータスを含む計算です。')
 if any(r[43]>=0 for r in compiled['program']['effects']):payload['app_warnings'].append('固定CPU版に合わせ、同名・同種の装備効果は最初の定義へ統合しています。異なるオバロ値の実機再現は保証できません。')
 return payload

