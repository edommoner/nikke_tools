// Detailed effect-state interpreter. Never skips an unsupported source construct.
// Event input is a stimulus program, not a CPU-computed buff/damage replay.
#define NE 128
#define EW 208
#define CW 40
#define ST 32
#define OW 48
#define EVS 8
#define TD 145
#define TS 7
__device__ double mx(double a,double b){return a>b?a:b;}
__device__ double mn(double a,double b){return a<b?a:b;}
struct State {
 int weapon_context[5],mode_started[5];double mode_ready[5];int gauge_present[5][NE];double gauges[5][NE],gauge_cap[5][NE];
 double when,timer_at[NE],timer_end[NE];int timer_active[NE],timer_seq[NE],entry_seq[NE],timer_clock,entry_clock,dot_present[NE],bullets[NE][6],bullet_stacks[NE][6],bullet_left[NE];
 int shield_mask[NE],hits[5],activations[NE];double hit_unit[5],frac[5][2];int cast_mask,heal_source,auto_reload[5],lazy_dirty,squad_mode,land_count,now_count,land_owner[1024],now_owner[NE];double land_damage[1024],now_damage[NE];double cached[5][58];double hp[5],hppct[5],hit[5];int pending[NE];unsigned int excluded[4];unsigned long long valid[5];int cached_full;
 double stacks[NE],end[NE],capture[NE],period_at[NE],activated[NE];int masks[NE],target_order[NE],count[NE][EVS];
 int mode[5],prev_mode[5],started[5],shots[5],charge_phase[5]; double charge_start[5],ready[5],cd_applied[5]; int phase,cycle,fb_caster,wait_mask,log_count,log_who[256],log_event[256]; double action,opened,gauge,fb_end,fb_cast_t,log_t[256]; double mode_end[5],total[5],warm[5],last[5],inter[5],next[5],ammo[5],reload[5],post[5];
};
// Export the compiler layout; the host never guesses CUDA struct padding.
extern "C" __device__ __constant__ unsigned int detail_state_bytes_v4=sizeof(State);
__device__ void invalidate(State* s){for(int i=0;i<5;i++)s->valid[i]=0;}
__device__ int target(const double* q,int n,State* s){
 int c=(int)q[0],kind=(int)q[4],arg=(int)q[5],mask=0;
 if(kind==0)return 1<<c;
 if(kind==1)return (1<<n)-1;
 if(kind==9)return s->cast_mask;
 if(kind==10)return ((1<<n)-1)^s->cast_mask;
 if(kind==2){for(int j=c+1;j<n&&j<=c+arg;j++)mask|=1<<j;return mask;}
 if(kind==3){mask=1<<c;int used=0;if(c>0&&used<arg){mask|=1<<(c-1);used++;}if(c+1<n&&used<arg)mask|=1<<(c+1);return mask;}
 if(kind>=5&&kind<=7)return -1;
 if(kind==8)return (int)q[48];
 if(kind==4)return 1<<5; // Single enemy sentinel.
 return 0;
}
__device__ double ref(const double* e,int ne,State* s,int owner,int name){
 if(name>=0&&name<NE&&s->gauge_present[owner][name])return (long long)s->gauges[owner][name];
 for(int j=0;j<ne;j++)if((int)e[j*EW]==owner&&(int)e[j*EW+3]==name&&(s->stacks[j]>0||s->dot_present[j]))return s->stacks[j];
 return 0;
}
__device__ double value(const double* e,int ne,State* s,int j){
 const double* q=e+j*EW;double v=q[6];
 if(q[10]>=0)v*=s->capture[j]>=0?s->capture[j]:ref(e,ne,s,(int)q[0],(int)q[10]);
 else if((int)q[9]!=1)v*=s->stacks[j];
 return v;
}
__device__ double recipient_value(const double* e,int ne,State* s,int j,int who){
 const double* q=e+j*EW;double v=value(e,ne,s,j);
 if(q[62]>=0&&q[9]!=1&&q[10]<0&&!(q[4]>=5&&q[4]<=7)&&s->stacks[j]>0)v=q[6]*s->bullet_stacks[j][who];
 return v;
}
__device__ int base_condition(const double* c,const double* e,int ne,State* s,const double* q,int full,int runtime);
__device__ void resolve_all(const double* c,const double* e,int ne,State* s,int full,int consume=0);
// Boolean charge lock lookup avoids a recursive stat() call and its large stack frame.
__device__ int charge_locked(const double* c,const double* e,int ne,State* s,int who,int full){
 for(int j=0;j<ne;j++){const double* q=e+j*EW;if(q[1]!=0||q[2]!=53||s->stacks[j]<=0||s->end[j]<=s->when||(s->excluded[j/32]&(1u<<(j%32))))continue;
  if((s->masks[j]&((1<<who)|(1<<5)))&&base_condition(c,e,ne,s,q,full,1))return 1;
 }return 0;
}
__device__ double stat(const double* c,const double* e,int ne,State* s,int who,int key,int full){
 resolve_all(c,e,ne,s,full);
 if(s->cached_full!=full){invalidate(s);s->cached_full=full;}
 if(s->valid[who]&(1ULL<<key))return s->cached[who][key];
 if(key==20&&charge_locked(c,e,ne,s,who,full))return 0;
 double out=key==5||key==24?.15:0;
 for(int j=0;j<ne;j++){
  const double* q=e+j*EW;if((int)q[1]!=0||s->stacks[j]<=0||s->end[j]<=s->when||(s->excluded[j/32]&(1u<<(j%32))))continue;
  int k=(int)q[2];int want=key;
  if(key==24&&k==22||key==25&&k==23)continue;
  if(key==24)want=5;if(key==25)want=6;
  int matches=(k==want)||(key==5&&k==22)||(key==6&&k==23)||(key==1&&k==26)||(key==20&&k==37)||(key==3&&k==46);
  if(!matches)continue;
  int mask=s->masks[j];if(!(mask&(1<<who))&&!(mask&(1<<5)))continue;
  // Pinned CPU applies most enemy-target stats through its generic attacker/target route.
  if(mask&(1<<5)){if(k==27||k==26)continue;}
  else if(k==12||k==2||k==3||k==46)continue;
  if(!base_condition(c,e,ne,s,q,full,1))continue;
  if(key==28||key==36||key==52||key==53){out=1;continue;}
  double v=recipient_value(e,ne,s,j,who);if(k==26)v=c[(int)q[0]*CW]*v/100;
  if(k==46)v=c[(int)q[0]*CW+30]*v/100;
  if(k==37){double raw=c[who*CW+29]>0?c[who*CW+29]:c[(int)q[0]*CW+29];v=raw>0?c[(int)q[0]*CW+29]*v/100/raw*100:0;}
  if(key==5||key==24)v/=100;
  out+=v;
 }
 s->cached[who][key]=out;s->valid[who]|=1ULL<<key;return out;
}
__device__ int base_condition(const double* c,const double* e,int ne,State* s,const double* q,int full,int runtime){
 for(int j=0;j<(int)q[14];j++){
  int type=(int)q[15+j*3],name=(int)q[16+j*3];double arg=q[17+j*3];int owner=(int)q[0];double v=0;
  // Only persistent self-state/full-burst predicates are reevaluated at query time.
  if(runtime && (q[7]>=0 || q[62]>=0 || (type!=1&&type!=2&&type!=3&&type!=4&&type!=5&&type!=9&&type!=10&&type!=11&&type!=12&&type!=14&&type!=15&&type!=16&&type!=17&&type!=18&&type!=19)))continue;
  if(type==1&&!full || type==2&&full)return 0;
  if(type>=18&&type<=21){v=s->gauges[owner][name];if(type==18&&v<arg||type==19&&v>=arg||type==20&&v!=arg)return 0;if(type==21){long long iv=(long long)v,m=(long long)arg;long long rem=((iv%m)+m)%m;if(rem!=(long long)q[66+j])return 0;}}
  if(type>=3&&type<=5){
   for(int k=0;k<ne;k++)if((int)e[k*EW+3]==name&&(s->stacks[k]>0||s->dot_present[k])&&s->masks[k]>=0){int mask=s->masks[k];if(type==5?(e[k*EW]==owner&&(mask&((1<<owner)|(1<<5)))):(mask&(1<<owner))){v=s->stacks[k];break;}}
   if(s->mode[owner]>=0&&(int)e[s->mode[owner]*EW+3]==name)v=1;
  }
  if(type==16||type==17){int found=0;for(int k=0;k<ne;k++)if((int)e[k*EW+3]==name&&(s->stacks[k]>0||s->dot_present[k])&&s->masks[k]>=0&&(s->masks[k]&(1<<5))){found=1;break;}if(type==16&&!found||type==17&&found)return 0;}
  if(type==3&&v<=0 || type==4&&v>0 || type==5&&v<arg)return 0;
  
  if(type==12){int shield=0;for(int k=0;k<ne;k++)if(e[k*EW+2]==45&&s->stacks[k]>0&&(s->shield_mask[k]&(1<<owner))){shield=1;break;}if(!shield)return 0;}
  if(type==13&&s->heal_source==owner)return 0;
  if(type==14&&!(s->cast_mask&(1<<owner))||type==15&&(s->cast_mask&(1<<owner)))return 0;
  if(type==6&&owner!=0&&owner!=2&&owner!=4)return 0;
  if(type==7&&owner!=1&&owner!=3)return 0;
  if(type==9&&s->hppct[owner]<arg||type==10&&s->hppct[owner]>arg||type==11&&s->hppct[owner]<100)return 0;
 }
 return 1;
}
__device__ int condition(const double* c,const double* e,int ne,State* s,const double* q,int full,int runtime){
 if(!base_condition(c,e,ne,s,q,full,runtime))return 0;
 if(!runtime)for(int j=0;j<(int)q[14];j++)if((int)q[15+j*3]==8&&stat(c,e,ne,s,(int)q[0],(int)q[16+j*3],full)<=q[17+j*3])return 0;
 return 1;
}
// Rank targets are resolved lazily once, using the same activation group as CPU.
__device__ double rank_atk(const double* c,const double* e,int ne,State* s,int who,int full){
 double pct=0,flat=0;
 for(int j=0;j<ne;j++){
  const double* q=e+j*EW;if(q[1]!=0||s->stacks[j]<=0||s->masks[j]<0||!(s->masks[j]&(1<<who))||!base_condition(c,e,ne,s,q,full,1))continue;
  double v=value(e,ne,s,j);if(q[2]==0)pct+=v;if(q[2]==1)flat+=v;if(q[2]==26)flat+=c[(int)q[0]*CW]*v/100;
 }
 return c[who*CW]*(1+pct/100)+flat;
}
__device__ int ranked_target(const double* c,const double* e,int ne,State* s,const double* q,int full,int* ordered=0){
 int mask=0,order=0,owner=(int)q[0],kind=(int)q[4];
 for(int pick=0;pick<(int)q[5];pick++){
  int best=-1;double bestv=0;
  for(int who=0;who<5;who++){
   if(mask&(1<<who)||q[49]>0&&who==owner)continue;
   double v=kind==5?rank_atk(c,e,ne,s,who,full):kind==6?c[who*CW+30]:-s->hppct[who];
   if(best<0||v>bestv){best=who;bestv=v;}
  }
  if(best<0)break;mask|=1<<best;order|=(best+1)<<(pick*3);
 }
 if(ordered)*ordered=order;return mask;
}
__device__ int filter_order(int raw,int mask){int order=0,shift=0;while(raw){int who=(raw&7)-1;raw>>=3;if(who>=0&&(mask&(1<<who))){order|=(who+1)<<shift;shift+=3;}}return order;}
// Pack ordered recipients in three-bit slots (one-based indices).
__device__ int recipient_order(const double* c,const double* e,int ne,State* s,const double* q,int mask,int full){
 int order=0,shift=0,kind=(int)q[4],owner=(int)q[0];
 if(q[141]>0){int raw=(int)q[140];while(raw){int who=(raw&7)-1;raw>>=3;if(who>=0&&(mask&(1<<who))){order|=(who+1)<<shift;shift+=3;}}return order;}
 if(kind==3){int list[3]={owner,owner-1,owner+1};for(int k=0;k<3;k++){int who=list[k];if(who>=0&&who<5&&(mask&(1<<who))){order|=(who+1)<<shift;shift+=3;}}return order;}
 while(mask&31){int best=-1;double bestv=0;
  for(int who=0;who<5;who++)if(mask&(1<<who)){double v=kind==5?rank_atk(c,e,ne,s,who,full):kind==6?c[who*CW+30]:kind==7?-s->hppct[who]:0;if(best<0||v>bestv){best=who;bestv=v;}}
  mask&=~(1<<best);order|=(best+1)<<shift;shift+=3;
 }return order;
}
__device__ void resolve_all(const double* c,const double* e,int ne,State* s,int full,int consume){
 if(!s->lazy_dirty&&!consume)return;
 for(int j=0;j<ne;j++)if(s->stacks[j]>0&&s->masks[j]<0&&(e[j*EW+207]>0||consume&&e[j*EW+62]>=0)){
  const double* q=e+j*EW;int found=-1;
  for(int k=0;k<ne;k++)if(k!=j&&s->masks[k]>=0&&s->activated[k]==s->activated[j]&&e[k*EW]==q[0]&&e[k*EW+4]==q[4]&&e[k*EW+5]==q[5]&&e[k*EW+49]==q[49]){found=s->masks[k];s->target_order[j]=s->target_order[k];break;}
  s->masks[j]=found>=0?found:ranked_target(c,e,ne,s,q,full,&s->target_order[j]);if(q[62]>=0&&s->bullet_left[j]>=0){for(int k=0;k<6;k++)s->bullets[j][k]=(s->masks[j]&(1<<k))?s->bullet_left[j]:0;s->bullet_left[j]=-1;}invalidate(s);
 }
 s->lazy_dirty=0;
}
__device__ double max_hp(const double* c,const double* e,int ne,State* s,int who,int full){
 double pct=0,flat=0;
 for(int j=0;j<ne;j++){
  const double* q=e+j*EW;if(s->stacks[j]<=0||s->masks[j]<0||!(s->masks[j]&(1<<who))||!base_condition(c,e,ne,s,q,full,1))continue;
  double v=value(e,ne,s,j);if(q[2]==38||q[2]==41)pct+=v;if(q[2]==39||q[2]==40)flat+=c[(int)q[0]*CW+28]*v/100;
 }
 return c[who*CW+28]*(1+pct/100)+flat;
}
__device__ void sync_hp(const double* c,const double* e,int ne,State* s,int who,int full){double m=max_hp(c,e,ne,s,who,full);if(m>0){s->hppct[who]=s->hp[who]/m*100;invalidate(s);}}
// Healing uses recipient-only live buffs, excluding generic enemy stat routing.
__device__ double heal_multiplier(const double* c,const double* e,int ne,State* s,int who,int full){
 resolve_all(c,e,ne,s,full);double pct=0;
 for(int j=0;j<ne;j++)if(e[j*EW+1]==0&&e[j*EW+2]==42&&s->stacks[j]>0&&s->end[j]>s->when&&s->masks[j]>=0&&(s->masks[j]&(1<<who))&&base_condition(c,e,ne,s,e+j*EW,full,1))pct+=value(e,ne,s,j);
 return mx(0,1+pct/100);
}
__device__ void health_activation(const double* c,const double* e,int ne,State* s,int j,int full,int explicit_mask=-2){
 const double* q=e+j*EW;int mask=explicit_mask==-2?s->masks[j]:explicit_mask;if(mask<0||q[1]!=0||q[2]<38||q[2]>41||(q[4]>=5&&q[4]<=7))return;
 double unit=value(e,ne,s,j)/s->stacks[j];
 for(int who=0;who<5;who++)if(mask&(1<<who)){
  if(q[2]==38||q[2]==39)s->hp[who]=mn(s->hp[who]+c[(int)q[0]*CW+28]*unit/100,max_hp(c,e,ne,s,who,full));
  sync_hp(c,e,ne,s,who,full);
 }
}
__device__ __noinline__ int notify(const double*,const double*,int,State*,const double*,double,int,int,int,int);
__device__ double full_ammo(const double*,const double*,int,State*,int,int);
__device__ int expire(const double* c,const double* e,State* s,int ne,const double* env,double t,int full){
 int removed[NE],masks[NE],n=0,code=0;
 for(int j=0;j<ne;j++)if(s->end[j]<=t&&(s->stacks[j]>0||s->dot_present[j])){removed[n]=j;masks[n++]=s->masks[j];s->stacks[j]=0;s->dot_present[j]=0;invalidate(s);}
 for(int k=1;k<n;k++){int j=removed[k],mask=masks[k],at=k;while(at>0&&s->entry_seq[j]<s->entry_seq[removed[at-1]]){removed[at]=removed[at-1];masks[at]=masks[at-1];at--;}removed[at]=j;masks[at]=mask;}
 for(int step=0;step<n;step++){
  int j=removed[step],mask=masks[step];
  if(e[j*EW+35]>0)code|=notify(c,e,ne,s,env,t,29,(int)e[j*EW],(int)e[j*EW+3],full);
  if(e[j*EW+2]==39||e[j*EW+2]==40)for(int who=0;who<5;who++)if(mask>=0&&(mask&(1<<who))){s->hp[who]=mn(s->hp[who],max_hp(c,e,ne,s,who,full));sync_hp(c,e,ne,s,who,full);}
 }
 for(int i=0;i<5;i++)if(s->mode_end[i]<=t&&s->mode[i]>=0){int j=s->mode[i];s->mode[i]=-1;invalidate(s);if(e[j*EW+35]>0)code|=notify(c,e,ne,s,env,t,29,i,(int)e[j*EW+3],full);}
 return code;
}
__device__ __noinline__ double damage(const double* c,const double* e,int ne,State* s,const double* env,int who,int full,double coeff,int normal,int flags){
 const double* a=c+who*CW;double b[ST];for(int k=0;k<ST;k++)b[k]=stat(c,e,ne,s,who,k,full);
 double defense=(flags&512)?0:mx(env[0]*(1+b[2]/100)+b[3],0)*(1-b[4]/100);double attack=mx(a[0]*(1+b[0]/100)+b[1]-defense,0);
 double crit=mn(normal?b[5]:b[24],1)*mx(.5+(normal?b[6]:b[25])/100,0);
 double spread=a[13];
 if(s->started[who])spread=a[10]>0?a[9]+(a[13]-a[9])*mn(s->warm[who],a[10])/a[10]:a[9];
 double core=(flags&16384)?1:(flags&256)?(env[1]>0?1:0):normal&&env[1]>0?mn(1,pow(env[1]/mx(spread*(1-.00908*b[21]),1),2.55)):0;
 double bonus=1+crit+(full?.5:0)+(normal&&(s->weapon_context[who]&&s->mode[who]>=0?e[s->mode[who]*EW+30]:a[14])>.5?.3:0)+core*(a[12]-100+b[7])/100;
 double f5=1+b[10]/100;
 if(flags&1){f5+=b[13]/100;if(flags&4096)f5+=stat(c,e,ne,s,who,56,full)/100;if(flags&8192)f5+=stat(c,e,ne,s,who,57,full)/100;}
 if(flags&64)f5+=stat(c,e,ne,s,who,35,full)/100;if(flags&512)f5+=stat(c,e,ne,s,who,51,full)/100;if(flags&128)f5+=stat(c,e,ne,s,who,50,full)/100;
 if(flags&8)f5+=b[16]/100;if(flags&4)f5+=b[15]/100;if(flags&2)f5+=b[14]/100;if(flags&1024)f5+=stat(c,e,ne,s,who,54,full)/100;if(flags&2048)f5+=stat(c,e,ne,s,who,55,full)/100;
 double f6=1+b[12]/100;if(flags&16)f6+=b[27]/100;
 double charge=(flags&32)?a[19]/100*(1+b[9]/100)+b[8]/100:1;
 double d=(coeff*(normal?1+b[11]/100:1)/100)*attack*bonus*charge*f5*f6*(a[15]>.5?1.1+b[17]/100:1);
 return mx((double)__double2ll_rn(d),1);
}
// Explicit bounded DFS preserves synchronous nested stack-reach order.
__device__ __noinline__ int notify(const double* c,const double* e,int ne,State* s,const double* env,double t,int ev,int who,int arg,int full){
 unsigned char ended[32][NE];int ended_count[32],ended_pos[32];for(int j=0;j<32;j++)ended_count[j]=ended_pos[j]=0;
 int gauge_id[32],gauge_owner[32],ammo_left[32],ammo_owner[32],named_event[32];double gauge_cursor[32],gauge_end[32];
 int post_row[32],post_phase[32],post_uid[32],post_new[32],post_changed[32],post_stack[32],post_mask[32],post_rawmask[32],post_order[32],post_raworder[32],post_lazy[32],queue_arg[32];for(int i=0;i<32;i++){post_row[i]=-1;queue_arg[i]=-1;}
 int repeat_row[32],repeat_left[32],repeat_passive[32];for(int i=0;i<32;i++)repeat_left[i]=0;
 int iev[32],iwho[32],iarg[32],icount[32],cursor[32],queue[32],queue_event[32],healrow[32];for(int j=0;j<32;j++){queue[j]=0;healrow[j]=-1;gauge_id[j]=-1;ammo_left[j]=0;named_event[j]=-1;}int depth=0;iev[0]=ev;iwho[0]=who;iarg[0]=arg;icount[0]=ev==9?(int)ref(e,ne,s,who,arg):0;cursor[0]=0;
 while(depth>=0){
  if(ended_pos[depth]<ended_count[depth]){
   if(depth==31)return 1;int k=ended[depth][ended_pos[depth]++];depth++;iev[depth]=29;iwho[depth]=(int)e[k*EW];iarg[depth]=(int)e[k*EW+3];icount[depth]=0;cursor[depth]=0;queue[depth]=0;healrow[depth]=-1;gauge_id[depth]=-1;ammo_left[depth]=0;named_event[depth]=-1;repeat_left[depth]=0;post_row[depth]=-1;queue_arg[depth]=-1;ended_count[depth]=ended_pos[depth]=0;continue;
  }
  if(gauge_id[depth]>=0){
   int gid=gauge_id[depth],gowner=gauge_owner[depth];double next=1e30;
   for(int k=0;k<ne;k++){const double* r=e+k*EW;if((int)r[0]!=gowner)continue;
    for(int a=0;a<(int)r[144];a++){const double* d=r+TD+a*TS;if(d[0]!=30||d[3]!=gid)continue;double step=d[1];double boundary=(floor(gauge_cursor[depth]/step)+1)*step;if(boundary<=gauge_end[depth]&&boundary<next)next=boundary;}
   }
   if(next<1e30){if(depth==31||next>2147483647||next<-2147483647)return 8;gauge_cursor[depth]=next;depth++;iev[depth]=30;iwho[depth]=gowner;iarg[depth]=gid;icount[depth]=(int)next;cursor[depth]=0;queue[depth]=0;healrow[depth]=-1;gauge_id[depth]=-1;ammo_left[depth]=0;named_event[depth]=-1;repeat_left[depth]=0;post_row[depth]=-1;queue_arg[depth]=-1;ended_count[depth]=ended_pos[depth]=0;continue;}
   gauge_id[depth]=-1;
  }
  if(ammo_left[depth]>0){
   if(depth==31)return 1;int attacker=ammo_owner[depth];ammo_left[depth]--;depth++;iev[depth]=26;iwho[depth]=attacker;iarg[depth]=0;icount[depth]=0;cursor[depth]=0;queue[depth]=0;healrow[depth]=-1;gauge_id[depth]=-1;ammo_left[depth]=0;named_event[depth]=-1;repeat_left[depth]=0;post_row[depth]=-1;queue_arg[depth]=-1;ended_count[depth]=ended_pos[depth]=0;continue;
  }
  if(named_event[depth]>=0){
   if(depth==31)return 1;int name=named_event[depth],caster=ammo_owner[depth];named_event[depth]=-1;depth++;iev[depth]=31;iwho[depth]=caster;iarg[depth]=name;icount[depth]=0;cursor[depth]=0;queue[depth]=0;healrow[depth]=-1;gauge_id[depth]=-1;ammo_left[depth]=0;named_event[depth]=-1;repeat_left[depth]=0;post_row[depth]=-1;queue_arg[depth]=-1;ended_count[depth]=ended_pos[depth]=0;continue;
  }
  if(queue[depth]){
   if(depth==31)return 1;int recipient=(queue[depth]&7)-1,event=queue_event[depth],source=queue_arg[depth];queue[depth]>>=3;
   if(healrow[depth]>=0){const double* heal=e+healrow[depth]*EW;source=(int)heal[0];double amount=heal[6];if(heal[10]>=0)amount*=ref(e,ne,s,source,(int)heal[10]);double base=heal[50]>0?max_hp(c,e,ne,s,source,full):c[recipient*CW+28];s->hp[recipient]=mn(s->hp[recipient]+base*amount/100*heal_multiplier(c,e,ne,s,recipient,full),max_hp(c,e,ne,s,recipient,full));sync_hp(c,e,ne,s,recipient,full);}
   depth++;iev[depth]=event;iwho[depth]=recipient;iarg[depth]=source;icount[depth]=0;cursor[depth]=0;queue[depth]=0;healrow[depth]=-1;gauge_id[depth]=-1;ammo_left[depth]=0;named_event[depth]=-1;repeat_left[depth]=0;post_row[depth]=-1;queue_arg[depth]=-1;continue;
  }
  if(post_row[depth]>=0){
   int r=post_row[depth],owner=(int)e[r*EW];const double* q=e+r*EW;
   int phase=post_phase[depth]++;
   if(phase==0&&!post_new[depth]&&q[9]!=1&&post_changed[depth]&&q[35]>0||phase==2&&post_new[depth]&&q[35]>0){
    if(depth==31)return 1;int stack=phase==2?1:post_stack[depth];depth++;iev[depth]=9;iwho[depth]=owner;iarg[depth]=(int)q[3];icount[depth]=stack;cursor[depth]=0;queue[depth]=0;healrow[depth]=-1;gauge_id[depth]=-1;ammo_left[depth]=0;named_event[depth]=-1;repeat_left[depth]=0;post_row[depth]=-1;queue_arg[depth]=-1;ended_count[depth]=ended_pos[depth]=0;continue;
   }
   if(phase==1&&(post_new[depth]||q[9]!=1)&&q[202]>0){
    int mask=post_mask[depth],order=post_order[depth];if(!post_new[depth]&&s->entry_seq[r]==post_uid[depth]){mask=s->masks[r];order=s->target_order[r];}
    queue[depth]=q[201]>0?(mask<0?owner+1:filter_order(order,mask)):22737;queue_event[depth]=(int)q[202]-1;queue_arg[depth]=(int)q[203];healrow[depth]=-1;continue;
   }
   if(phase==3){
    if(!post_new[depth]&&s->entry_seq[r]==post_uid[depth]&&s->stacks[r]>0){s->capture[r]=q[10]>=0&&q[7]>=0?ref(e,ne,s,owner,(int)q[10]):-1;invalidate(s);}
    if(q[204]>=0&&!post_lazy[depth]){queue[depth]=post_raworder[depth];queue_event[depth]=31;queue_arg[depth]=(int)q[204];healrow[depth]=-1;continue;}
   }
   if(phase==4&&q[1]==0&&q[2]==45&&!post_lazy[depth]&&post_rawmask[depth]&&s->stacks[r]>0){
    s->shield_mask[r]=max_hp(c,e,ne,s,owner,full)*value(e,ne,s,r)>0?s->masks[r]&31:0;invalidate(s);
    queue[depth]=s->target_order[r];queue_event[depth]=18;queue_arg[depth]=-1;healrow[depth]=-1;continue;
   }
   if(phase>=5){if(!post_lazy[depth]&&s->stacks[r]>0)health_activation(c,e,ne,s,r,full,post_rawmask[depth]);post_row[depth]=-1;}
   continue;
  }
  s->heal_source=iev[depth]==16?iarg[depth]:-1;
  if(cursor[depth]>=ne&&repeat_left[depth]<=0){depth--;continue;}
  int repeated=repeat_left[depth]>0;int j=repeated?repeat_row[depth]:cursor[depth]++;if(repeated)repeat_left[depth]--;const double* q=e+j*EW;int event=iev[depth],owner=(int)q[0];
  if(event==28){if(j!=iarg[depth])continue;}else{
  if(event!=26&&owner!=iwho[depth])continue;
  int matched=repeated,passive=repeated?repeat_passive[depth]:0,multiplicity=0;
  // CPU indexes each timing separately, including duplicate event keys. Count
  // once per notification, then replay each indexed activation synchronously.
  if(!repeated)for(int a=0;a<(int)q[144];a++){
   const double* d=q+TD+a*TS;if((int)d[0]!=event)continue;
   int threshold=(int)d[1],mode=(int)d[2];
   if(event==4&&iarg[depth]!=(int)d[6])continue;
   if(event==6&&iarg[depth]!=j)continue;
   if((event==9||event==29||event==30||event==31)&&(int)d[3]!=iarg[depth])continue;
   if(event==9&&icount[depth]!=(int)d[4])continue;
   if(event==27&&iarg[depth]!=threshold)continue;
   multiplicity++;int ok=1;
   if(event==7||event==8||mode>0){s->count[j][a]++;int ct=s->count[j][a];ok=mode==2?ct>=threshold:mode==3?ct==threshold:ct%threshold==0;}
   if(event==30&&icount[depth]%threshold!=0)ok=0;
   if(ok&&!matched){matched=1;passive=(int)d[5];}
  }
  if(!matched)continue;
  if(!repeated&&event!=6&&multiplicity>1){repeat_row[depth]=j;repeat_left[depth]=multiplicity-1;repeat_passive[depth]=passive;}
  if(!(event==0 && q[7]<0 && passive) && !condition(c,e,ne,s,q,full,0))continue;
  if(q[56]>0&&s->cast_mask!=(int)q[56]-1)continue;
  }
  int mask=target(q,5,s),kind=(int)q[1];if(mask<0&&kind!=0&&kind!=4)mask=ranked_target(c,e,ne,s,q,full);if(!mask&&q[57]>=0)continue;
  int budget=(int)q[58];if(event!=28||q[69]>0){if(q[57]>=0&&s->activations[budget]>=q[57])continue;s->activations[budget]++;}
  if(q[59]>0&&event!=28){
   double expires=q[7]<0?1e30:t+q[7];int original=j;
   if(kind==3&&(int(q[39])&128)&&q[9]==1)for(int k=0;k<ne;k++)if(k!=j&&e[k*EW]==owner&&e[k*EW+3]==q[3]&&(int(e[k*EW+39])&128)&&e[k*EW+9]==1&&s->dot_present[k]&&s->timer_active[k]){j=k;q=e+j*EW;break;}
   int was=s->timer_active[j];if(!was)s->timer_seq[j]=++s->timer_clock;
   if(!(kind==3&&(int(q[39])&128)&&was))s->timer_at[j]=t+(kind==3&&q[60]>0?0:q[59]);
   s->timer_active[j]=1;s->timer_end[j]=expires;
   if(kind==3){
    int had=s->dot_present[j];if(!had){s->entry_seq[j]=++s->entry_clock;s->activated[j]=t;}
    double stack=1;if(q[10]>=0){if(s->gauge_present[owner][(int)q[10]])stack=ref(e,ne,s,owner,(int)q[10]);else for(int k=0;k<ne;k++)if(e[k*EW]==owner&&e[k*EW+3]==q[10]&&(s->stacks[k]>0||s->dot_present[k])){stack=s->stacks[k];break;}}
    if(q[10]>=0)s->stacks[j]=stack;else if(!had)s->stacks[j]=1;else s->stacks[j]=q[9]<0?s->stacks[j]+1:mn(s->stacks[j]+1,q[9]);
    s->dot_present[j]=1;s->end[j]=expires;s->masks[j]=mask;s->capture[j]=-1;if(mask<0)s->lazy_dirty=1;invalidate(s);
   }
   continue;
  }
  if(kind>=9&&kind<=11){
   int gid=(int)q[64];if(q[65]>=0)s->gauge_cap[owner][gid]=q[65];double old=s->gauges[owner][gid],now,consumed=q[6]==-1?old:mn(q[6],old);
   if(kind==9){double cap=s->gauge_cap[owner][gid];for(int k=0;k<ne;k++)if(e[k*EW]==owner&&e[k*EW+1]==12&&e[k*EW+64]==gid&&s->stacks[k]>0)cap+=e[k*EW+70];now=mn(old+q[6],cap);}
   else now=q[6]==-1?0:mx(0,old-q[6]);
   s->gauges[owner][gid]=now;s->gauge_present[owner][gid]=1;invalidate(s);
   if(kind==9&&now>old){gauge_id[depth]=gid;gauge_owner[depth]=owner;gauge_cursor[depth]=old;gauge_end[depth]=now;}
   if(kind==11&&consumed>0){if(consumed>2147483647)return 8;ammo_left[depth]=(int)consumed;ammo_owner[depth]=owner;}
   continue;
  }
  if(kind==13||kind==14){
   for(int recipient=0;recipient<5;recipient++)if(mask&(1<<recipient)){
    double maximum=full_ammo(c,e,ne,s,recipient,full);
    double v=q[6];double add=kind==13?(double)__double2ll_rn(maximum*(v/100)):(double)(long long)v;
    s->ammo[recipient]=kind==13?mx(0,mn(s->ammo[recipient]+add,maximum)):mn(s->ammo[recipient]+add,maximum);
   }
   if(kind==13&&q[202]>0){queue[depth]=owner+1;queue_event[depth]=(int)q[202]-1;queue_arg[depth]=(int)q[203];healrow[depth]=-1;}continue;
  }
  if(kind==8){for(int recipient=0;recipient<5;recipient++)if(mask&(1<<recipient)){s->hp[recipient]=mx(0,s->hp[recipient]*(1-q[6]/100));sync_hp(c,e,ne,s,recipient,full);}continue;}
  if(kind==7){if(q[6]!=0){queue[depth]=recipient_order(c,e,ne,s,q,mask,full);queue_event[depth]=17;queue_arg[depth]=-1;healrow[depth]=-1;}continue;}
  if(kind==6){queue[depth]=recipient_order(c,e,ne,s,q,mask,full);queue_event[depth]=16;queue_arg[depth]=-1;healrow[depth]=j;continue;}
  if(kind==5){for(int k=0;k<5;k++)if(mask&(1<<k))s->ready[k]=mx(t,s->ready[k]-q[6]);continue;}
  if(kind==1){
   invalidate(s);ended_count[depth]=ended_pos[depth]=0;
   for(int k=0;k<ne;k++)if((int)e[k*EW+3]==(int)q[36]&&(s->stacks[k]>0||s->dot_present[k])){
    // Match CPU target-list removal: lazy states stay unresolved, shield/bullet maps persist while the instance survives.
    if(q[142]>0){if(s->masks[k]<0||!(s->masks[k]&mask))continue;s->masks[k]&=~mask;s->target_order[k]=filter_order(s->target_order[k],s->masks[k]);for(int f=0;f<=depth;f++)if(post_row[f]==k&&post_uid[f]==s->entry_seq[k]){post_mask[f]=s->masks[k];post_order[f]=s->target_order[k];}if(s->masks[k])continue;}
    s->stacks[k]=0;s->dot_present[k]=0;s->timer_active[k]=0;if(q[142]<=0&&e[k*EW+35]<=0)continue;int at=ended_count[depth]++;
    while(at>0&&s->entry_seq[k]<s->entry_seq[ended[depth][at-1]]){ended[depth][at]=ended[depth][at-1];at--;}ended[depth][at]=(unsigned char)k;
   }continue;
  }
  if(kind==15){
   for(int k=0;k<ne;k++)if((s->stacks[k]>0||s->dot_present[k])&&s->end[k]<1e30&&s->masks[k]>=0&&(s->masks[k]&mask)){
    int name=(int)e[k*EW+3],word=name/32,slot=word==0?36:word==1?47:word==2?142:143;
    if((unsigned int)q[slot]&(1u<<(name%32))){s->end[k]+=q[6];if(s->dot_present[k]&&s->timer_active[k])s->timer_end[k]=s->end[k];invalidate(s);}
   }continue;
  }
  if(kind==2){invalidate(s);s->mode[owner]=j;s->mode_end[owner]=q[7]<0?1e30:t+q[7];if(q[202]>0){queue[depth]=22737;queue_event[depth]=(int)q[202]-1;queue_arg[depth]=(int)q[203];healrow[depth]=-1;}continue;}
  if(kind==3){
   if(q[6]==0)continue;if(q[51]>0){s->pending[j]=1;continue;}
   double v=q[6];if((int(q[39])&128)&&(q[10]>=0||q[10]==-2))v*=s->stacks[j];
   int count=(int)q[61];if(q[136]>=0){int name=(int)q[136],found=s->gauge_present[owner][name];if(q[137]==2)count=found?(int)s->gauges[owner][name]:0;else{for(int k=0;k<ne&&!found;k++)if(e[k*EW]==owner&&e[k*EW+3]==name&&(s->stacks[k]>0||s->dot_present[k]))found=1;count=found?(int)ref(e,ne,s,owner,name):1;}}
   if(count>4096)return 8;if(v==0)continue;for(int hitno=0;hitno<count;hitno++){
    double hit=damage(c,e,ne,s,env,owner,full,v,(int(q[39])&256)?1:0,(int)q[39]);s->total[owner]+=hit;
    if(s->squad_mode){if(s->land_count>=1024)return 4;int k=s->land_count++;s->land_owner[k]=owner;s->land_damage[k]=hit;}
   }continue;
  }
  int rawmask=mask,raworder=mask>=0?recipient_order(c,e,ne,s,q,mask,full):0;
  double expires=q[7]<0?1e30:t+q[7];
  if(q[43]>=0){j=(int)q[43];q=e+j*EW;}
  else if(s->stacks[j]<=0&&q[205]>0&&q[35]>0){
   int best=-1;for(int k=0;k<ne;k++){const double* other=e+k*EW;if(k==j||s->stacks[k]<=0||s->end[k]<=t||other[205]<=0||other[0]!=q[0]||other[3]!=q[3]||other[206]!=q[206]||other[9]!=q[9])continue;
    int same=rawmask<0?(other[4]==q[4]&&other[5]==q[5]&&other[49]==q[49]):(s->masks[k]==rawmask&&s->target_order[k]==raworder);
    if(same&&(best<0||s->entry_seq[k]<s->entry_seq[best]))best=k;
   }if(best>=0){j=best;q=e+j*EW;}
  }
  invalidate(s);double previous=s->stacks[j];int order=raworder;if(mask<0&&previous>0&&s->masks[j]>=0){mask=s->masks[j];order=s->target_order[j];}
  if(s->stacks[j]<=0){s->entry_seq[j]=++s->entry_clock;s->stacks[j]=1;}else s->stacks[j]=q[9]<0?s->stacks[j]+1:mn(s->stacks[j]+1,q[9]);
  s->activated[j]=t;s->masks[j]=mask;s->target_order[j]=order;if(mask<0)s->lazy_dirty=1;s->end[j]=expires;if(previous<=0)s->capture[j]=q[10]>=0&&q[7]>=0?ref(e,ne,s,owner,(int)q[10]):-1;
  if(q[62]>=0){
   int lazy=q[4]>=5&&q[4]<=7;
   if(!lazy){for(int k=0;k<6;k++){int had=previous>0&&s->bullets[j][k]>0;if(mask>=0&&(mask&(1<<k))){s->bullets[j][k]=(int)q[62];s->bullet_stacks[j][k]=had?(q[9]<0?s->bullet_stacks[j][k]+1:(int)mn(s->bullet_stacks[j][k]+1,q[9])):1;}else{s->bullets[j][k]=0;s->bullet_stacks[j][k]=0;}}s->bullet_left[j]=-1;}
   else{if(previous<=0)for(int k=0;k<6;k++)s->bullets[j][k]=0;s->bullet_left[j]=(int)q[62];}
  }
  post_row[depth]=j;post_phase[depth]=0;post_uid[depth]=s->entry_seq[j];post_new[depth]=previous<=0;post_changed[depth]=previous!=s->stacks[j];post_stack[depth]=(int)s->stacks[j];post_mask[depth]=mask;post_order[depth]=order;post_rawmask[depth]=rawmask;post_raworder[depth]=raworder;post_lazy[depth]=q[4]>=5&&q[4]<=7;
 }
 return 0;
}
// All clocks are authored input times. Timers select their own due times and
// preserve dictionary insertion order, without CPU event traces.
__device__ __noinline__ int tick_effects(const double* c,const double* e,int ne,State* s,const double* env,double t,int full){
 int code=0,touched=0;int visited[NE];for(int j=0;j<ne;j++)visited[j]=0;
 for(int pass=0;pass<ne;pass++){
  int best=-1;for(int j=0;j<ne;j++)if(!visited[j]&&s->timer_active[j]&&e[j*EW+1]==3)if(best<0||s->timer_seq[j]<s->timer_seq[best])best=j;
  if(best<0)break;int j=best;visited[j]=1;const double* q=e+j*EW;
  double end=s->timer_end[j],limit=q[60]>0?end-1e-6:end+1e-6;
  if(s->timer_at[j]>limit){s->timer_active[j]=0;continue;}
  if(t<s->timer_at[j])continue;
  double when=t>=end?end-1e-4:t;s->when=when;touched=1;invalidate(s);
  code|=notify(c,e,ne,s,env,when,28,(int)q[0],j,full);
  s->timer_at[j]+=q[59];
 }
 s->when=t;if(touched)invalidate(s);code|=expire(c,e,s,ne,env,t,full);
 for(int j=0;j<ne;j++){const double* q=e+j*EW;if(q[69]<=0||!condition(c,e,ne,s,q,full,0))continue;
  if(s->stacks[j]<=0)code|=notify(c,e,ne,s,env,t,28,(int)q[0],j,full);
  else{double old=s->end[j];s->end[j]=mx(old,t+q[7]);if(old<=t&&s->end[j]>t)invalidate(s);}
 }
 for(int j=0;j<ne;j++)if(e[j*EW+44]>0&&t>=s->period_at[j]){s->period_at[j]+=e[j*EW+44];code|=notify(c,e,ne,s,env,t,6,(int)e[j*EW],j,full);}
 for(int j=0;j<ne;j++)visited[j]=0;
 for(int pass=0;pass<ne;pass++){
  int best=-1;for(int j=0;j<ne;j++)if(!visited[j]&&s->timer_active[j]&&e[j*EW+1]!=3)if(best<0||s->timer_seq[j]<s->timer_seq[best])best=j;
  if(best<0)break;int j=best;visited[j]=1;const double* q=e+j*EW;
  if(t>=s->timer_end[j]){s->timer_active[j]=0;continue;}
  if(t<s->timer_at[j])continue;
  if(q[60]!=2||base_condition(c,e,ne,s,q,full,1))code|=notify(c,e,ne,s,env,t,28,(int)q[0],j,full);
  // A synchronous nested event can remove its own timer; do not resurrect it.
  if(s->timer_active[j])s->timer_at[j]+=q[59];
 }
 return code;
}
__device__ __noinline__ int consume_bullets(const double* c,const double* e,int ne,State* s,const double* env,double t,int who,int full){
 resolve_all(c,e,ne,s,full,1);int removed[NE],n=0,code=0;
 for(int j=0;j<ne;j++){
  const double* q=e+j*EW;if(q[62]<0||s->stacks[j]<=0||s->activated[j]==t&&q[63]==0)continue;
  if(s->bullets[j][who]>0){
   s->bullets[j][who]--;if(s->bullets[j][who]==0){s->masks[j]&=~(1<<who);invalidate(s);int left=0;for(int k=0;k<6;k++)if(s->bullets[j][k]>0)left=1;if(!left){s->stacks[j]=0;removed[n++]=j;}}
  }else if(q[0]==who&&s->bullet_left[j]>=0){s->bullet_left[j]--;if(s->bullet_left[j]<=0){s->stacks[j]=0;removed[n++]=j;invalidate(s);}}
 }
 for(int k=1;k<n;k++){int j=removed[k],at=k;while(at>0&&s->entry_seq[j]<s->entry_seq[removed[at-1]]){removed[at]=removed[at-1];at--;}removed[at]=j;}
 for(int pass=0;pass<n;pass++){int j=removed[pass];if(e[j*EW+35]>0)code|=notify(c,e,ne,s,env,t,29,(int)e[j*EW],(int)e[j*EW+3],full);}
 return code;
}
// Equipment entries with equal source/type/level are one rounding group.
__device__ double quant(const double* c,const double* e,int ne,State* s,int who,int key,int full,double base,double step){
 resolve_all(c,e,ne,s,full);if(key==20&&stat(c,e,ne,s,who,53,full)>0)return 0;double out=0;
 for(int j=0;j<ne;j++){
  const double* q=e+j*EW;if((int)q[1]!=0||((int)q[2]!=key&&!(key==20&&q[2]==37))||s->stacks[j]<=0||s->end[j]<=s->when||!(s->masks[j]&(1<<who))||!condition(c,e,ne,s,q,full,1))continue;
  int seen=0;double v=0;
  for(int k=0;k<ne;k++)if((int)e[k*EW+1]==0&&((int)e[k*EW+2]==key||(key==20&&e[k*EW+2]==37))&&e[k*EW+45]==q[45]&&s->stacks[k]>0&&s->end[k]>s->when&&(s->masks[k]&(1<<who))&&condition(c,e,ne,s,e+k*EW,full,1)){if(k<j)seen=1;double part=recipient_value(e,ne,s,k,who);if(e[k*EW+2]==37){double raw=c[who*CW+29]>0?c[who*CW+29]:c[(int)e[k*EW]*CW+29];part=raw>0?c[(int)e[k*EW]*CW+29]*part/100/raw*100:0;}v+=part;}
  if(!seen)out+=floor(base*(v/100)/step+.5)*step;
 }
 return out;
}
__device__ double full_ammo(const double* c,const double* e,int ne,State* s,int who,int full){
 double base=s->weapon_context[who]?999999:c[who*CW+2];return mx(1,base+quant(c,e,ne,s,who,18,full,base,1)+(double)__double2ll_rn(stat(c,e,ne,s,who,33,full)));
}
__device__ double charge_duration(const double* c,const double* e,int ne,State* s,int who,int full){
 const double* a=c+who*CW;double cut=quant(c,e,ne,s,who,20,full,a[16],.01);
 double charge=mx(0,mx(0,a[16]-cut)+stat(c,e,ne,s,who,34,full));
 if(stat(c,e,ne,s,who,53,full)>0){int best=-1;charge=a[16];for(int k=0;k<ne;k++)if(e[k*EW]==who&&e[k*EW+2]==53&&s->stacks[k]>0&&e[k*EW+139]>0){if(best<0||s->activated[k]>s->activated[best]||s->activated[k]==s->activated[best]&&s->entry_seq[k]>s->entry_seq[best])best=k;}if(best>=0)charge=e[best*EW+138];}
 return charge;
}
// Per-pellet events use deterministic fractional accumulators in expected mode.
__device__ int fractional(const double* c,const double* e,int ne,State* s,const double* env,double t,int who,int full,int ev,double part){
 if(part<=0)return 0;if(part>=1)return notify(c,e,ne,s,env,t,ev,who,0,full);
 int index=ev==22?0:1; s->frac[who][index]+=part;int code=0;
 while(s->frac[who][index]>=1){s->frac[who][index]-=1;code|=notify(c,e,ne,s,env,t,ev,who,0,full);}return code;
}
__device__ double core_probability(const double* c,const double* e,int ne,State* s,const double* env,int who,int full){
 const double* a=c+who*CW;double spread=a[13];if(s->started[who])spread=a[10]>0?a[9]+(a[13]-a[9])*mn(s->warm[who],a[10])/a[10]:a[9];
 return env[1]>0?mn(1,pow(env[1]/mx(spread*(1-.00908*stat(c,e,ne,s,who,21,full)),1),2.55)):0;
}
__device__ int pellets(const double* c,const double* e,int ne,State* s,int who,int full){
 double fixed=stat(c,e,ne,s,who,48,full);return fixed>0?(int)mx(1,(double)__double2ll_rn(fixed)):(int)mx(1,(s->weapon_context[who]&&s->mode[who]>=0?e[s->mode[who]*EW+25]:c[who*CW+32])+(double)__double2ll_rn(stat(c,e,ne,s,who,47,full)));
}
__device__ double reload_duration(const double* c,const double* e,int ne,State* s,int who,int full){return c[who*CW+3]*mx(0,1-stat(c,e,ne,s,who,19,full)/100);}
// A clip fills a rounded fraction of the current full magazine; only its final
// completion emits full_reload. Even a zero-duration next clip waits a frame.
__device__ int finish_clip(const double* c,const double* e,int ne,State* s,int who,int full,double t){
 double fullmag=full_ammo(c,e,ne,s,who,full),ratio=mn(1,mx(0,1+stat(c,e,ne,s,who,49,full)/100)/c[who*CW+34]);
 if(ratio<1){s->ammo[who]=mn(fullmag,s->ammo[who]+mx(1,floor(fullmag*ratio+.5)));if(s->ammo[who]<fullmag){s->reload[who]=t+reload_duration(c,e,ne,s,who,full);return 0;}}
 else s->ammo[who]=fullmag;
 s->reload[who]=-1;return 1;
}
__device__ int auto_frame(const double* c,const double* e,int ne,State* s,const double* env,double t,int who,int full){
 const double* a=c+who*CW;int mode=s->mode[who],prior=s->prev_mode[who];int status=0;
 if(stat(c,e,ne,s,who,28,full)>0)return status;
 if(!s->started[who]){s->started[who]=1;s->ammo[who]=full_ammo(c,e,ne,s,who,full);}
 if(mode<0){
  if(s->reload[who]<0)s->ammo[who]=mn(s->ammo[who],full_ammo(c,e,ne,s,who,full));
  if(s->reload[who]>=0){if(t<s->reload[who])return status;if(!finish_clip(c,e,ne,s,who,full,t))return status;status|=notify(c,e,ne,s,env,t,19,who,0,full);if(a[7]>0)s->post[who]=t+a[7];else s->next[who]=t;}
  if(s->post[who]>0){if(t<s->post[who])return status;s->post[who]=-1;s->next[who]=t;}
 }
 double rate=mode>=0?e[mode*EW+28]:a[4],maxrate=mode>=0?e[mode*EW+24]:a[5];
 double warmcap=mode>=0?e[mode*EW+40]:a[6],cool=mode>=0?e[mode*EW+41]:a[11];
 if((mode>=0||a[8]==2) && s->warm[who]>0){double idle=t-s->last[who];double inter=s->inter[who]>0?s->inter[who]:1/mx(rate,.01);if(idle>inter*1.5){s->warm[who]=mx(0,s->warm[who]-warmcap/cool*idle);s->last[who]=t;}}
 if(t<s->next[who])return status;
 if(mode<0&&s->ammo[who]<=0){s->reload[who]=t+reload_duration(c,e,ne,s,who,full);return status;}
 double fr=(mode>=0||a[8]==2)?rate+(maxrate-rate)*mn(s->warm[who],warmcap)/warmcap:rate;
 fr*=mx(.01,1+stat(c,e,ne,s,who,30,full)/100);
 int is_last=mode<0&&s->ammo[who]==1;if(is_last)status|=notify(c,e,ne,s,env,t,21,who,0,full);
 double cap=mx(warmcap,a[10]);if((mode>=0||a[8]==2||a[10]>0)&&s->warm[who]<cap)s->warm[who]=mn(cap,s->warm[who]+mx(0,1+stat(c,e,ne,s,who,31,full)/100));
 s->ammo[who]--;status|=notify(c,e,ne,s,env,t,26,who,0,full);
 int split=pellets(c,e,ne,s,who,full),muzzles=(int)(mode>=0?e[mode*EW+29]:a[33]),count=split*muzzles;if(count>512)return 8;
 double coeff=(mode>=0?e[mode*EW+26]:a[1])/split;
 double one=damage(c,e,ne,s,env,who,full,coeff,1,(stat(c,e,ne,s,who,36,full)>0?64:0)|(stat(c,e,ne,s,who,52,full)>0?512:0));
 double crit=mn(stat(c,e,ne,s,who,5,full),1),core=core_probability(c,e,ne,s,env,who,full);
 s->hit_unit[who]=one;s->hits[who]=count;s->hit[who]=one*count;s->total[who]+=s->hit[who];s->shots[who]++;
 for(int hit=0;hit<count;hit++){status|=notify(c,e,ne,s,env,t,20,who,0,full);status|=fractional(c,e,ne,s,env,t,who,full,22,crit);status|=fractional(c,e,ne,s,env,t,who,full,23,core);}
 int previous_threshold=0;
 for(int pass=0;pass<NE*EVS;pass++){
  int threshold=2147483647;
  for(int j=0;j<ne;j++){const double* q=e+j*EW;if((int)q[0]!=who)continue;for(int a=0;a<(int)q[144];a++){const double* d=q+TD+a*TS;if(d[0]==27&&d[1]>previous_threshold&&d[1]<=count&&d[1]<threshold)threshold=(int)d[1];}}
  if(threshold==2147483647)break;status|=notify(c,e,ne,s,env,t,27,who,threshold,full);previous_threshold=threshold;
 }
 status|=notify(c,e,ne,s,env,t,7,who,0,full);for(int k=0;k<muzzles;k++)status|=notify(c,e,ne,s,env,t,8,who,0,full);
 status|=consume_bullets(c,e,ne,s,env,t,who,full);
 if(is_last)for(int k=0;k<muzzles;k++)status|=notify(c,e,ne,s,env,t,14,who,0,full);
 s->next[who]+=1/fr;
 if(mode>=0||a[8]==2){s->last[who]=t;s->inter[who]=1/fr;}
 if(s->next[who]<=t)s->next[who]=t;
 return status;
}
__device__ int charge_frame(const double* c,const double* e,int ne,State* s,const double* env,double t,int who,int full){
 const double* a=c+who*CW;int code=0;if(stat(c,e,ne,s,who,28,full)>0)return code;
 if(!s->started[who]){s->started[who]=1;s->ammo[who]=full_ammo(c,e,ne,s,who,full);}
 s->ammo[who]=mn(s->ammo[who],full_ammo(c,e,ne,s,who,full));
 if(s->reload[who]>=0){if(t<s->reload[who])return code;if(!finish_clip(c,e,ne,s,who,full,t))return code;code|=notify(c,e,ne,s,env,t,19,who,0,full);s->post[who]=a[7]>0?t+a[7]:-1;}
 if(s->post[who]>0){if(t<s->post[who])return code;s->post[who]=-1;}
 if(s->charge_phase[who]==2){if(t<s->next[who])return code;if(s->auto_reload[who]){s->auto_reload[who]=0;s->ammo[who]=full_ammo(c,e,ne,s,who,full);code|=notify(c,e,ne,s,env,t,19,who,0,full);}s->charge_phase[who]=0;}
 if(s->charge_phase[who]==0){
  if(s->ammo[who]<=0){s->reload[who]=t+reload_duration(c,e,ne,s,who,full);return code;}
  s->charge_start[who]=t;s->charge_phase[who]=1;
  if(s->ammo[who]==1)code|=notify(c,e,ne,s,env,t,21,who,0,full);
 }
 double charge=charge_duration(c,e,ne,s,who,full);
 if(t<s->charge_start[who]+charge)return code;
 code|=notify(c,e,ne,s,env,t,10,who,0,full);
 int auto_reload=a[31]>0&&stat(c,e,ne,s,who,19,full)>=100;
 int split=pellets(c,e,ne,s,who,full),muzzles=(int)a[33],count=split*muzzles;if(count>512)return 8;
 double one=damage(c,e,ne,s,env,who,full,a[1]/split,1,32|((int)a[26]?8:0)|(stat(c,e,ne,s,who,36,full)>0?64:0)|(stat(c,e,ne,s,who,52,full)>0?512:0));
 double crit=mn(stat(c,e,ne,s,who,5,full),1),core=core_probability(c,e,ne,s,env,who,full);
 s->hit_unit[who]=one;s->hits[who]=count;s->hit[who]=one*count;s->total[who]+=s->hit[who];s->shots[who]++;
 if(count>1)for(int k=0;k<count;k++)code|=notify(c,e,ne,s,env,t,20,who,0,full);
 int is_last=s->ammo[who]==1;s->ammo[who]--;code|=notify(c,e,ne,s,env,t,26,who,0,full);
 code|=notify(c,e,ne,s,env,t,7,who,0,full);code|=notify(c,e,ne,s,env,t,11,who,0,full);
 for(int k=0;k<muzzles;k++)code|=notify(c,e,ne,s,env,t,8,who,0,full);
 for(int k=0;k<muzzles;k++)code|=notify(c,e,ne,s,env,t,12,who,0,full);
 code|=consume_bullets(c,e,ne,s,env,t,who,full);
 for(int k=0;k<count;k++)code|=fractional(c,e,ne,s,env,t,who,full,22,crit);
 for(int k=0;k<count;k++)code|=fractional(c,e,ne,s,env,t,who,full,23,core);
 if(is_last)for(int k=0;k<muzzles;k++)code|=notify(c,e,ne,s,env,t,14,who,0,full);
 s->next[who]=mx(t+a[17],s->charge_start[who]+a[18]);s->charge_phase[who]=2;s->auto_reload[who]=auto_reload;
 return code;
}
__device__ int weapon_frame(const double* c,const double* e,int ne,State* s,const double* env,double t,int who,int full){
 if(stat(c,e,ne,s,who,28,full)>0)return 0;
 if(!s->started[who]){s->started[who]=1;s->ammo[who]=full_ammo(c,e,ne,s,who,full);}
 int mode=s->mode[who],prior=s->prev_mode[who];
 if(mode>=0&&prior<0){s->mode_ready[who]=t+e[mode*EW+42];s->mode_started[who]=0;}
 s->prev_mode[who]=mode;
 if(mode>=0){if(t<s->mode_ready[who])return 0;if(!s->mode_started[who]){s->ammo[who]=999999;s->next[who]=t;s->mode_started[who]=1;}}
 if(mode<0&&prior>=0){s->ammo[who]=full_ammo(c,e,ne,s,who,full);s->next[who]=t;if(c[who*CW+8]==3)s->charge_phase[who]=0;}
 s->weapon_context[who]=mode>=0;
 int code=mode<0&&c[who*CW+8]==3?charge_frame(c,e,ne,s,env,t,who,full):auto_frame(c,e,ne,s,env,t,who,full);
 s->weapon_context[who]=0;return code;
}
__device__ int log_burst(State* s,double t,int event,int who){
 if(s->log_count>=256)return 2;int j=s->log_count++;s->log_t[j]=t;s->log_event[j]=event;s->log_who[j]=who;return 0;
}
// Skill hits land at the next frame's dot-event drain, preserving HP-trigger timing.
__device__ int heal_landed(const double* c,const double* e,int ne,State* s,const double* env,double t,int full,int who,double hit){
 if(hit<=0)return 0;double ls=stat(c,e,ne,s,who,44,full);if(ls<=0)return 0;
 s->hp[who]=mn(s->hp[who]+hit*ls/100*heal_multiplier(c,e,ne,s,who,full),max_hp(c,e,ne,s,who,full));sync_hp(c,e,ne,s,who,full);
 return notify(c,e,ne,s,env,t,16,who,who,full);
}
__device__ int flush_lands(const double* c,const double* e,int ne,State* s,const double* env,double t,int full){
 int code=0;for(int k=0;k<s->land_count;k++)code|=heal_landed(c,e,ne,s,env,t,full,s->land_owner[k],s->land_damage[k]);s->land_count=0;return code;
}
__device__ int squad_frame(const double* c,const double* e,int ne,State* s,const double* env,double t,int* full){
 int code=tick_effects(c,e,ne,s,env,t,*full);
 code|=flush_lands(c,e,ne,s,env,t,*full);
 if(s->phase==5&&t>=s->fb_end-1e-9){
  s->phase=0;*full=0;code|=log_burst(s,t,5,-1);
  for(int i=0;i<5;i++)code|=notify(c,e,ne,s,env,t,2,i,0,0);
  double regen=0;for(int i=0;i<5;i++)regen=mx(regen,c[i*CW+25]);s->gauge=t+regen;s->cycle++;s->cast_mask=0;invalidate(s);
 }
 if(s->phase==0&&t>=s->gauge-1e-9){s->phase=1;s->action=t;s->opened=t;for(int i=0;i<5;i++)code|=notify(c,e,ne,s,env,t,4,i,1,0);}
 if(s->wait_mask){double at=1e30;for(int i=0;i<5;i++)if(s->wait_mask&(1<<i))at=mn(at,s->ready[i]);s->action=mx(s->opened,at);}
 if(s->phase>=1&&s->phase<=3&&t>=s->action-1e-9){
  int stage=s->phase,picked=-1;double earliest=1e30;int stop=0,mask=0;s->wait_mask=0;
  for(int rank=0;rank<3&&!stop;rank++)for(int i=0;i<5;i++){
   const double* a=c+i*CW;if((int)a[20]!=stage||a[27]<.5)continue;mask|=1<<i;
   int pr=1;
   if(a[22]>0)pr=s->cycle%(int)a[22]==0?0:2;
   else if(a[22]<0){int cycle=s->cycle-1;pr=cycle>=0&&cycle<160&&((unsigned int)a[35+cycle/32]&(1u<<(cycle%32)))?0:2;}
   if(pr!=rank)continue;
   earliest=mn(earliest,s->ready[i]);if(stat(c,e,ne,s,i,28,0)>0)continue;
   if(t<s->ready[i]-1e-9){if(s->ready[i]-t<=a[23]+1e-9){s->action=s->ready[i];s->wait_mask=1<<i;stop=1;break;}continue;}
   double press=mx(s->opened,s->ready[i])+a[24];if(t<press-1e-9){s->action=press;stop=1;break;}
   picked=i;stop=1;break;
  }
  if(picked>=0){
   int i=picked;s->cd_applied[i]=stat(c,e,ne,s,i,32,0);s->ready[i]=t+mx(0,c[i*CW+21]-s->cd_applied[i]);
   s->cast_mask|=1<<i;invalidate(s);code|=notify(c,e,ne,s,env,t,3,i,0,0);code|=log_burst(s,t,stage,i);
   if(stage==3){s->phase=4;s->action=t+.37;s->fb_caster=i;s->fb_cast_t=t;}
   else{s->phase++;s->opened=t+.1;s->action=t+.1;for(int j=0;j<5;j++)code|=notify(c,e,ne,s,env,t,4,j,stage+1,0);}
  }else if(!stop){s->action=mx(s->action,earliest);s->wait_mask=mask;}
 }
 if(s->phase==4&&t>=s->action-1e-9){
  double ext=0;for(int j=0;j<ne;j++)if((int)e[j*EW+1]==0&&(int)e[j*EW+2]==29&&s->stacks[j]>0){if(((unsigned int)e[j*EW+12]&(1u<<3))&&((int)e[j*EW]!=s->fb_caster||s->activated[j]<s->fb_cast_t-1e-9))continue;ext+=e[j*EW+6];}
  s->fb_end=t+mx(1,10+ext);s->phase=5;*full=1;
  for(int i=0;i<5;i++)code|=notify(c,e,ne,s,env,t,1,i,0,1);
  for(int i=0;i<5;i++){double extra=stat(c,e,ne,s,i,32,1)-s->cd_applied[i];if(s->ready[i]>t&&extra>0)s->ready[i]=mx(t,s->ready[i]-extra);s->cd_applied[i]=0;}
  // B3 bonus hits are evaluated after full-burst buffs, excluding later cast buffs.
  for(int j=0;j<ne;j++)if(s->pending[j]){
   const double* q=e+j*EW;s->pending[j]=0;for(int k=0;k<4;k++)s->excluded[k]=(unsigned int)q[52+k];invalidate(s);
   double coeff=q[6];if(q[10]>=0)coeff*=ref(e,ne,s,(int)q[0],(int)q[10]);if(coeff!=0){double hit=damage(c,e,ne,s,env,(int)q[0],1,coeff,0,0);s->total[(int)q[0]]+=hit;if(s->now_count>=NE)return 4;s->now_owner[s->now_count]=(int)q[0];s->now_damage[s->now_count++]=hit;}
   for(int k=0;k<4;k++)s->excluded[k]=0;invalidate(s);
  }
  for(int k=0;k<s->now_count;k++)code|=heal_landed(c,e,ne,s,env,t,1,s->now_owner[k],s->now_damage[k]);s->now_count=0;
  code|=log_burst(s,t,4,-1);
 }
 for(int i=0;i<5;i++){
  s->hit[i]=0;s->hits[i]=0;code|=weapon_frame(c,e,ne,s,env,t,i,*full);
  for(int k=0;k<s->hits[i];k++)code|=heal_landed(c,e,ne,s,env,t,*full,i,s->hit_unit[i]);
 }
 return code;
}
extern "C" __global__ void detail_workspace_v4(const double* chars,const double* effects,const int* counts,const double* enemy,const double* script,int steps,int nq,int n,double* queries,double* totals,int* status,State* workspace){
 int id=blockIdx.x*blockDim.x+threadIdx.x;if(id>=n)return;
 const double* c=chars+id*5*CW;const double* e=effects+id*NE*EW;const double* env=enemy+id*2;int ne=counts[id];
 State* s=workspace+id;int full=0;s->when=0;s->timer_clock=s->entry_clock=0;s->cast_mask=0;s->heal_source=-1;for(int i=0;i<5;i++)s->auto_reload[i]=0;s->lazy_dirty=0;s->land_count=0;s->now_count=0;s->squad_mode=0;for(int j=0;j<steps;j++)if(script[j*8+1]==4){s->squad_mode=1;break;}s->cached_full=0;invalidate(s);for(int j=0;j<4;j++)s->excluded[j]=0;
 for(int j=0;j<NE;j++){for(int k=0;k<5;k++){s->gauges[k][j]=0;s->gauge_present[k][j]=0;s->gauge_cap[k][j]=1e30;}s->timer_active[j]=0;s->timer_at[j]=s->timer_end[j]=-1;s->timer_seq[j]=s->entry_seq[j]=0;s->dot_present[j]=0;s->bullet_left[j]=-1;for(int k=0;k<6;k++)s->bullets[j][k]=s->bullet_stacks[j][k]=0;s->activations[j]=0;s->shield_mask[j]=0;s->stacks[j]=0;s->end[j]=-1;s->capture[j]=-1;s->pending[j]=0;s->masks[j]=0;s->target_order[j]=0;for(int k=0;k<EVS;k++)s->count[j][k]=0;s->period_at[j]=e[j*EW+44];s->activated[j]=-1;}
 for(int i=0;i<5;i++){s->weapon_context[i]=0;s->mode_started[i]=0;s->mode_ready[i]=-1;s->hits[i]=0;s->hit_unit[i]=0;s->frac[i][0]=s->frac[i][1]=0;s->hp[i]=c[i*CW+28];s->hppct[i]=100;s->hit[i]=0;s->mode[i]=-1;s->mode_end[i]=-1;s->total[i]=0;s->prev_mode[i]=-1;s->started[i]=0;s->shots[i]=0;s->warm[i]=0;s->last[i]=-999;s->inter[i]=0;s->next[i]=0;s->ammo[i]=c[i*CW+2];s->reload[i]=-1;s->post[i]=-1;s->charge_phase[i]=0;s->charge_start[i]=0;s->ready[i]=0;s->cd_applied[i]=0;}
 s->phase=0;s->cycle=1;s->action=0;s->opened=0;s->gauge=3;s->fb_end=-1;s->fb_caster=-1;s->fb_cast_t=-1;s->wait_mask=0;s->log_count=0;
 status[id]=0;
 for(int step=0;step<steps;step++){
  const double* cmd=script+step*8;double t=cmd[0];int op=(int)cmd[1],ev=(int)cmd[2],who=(int)cmd[3],arg=(int)cmd[4],out=(int)cmd[5];
  if(s->squad_mode&&op!=4&&s->when!=t)invalidate(s);s->when=t;
  if(!s->squad_mode)status[id]|=tick_effects(c,e,ne,s,env,t,full);
  if(op==0){if(ev==1)full=1;if(ev==2)full=0;status[id]|=notify(c,e,ne,s,env,t,ev,who,arg,full);}
  if(op==3)status[id]|=weapon_frame(c,e,ne,s,env,t,who,full);
  if(op==4)status[id]|=squad_frame(c,e,ne,s,env,t,&full);
  if(op==5)status[id]|=flush_lands(c,e,ne,s,env,t,full);
  if(op==2){
   double* dst=queries+(id*nq+out)*OW;
   if(ev==105){dst[0]=damage(c,e,ne,s,env,who,full,cmd[6],(int)cmd[7],arg);continue;}
   if(ev==103){dst[0]=stat(c,e,ne,s,who,arg,full);continue;}
   if(ev==104){dst[0]=charge_duration(c,e,ne,s,who,full);continue;}
   if(ev==102){dst[0]=s->gauges[who][arg];dst[1]=s->gauge_cap[who][arg];continue;}
   if(ev==101){dst[0]=s->hp[who];dst[1]=s->hppct[who];dst[2]=max_hp(c,e,ne,s,who,full);continue;}
   if(ev==100){dst[3]=s->log_count;if(arg<s->log_count){dst[0]=s->log_t[arg];dst[1]=s->log_event[arg];dst[2]=s->log_who[arg];}continue;}
   for(int k=0;k<ST;k++)dst[k]=stat(c,e,ne,s,who,k,full);
   int mode=s->mode[who];dst[32]=mode<0?c[who*CW+1]:e[mode*EW+26];dst[33]=mode<0?c[who*CW+4]:e[mode*EW+28];dst[34]=mode<0?c[who*CW+2]:e[mode*EW+27];
   dst[35]=mode>=0;dst[36]=damage(c,e,ne,s,env,who,full,dst[32],1,0);dst[37]=arg>=0?ref(e,ne,s,who,arg):0;
   for(int i=0;i<5;i++)dst[38+i]=s->total[i];
   dst[43]=s->shots[who];dst[44]=s->ammo[who];dst[45]=s->warm[who];dst[46]=s->next[who];dst[47]=s->reload[who];
  }
 }
 if(s->squad_mode)status[id]|=flush_lands(c,e,ne,s,env,script[(steps-1)*8],full);
 for(int i=0;i<5;i++)totals[id*5+i]=s->total[i];
}
