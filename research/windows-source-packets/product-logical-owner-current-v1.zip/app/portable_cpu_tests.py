"""One CPU-only unittest worker, preserving every selected group and its logs."""
import contextlib,os,re,sys,time,unittest
from pathlib import Path

AUDIT_FILES = {'test_weighted_source_contract.py': ('research/portable-cover-defense-modifiers-v1-expected.json','tests/fixtures/portable-product-boss-debuff-source-delta.json'),
    'test_quantity_visited.py': ('tests/fixtures/quantity-visited-source-change-v1.json','tests/fixtures/portable-coordinate-full-burst-source-delta.json','tests/fixtures/portable-max-ammo-scaling-source-delta.json'),
    'test_coordinate_power_v1.py': ('requirements-validation.txt',),'test_coordinate_landing_v1.py': ('requirements-validation.txt',),
    'test_coordinate_healing.py': ('research/portable-coordinate-auto-reload-short-expected.json',),'test_coordinate_auto_reload.py': ('research/portable-coordinate-mode-actions-short-expected.json',),
    'test_coordinate_mode_actions.py': ('research/portable-coordinate-burst-control-short-expected.json',),
    'test_original_lock_health_parts.py': ('research/portable-original-lock-composition-v1-expected.json',),
    'test_original_shield_weapons.py': ('research/upstream/nikke-calc-master/data/parsed_skills.json',),
    'test_original_lock_controls.py': ('research/portable-original-lock-composition-v1-expected.json',),
    'test_coordinate_mixed.py': ('research/portable-coordinate-group-short-expected.json',),
    'test_coordinate_sampled_delivery.py': ('research/portable-coordinate-sampled-vital-short-expected.json',),
    'test_coordinate_physical_frontier.py': (
    'research/upstream/nikke-calc-master/docs/IMPL-STATUS.md',
    'research/portable-coordinate-arcs-short-expected.json',
    'tests/fixtures/coordinate-common-numeric-decision.json'),
    'test_portable_model_gap_audit.py': (
    'tests/fixtures/resident-append-full106-metal-v1.json',
    'tests/fixtures/resident-append-cross-gpu-v1.json',
    'research/upstream/nikke-calc-master/docs/IMPL-STATUS.md',
    'tests/fixtures/coordinate-common-numeric-decision.json',
    'tests/fixtures/heavyarms-lock-published-contract.json',
    'research/upstream/nikke-calc-master/data/parsed_skills.json')}


AUDIT_FILES['test_original_catalogue_burst.py']=('research/portable-original-catalogue-burst-v1-expected.json','research/portable-original-catalogue-initial-v1-expected.json')
AUDIT_FILES['test_original_catalogue_roles_sealed.py']=('research/portable-original-catalogue-roles-v1-expected.json',)
AUDIT_FILES['test_original_catalogue_incoming_sealed.py']=('research/portable-original-catalogue-incoming-v1-expected.json',)
AUDIT_FILES['test_recipient_order_observation.py']=('tests/fixtures/portable-recipient-order-observation-source-delta.json',)
AUDIT_FILES['test_original_catalogue_support.py']=(
    'tests/fixtures/original-catalogue-support-independent-v1.json',
    'research/portable-original-catalogue-support-v1-expected.json',
    'research/portable-compiler-full--original-catalogue-support-source-certificate.json')
AUDIT_FILES['test_original_support_conditions.py']=(
    'research/portable-original-catalogue-support-v1-expected.json',
    'research/portable-original-support-conditions-v1-expected.json',
    'research/portable-compiler-full--original-support-conditions-source-certificate.json',
    'tests/fixtures/original-support-conditions-independent-v1.json')
AUDIT_FILES['test_original_threshold_conditions.py']=(
    'research/portable-original-support-conditions-v1-expected.json',
    'research/portable-original-threshold-conditions-v1-expected.json',
    'research/portable-compiler-full--original-threshold-conditions-source-certificate.json',
    'tests/fixtures/original-threshold-conditions-independent-v1.json',
    'tests/fixtures/original-threshold-gpu-counts-v1.json')
AUDIT_FILES['test_original_probability_conditions.py']=(
    'research/portable-original-threshold-conditions-v1-expected.json',
    'research/portable-original-probability-conditions-v1-expected.json',
    'research/portable-compiler-full--original-probability-conditions-source-certificate.json',
    'tests/fixtures/original-probability-conditions-independent-v1.json',
    'tests/fixtures/original-probability-gpu-counts-v1.json')
AUDIT_FILES['test_cover_defense_numeric.py']=('research/cover-defense-random-inputs-v1.json','research/portable-cover-defense-numeric-v1-expected.json','tests/fixtures/cover-defense-numeric-metal-v1.json','tests/fixtures/cover-defense-numeric-independent-v1.json')
AUDIT_FILES['test_cover_defense_battle.py']=('tests/fixtures/cover-defense-battle-cpu-v1.json',)
AUDIT_FILES['test_cover_defense_modifiers.py']=('tests/fixtures/cover-defense-modifiers-cpu-v1.json','tests/fixtures/portable-received-sum-source-delta.json','research/portable-cover-defense-battle-v1-expected.json')
AUDIT_FILES['test_cover_defense_modifiers_sealed.py']=('research/portable-cover-defense-modifiers-v1-expected.json','research/portable-compiler-full--cover-defense-modifiers-source-certificate.json','tests/fixtures/cover-defense-modifiers-metal-v1.json','tests/fixtures/cover-defense-modifiers-independent-v1.json','tests/fixtures/cover-defense-modifiers-retention-v1.json','research/portable-cover-defense-battle-v1-expected.json')
AUDIT_FILES['test_cover_defense_wire.py']=('tests/fixtures/cover-defense-battle-cpu-v1.json','tests/fixtures/portable-cover-defense-source-delta.json','tests/fixtures/portable-received-sum-source-delta.json')
AUDIT_FILES['test_cover_defense_sealed.py']=('tests/fixtures/cover-defense-battle-metal-v1.json','tests/fixtures/cover-defense-battle-independent-v1.json','research/portable-cover-defense-battle-v1-expected.json','research/portable-compiler-full--cover-defense-battle-source-certificate.json')
AUDIT_FILES['test_heavyarms_lock_reference.py']=AUDIT_FILES['test_portable_model_gap_audit.py']
AUDIT_FILES['test_bay_published_allocation.py']=('tests/fixtures/bay-published-allocation-v1.json',)
AUDIT_FILES['test_portable_entry_plan.py']=('tests/fixtures/bay-published-allocation-v1.json',)
for _test in ('test_effect_target_count_policy.py','test_effect_target_count_reference.py','test_portable_effect_target_count.py','test_effect_target_count_shots.py'):
    AUDIT_FILES[_test]=('research/upstream/nikke-calc-master/data/parsed_skills.json',)
AUDIT_FILES['test_effect_target_count_policy.py']=AUDIT_FILES['test_portable_model_gap_audit.py']
AUDIT_FILES['test_effect_range.py']=('research/upstream/nikke-calc-master/data/parsed_skills.json',)
AUDIT_FILES['test_portable_scope_snapshot_audit.py']=(
    'tests/fixtures/portable-resident-scalar-generated.json',
    'tests/fixtures/portable-healing-hp-snapshot-delta.json')
AUDIT_FILES['test_resident_append_probe.py']=('tests/fixtures/portable-resident-scalar-generated.json',)
AUDIT_FILES['test_dispatch_frame_storage.py']=(
    'research/portable-coordinate-resident-frames-short-expected.json',
    'research/portable-coordinate-resident-frames-short-v2-expected.json',
    'research/portable-compiler-full--coordinate-resident-frames-v2-source-certificate.json')
AUDIT_FILES['test_moving_frames.py']=(
    'research/portable-moving-group-v2-expected.json',
    'research/portable-moving-frames-v1-expected.json',
    'research/portable-compiler-full--moving-frames-source-certificate.json')
AUDIT_FILES['test_quantity_moving_frames.py']=(
    'research/portable-moving-frames-v1-expected.json',
    'research/portable-moving-visited-v1-expected.json',
    'research/portable-compiler-full--moving-visited-source-certificate.json')
AUDIT_FILES['test_portable_readiness_semantics.py']=(
    'research/upstream/nikke-calc-master/docs/IMPL-STATUS.md',
    'tests/fixtures/enemy-movement-math-metal-v1.json',
    'tests/fixtures/enemy-movement-math-cuda-v1.json',
    'tests/fixtures/enemy-movement-battle-metal-v1.json',
    'tests/fixtures/moving-typed-metal-v1.json',
    'tests/fixtures/moving-group-metal-v1.json',
    'tests/fixtures/moving-many-metal-v1.json',
    'research/portable-moving-typed-v1-expected.json',
    'research/portable-enemy-movement-battle-v1-expected.json',
    'tests/fixtures/resident-current-cuda-native-join-v1.json',
    'tests/fixtures/resident-append-full106-metal-v1.json',
    'tests/fixtures/resident-append-cross-gpu-v1.json',
    'tests/fixtures/resident-current-cuda-v2-summary.json')
AUDIT_FILES['test_portable_partitioned_current.py']=(
    'tests/fixtures/partitioned-physical-reference-v1.json',
    'tests/fixtures/resident-append-full106-metal-v1.json',
    'research/portable-coordinate-resident-frames-short-v2-expected.json')
AUDIT_FILES['test_portable_partitioned_witness.py']=(
    'tests/fixtures/resident-current-cuda-v2-summary.json',
    'research/portable-coordinate-resident-frames-short-v2-expected.json')
AUDIT_FILES['test_portable_partitioned_join.py']=(
    'tests/fixtures/resident-current-envelope-v1-summary.json',
    'research/portable-coordinate-resident-frames-short-v2-expected.json')
AUDIT_FILES['test_enemy_movement_wire.py']=('tests/fixtures/portable-enemy-movement-source-delta.json',)
AUDIT_FILES['test_moving_group_events.py']=('tests/fixtures/moving-group-native-events-v1.json','tests/fixtures/moving-group-metal-v1.json','research/portable-moving-group-v1-expected.json')

def validate_dependency_files(root,patterns,included=None):
    """Reject missing audit data before tests/native work or execution claims."""
    root=Path(root)
    names={name for pattern in patterns for name in AUDIT_FILES.get(pattern,())}
    for name in sorted(names):
        path=root/name
        if not path.is_file() or path.is_symlink():
            raise ValueError('CPU audit dependency missing: '+name)
        if included is not None and name not in included:
            raise ValueError('CPU audit dependency missing from immutable payload: '+name)


def validate_groups(root,patterns):
    if len(set(patterns))!=len(patterns):raise ValueError('Duplicate CPU test group')
    for pattern in patterns:
        if not re.fullmatch(r'test_[A-Za-z0-9_]+\.py',pattern) or not (root/'tests'/pattern).is_file():
            raise ValueError('CPU test file missing or invalid: '+pattern)
    validate_dependency_files(root,patterns)


def discovered_cases(root,pattern):
    """Discover original test IDs without executing fixtures or test bodies."""
    validate_groups(Path(root),[pattern]);before=list(sys.path)
    def flatten(suite):
        for item in suite:
            if isinstance(item,unittest.TestSuite):yield from flatten(item)
            else:yield item
    try:
        cases=list(flatten(unittest.TestLoader().discover(str(Path(root)/'tests'),pattern=pattern)))
    finally:sys.path[:]=before
    ids=[case.id() for case in cases]
    if not ids or len(ids)!=len(set(ids)) or any(type(case).__name__=='_FailedTest' for case in cases):
        raise ValueError('CPU test discovery incomplete or ambiguous')
    return cases


AUDIT_FILES['test_portable_gpu_cli.py']=tuple(AUDIT_FILES.get('test_portable_gpu_cli.py',()))+(
    'scripts/windows-product/prepare-api.py',
    'scripts/windows-product/check-sdk.py',
    'scripts/windows-product/verify-host-tests.py')


def selection_request(document,patterns,package_id):
    """Bind an explicit unit subset to one owner and every registered group."""
    if (type(document) is not dict or set(document)!={'schema','package_id','patterns','expected_tests'}
        or document['schema']!='unit-selection-v1' or document['package_id']!=package_id
        or type(document['patterns']) is not dict or list(document['patterns'])!=list(patterns)
        or type(document['expected_tests']) is not int or document['expected_tests']<=0):
        raise ValueError('Unit selection requires exact package, registry order and positive expected count')
    for ids in document['patterns'].values():
        if ids is not None and (type(ids) is not list or not ids or any(type(x) is not str for x in ids)
            or len(ids)!=len(set(ids))):
            raise ValueError('Unit selection requires nonempty unique test IDs or null for a complete group')
    return document


def resolve_selection(root,patterns,document,package_id):
    """Discover only in the fresh CPU child, then reuse run_groups admission."""
    selection_request(document,patterns,package_id);selected={}
    for pattern in patterns:
        available=[case.id() for case in discovered_cases(root,pattern)]
        ids=document['patterns'][pattern]
        if ids is None:ids=available
        if not ids or ids!=[name for name in available if name in ids]:
            raise ValueError('Selected CPU test IDs missing, duplicated or reordered')
        selected[pattern]=ids
    if sum(map(len,selected.values()))!=document['expected_tests']:
        raise ValueError('Selected CPU test count differs from explicit request')
    return selected


def run_groups(root,capture,patterns,write,*,selected_cases=None):
    """Execute in registry order; failure stops before any later group or GPU."""
    root=Path(root);capture=Path(capture);validate_groups(root,patterns)
    if selected_cases is not None and (type(selected_cases) is not dict or set(selected_cases)!=set(patterns)):
        raise ValueError('Exact selected CPU test patterns required')
    if (capture/'cpu-tests.json').exists():raise FileExistsError('Fresh CPU test receipt required')
    for pattern in patterns:
        for suffix in ('.stdout.log','.stderr.log'):
            if (capture/(pattern+suffix)).exists():raise FileExistsError('Fresh CPU test logs required')
    before_path=list(sys.path);rows=[];loader=unittest.TestLoader()
    try:
        # Standard unittest discovery keeps this path during test bodies.
        # Selected discovery restores its private import path, so retain the
        # same sibling-fixture imports here and restore it on every exit.
        test_root=str(root/'tests')
        if test_root not in sys.path:sys.path.insert(0,test_root)
        for pattern in patterns:
            started=time.perf_counter()
            with (capture/(pattern+'.stdout.log')).open('x',encoding='utf-8') as stdout,(capture/(pattern+'.stderr.log')).open('x',encoding='utf-8') as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
                selected=None
                if selected_cases is None:suite=loader.discover(str(root/'tests'),pattern=pattern)
                else:
                    selected=selected_cases[pattern];cases=discovered_cases(root,pattern);available={case.id():case for case in cases}
                    if (type(selected) is not list or not selected or any(type(x) is not str for x in selected)
                        or len(selected)!=len(set(selected)) or any(x not in available for x in selected)
                        or selected!=[case.id() for case in cases if case.id() in selected]):
                        raise ValueError('Selected CPU test IDs missing, duplicated or reordered')
                    suite=unittest.TestSuite([available[x] for x in selected])
                result=unittest.TextTestRunner(stream=stderr,verbosity=1).run(suite)
                success=result.wasSuccessful() and result.testsRun>0 and (selected is None or result.testsRun==len(selected))
                if result.testsRun==0:stderr.write('Required CPU group discovered zero tests\n')
            rows.append(dict(pattern=pattern,exit_code=0 if success else 1,elapsed_seconds=time.perf_counter()-started,
                tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),runner_pid=os.getpid()))
            if selected is not None:rows[-1]['case_ids']=list(selected)
            write(capture/'cpu-tests.json',rows)
            if not success:break
        if not patterns:write(capture/'cpu-tests.json',rows)
    finally:sys.path[:]=before_path
    return rows


def complete(rows,patterns):
    return bool([r.get('pattern') for r in rows]==list(patterns) and all(type(r.get('exit_code')) is int and r['exit_code']==0 and type(r.get('tests')) is int and r['tests']>0 and r.get('failures')==0 and r.get('errors')==0 for r in rows))

AUDIT_FILES['test_enemy_movement_cuda_words.py']=('tests/fixtures/enemy-movement-math-cuda-v1.json','research/portable-enemy-movement-math-v1-expected.json')
AUDIT_FILES['test_moving_typed_wire.py']=('tests/fixtures/portable-moving-many-source-delta.json','tests/fixtures/portable-moving-typed-source-delta.json','tests/fixtures/portable-enemy-movement-source-delta.json','tests/fixtures/portable-coordinate-typed-weapon-source-delta.json','tests/fixtures/moving-typed-metal-v1.json','research/portable-moving-typed-v1-expected.json')
AUDIT_FILES['test_moving_many_wire.py']=('tests/fixtures/portable-moving-many-source-delta.json','tests/fixtures/portable-moving-typed-source-delta.json','tests/fixtures/portable-enemy-movement-source-delta.json','tests/fixtures/moving-many-metal-v1.json','research/portable-moving-many-v1-expected.json')
