"""Exact inverse of explicit cover policy hooks for historical source certificates."""
import hashlib,json
from pathlib import Path
def project_sources(root,sources=None):
    root=Path(root);out=dict(sources or {})
    if (root/'gpu/coordinate_squad_control_runtime.slang').exists():
        from portable_coordinate_squad_source_contract import project_sources as squad
        out=squad(root,out)
    d=json.loads((root/'tests/fixtures/portable-coordinate-policy-source-delta.json').read_text())
    for name,row in d['sources'].items():
        current=out.get(name,(root/name).read_text());assert current==row['current'] and hashlib.sha256(current.encode()).hexdigest()==row['current_sha256'],'Unreviewed cover policy source: '+name
        assert hashlib.sha256(row['baseline'].encode()).hexdigest()==row['baseline_sha256'];out[name]=row['baseline']
    for name,h in d['added_sources'].items():assert hashlib.sha256(out.get(name,(root/name).read_text()).encode()).hexdigest()==h,'Unreviewed cover policy addition: '+name
    return out
def project_backend_source(root,source=None):
    root=Path(root);d=json.loads((root/'tests/fixtures/portable-coordinate-policy-source-delta.json').read_text())['transport'];s=(root/d['path']).read_text() if source is None else source
    if (root/'gpu/coordinate_squad_control_runtime.slang').exists():
        from portable_coordinate_squad_source_contract import project_backend_source
        s=project_backend_source(root,s)
    if s!=d['current'] or hashlib.sha256(s.encode()).hexdigest()!=d['current_sha256']:raise ValueError('Unreviewed cover policy transport')
    assert hashlib.sha256(d['baseline'].encode()).hexdigest()==d['baseline_sha256'];return d['baseline']
