"""Exact named-enemy route/operand delta before prior shared source contracts."""
import hashlib,json
from pathlib import Path
def ledger(root):return json.loads((Path(root)/'tests/fixtures/portable-named-enemy-source-delta.json').read_text())
def baseline_source(root,name,source):
    row=ledger(root)['sources'].get(name)
    if row is None:return source,False
    assert hashlib.sha256(source.encode()).hexdigest()==row['current_sha256'],'Unreviewed named-enemy source: '+name
    for change in reversed(row['changes']):
        assert source.count(change['current'])==1,'Ambiguous named-enemy delta: '+name
        source=source.replace(change['current'],change['baseline'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==row['baseline_sha256'],'Named-enemy historical source changed: '+name
    return source,True
def project_sources(root,sources=None):
    from portable_named_enemy_removal_source_contract import project_sources as project_removal
    root=Path(root);sources=project_removal(root,sources);data=ledger(root)
    for name,digest in data['added_sources'].items():assert hashlib.sha256(sources.get(name,(root/name).read_text()).encode()).hexdigest()==digest,'Unreviewed named-enemy helper: '+name
    for name in data['sources']:sources[name],_=baseline_source(root,name,sources.get(name,(root/name).read_text()))
    return sources,list(data['sources'])
