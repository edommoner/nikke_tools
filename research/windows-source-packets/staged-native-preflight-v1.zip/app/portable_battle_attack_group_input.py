"""Static opt-in lowering only; no native battle or authored hit/group lists."""
import copy
from portable_specs import LIMITS as L,FIELDS as F
from portable_trigger_specs import pack_event_candidates
from portable_runtime import double_words
from attack_group_specs import simultaneous_threshold
from portable_projectile_roster_input import compile_projectile_battle
SOURCE='gpu/world_attack_group_entry.slang'
from portable_arena_specs import attack_group_layout,WORLD_INPUT_WORDS
_ARENA=attack_group_layout(L['LANDINGS'])
INPUT_WORDS=WORLD_INPUT_WORDS+8
OUTPUT_WORDS=_ARENA['OUTPUT_WORDS']
HEADER=_ARENA['HEADER']
SLOTS=_ARENA['SLOTS']
SLOT_WORDS=_ARENA['WORDS']
LOG=_ARENA['LOG']
LOG_CAPACITY=_ARENA['LOG_CAP']
PACKETS=_ARENA['PACKETS']
COMPACT=_ARENA['COMPACT']
COMPACT_WORDS=_ARENA['COMPACT_WORDS']

def compile_battle(prepared,*,routing,declared_effects=(),group_history='fixed64'):
    if routing not in ('native','all-logical-enemies'):raise ValueError('Explicit native or logical-enemy routing required')
    if group_history not in ('fixed64','compact'):raise ValueError('Explicit fixed64 or compact group history required')
    enemy=prepared['enemy']
    if enemy.get('has_parts') or enemy.get('coord') is not None or enemy.get('part_break_interval',0):raise ValueError('Plain body/add world required')
    patterns=enemy.get('patterns',[])
    if any(p.get('kind') not in ('idle','summon') or p.get('kind')=='summon' and (p.get('spec',{}).get('attack') or p.get('spec',{}).get('self_destruct')) for p in patterns):raise ValueError('Only plain idle/summon patterns supported')
    lowered=copy.deepcopy(prepared);owner=prepared['chars'][0]['name']
    for effect in declared_effects:lowered['effects'].append(dict(effect=copy.deepcopy(effect),owner=owner))
    from portable_group_binding import lower,bind
    lowered,original,owners=lower(lowered)
    if owners==0:raise ValueError('At least one original or explicit declared listener required')
    words,metadata=compile_projectile_battle(lowered)
    bind(words,metadata,original)
    assert len(words)==104400
    words.extend([0x41475331,2 if routing=='native' else 1,owners,int(group_history=='compact'),0,0,0,0]);assert len(words)==INPUT_WORDS
    metadata['real_prepared_input']['declared_attack_group_policy']=dict(routing=routing,listener_owners=owners,game_geometry_verified=False,source_effects=original,cpu_trace_used_as_gpu_input=False)
    return words,metadata
