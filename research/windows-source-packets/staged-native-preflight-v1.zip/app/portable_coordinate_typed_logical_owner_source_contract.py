"""Strict logical-owner inverse before the existing BODY-owner source audit."""
import hashlib,json
from pathlib import Path

def ledger(root):return json.loads((Path(root)/'tests/fixtures/portable-coordinate-typed-logical-owner-source-delta.json').read_text())
def checked(current,row):
    assert current==row['current'] and hashlib.sha256(current.encode()).hexdigest()==row['current_sha256'],'Unreviewed logical owner source'
    assert hashlib.sha256(row['baseline'].encode()).hexdigest()==row['baseline_sha256'];return row['baseline']
def project_sources(root,sources=None):
    from portable_coordinate_resident_arc_source_contract import project_sources as arc
    root=Path(root);out=arc(root,sources);data=ledger(root)
    for name,digest in data['added_sources'].items():assert hashlib.sha256(out.get(name,(root/name).read_text()).encode()).hexdigest()==digest,'Unreviewed logical owner dependency'
    for name,row in data['sources'].items():
        if name.endswith('.slang'):out[name]=checked(out.get(name,(root/name).read_text()),row)
    return out

def project_backend_source(root,source=None):
    from portable_coordinate_resident_arc_source_contract import project_backend_source as arc
    root=Path(root);name='app/portable_backend.py';return checked(arc(root,source),ledger(root)['sources'][name])
