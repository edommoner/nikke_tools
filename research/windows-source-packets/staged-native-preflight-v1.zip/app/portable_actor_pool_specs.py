"""Authored Actor pool quantities;no HP,death schedule or recipients are simulated."""
import math,struct
from portable_specs import LIMITS as L
MAGIC=0x57485031
REF=0x80000000

def number(v):
 if type(v) not in (int,float) or not math.isfinite(v):raise ValueError('Finite Actor quantity required')
 return list(struct.unpack('<II',struct.pack('<d',float(v))))

def compile_pools(patterns,bindings,*,fields=False,boss_atk=114344,focus_aim=False,armed=False):
 from calculator.boss_pattern import BOSS_EVENTS,penalty_parts
 penalties=penalty_parts(patterns) if focus_aim else frozenset()
 words=[0]*(L['WORLD_ACTOR_POOL_INPUT_WORDS']-L['WORLD_ACTOR_INPUT_WORDS']);words[:2]=[MAGIC,len(bindings)]
 if fields:words[2:4]=number(boss_atk)
 for slot,b in enumerate(bindings):
  if slot==0:continue
  p=patterns[b.run];at=8+slot*12
  if int(b.kind) in (1,6):
   spec=p.targets[b.slot]
   if len(spec.emits)>8:raise ValueError('Actor death notice capacity exceeded')
   if spec.score>0x7fffffff:raise ValueError('Actor score exceeds exact integer bound')
   words[at:at+12]=[1,0,*number(spec.hp),0,0,len(spec.emits),sum((BOSS_EVENTS.index(e)+1)<<(i*3) for i,e in enumerate(spec.emits)),spec.score,0,0,0]
   if int(b.kind)==1 and p.id in penalties:words[at+11]=1
  else:
   spec=p.summon;mode=4 if spec.hp is not None and spec.hit_hp else 3 if spec.hp is None else 2
   if not 0<=spec.hit_hp<=0x7fffffff:raise ValueError('Actor hit-HP exceeds exact integer bound')
   words[at:at+12]=[mode,spec.hit_hp,*number(spec.hp or 0),*number(spec.hit_hp_after),0,0,0,0,0,0]
   if fields and int(b.kind)==5:words[at+9:at+11]=number(spec.atk)
 return words
