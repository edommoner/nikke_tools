"""Exact private harmful-recipient delta before all historical source proofs."""
import hashlib,json
from pathlib import Path

def ledger(root):return json.loads((Path(root)/'tests/fixtures/portable-random-cleanse-source-delta.json').read_text())
def baseline_source(root,name,source,*,named_projected=False):
    if not named_projected:
        from portable_named_enemy_source_contract import baseline_source as project_named
        source,_=project_named(root,name,source)
    row=ledger(root)['sources'].get(name)
    if row is None:return source,False
    assert hashlib.sha256(source.encode()).hexdigest()==row['current_sha256'],'Unreviewed random-cleanse source: '+name
    for change in reversed(row['changes']):
        assert source.count(change['current'])==1,'Ambiguous random-cleanse delta: '+name
        source=source.replace(change['current'],change['baseline'],1)
    assert hashlib.sha256(source.encode()).hexdigest()==row['baseline_sha256'],'Random-cleanse historical source changed: '+name
    return source,True
def project_sources(root,sources=None):
    from portable_named_enemy_source_contract import project_sources as project_named
    root=Path(root);sources,_=project_named(root,sources);data=ledger(root)
    for name,digest in data['added_sources'].items():assert hashlib.sha256(sources.get(name,(root/name).read_text()).encode()).hexdigest()==digest,'Unreviewed random-cleanse helper: '+name
    for name in data['sources']:sources[name],_=baseline_source(root,name,sources.get(name,(root/name).read_text()),named_projected=True)
    return sources,list(data['sources'])
