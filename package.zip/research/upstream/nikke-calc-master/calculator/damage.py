"""
Phase 4: 단일 히트 대미지 계산기

DealForm:
  대미지 = ① 계수 × ② 공방차이 × ③ 보너스 × ④ 차지 × ⑤ 유형별 버프 × ⑥ 적 받는 × ⑦ 우월 코드

사용법:
  result = calc_damage(base_atk, enemy_def, buffs, weapon, hit_type)
  # result = {"damage": int, "is_crit": bool, "crit_frac": float}

hit_type 딕셔너리:
  {
    "is_core":                      False,  # 코어 히트 (코어 대미지 가산. 스킬 공격은 is_core_damage와 함께여야 적용)
    "is_core_damage":               False,  # core_damage 스킬 (확정 코어 명중 — is_normal_atk=False라도 ③ 코어 배율 적용)
    "is_weapon_mode_skill":         False,  # 무기 변경 모드의 스킬 대미지 사격 (나유타 `기억 연소`)
    "is_part":                      False,  # 파츠 명중 (part_dmg_pct 가산). 파츠를 명시한 스킬 + enemy.has_parts=True일 때만
    "is_intercept":                 False,  # 저지원 명중 (intercept_dmg_pct 가산). 파츠·본체 히트에는 미적용
    "is_full_burst":                False,  # 풀버스트 타임 (+50%)
    "is_optimal_range":             False,  # 적정거리 (+30%, 스킬에는 미적용)
    "is_full_charge":               False,  # SR/RL 풀 차지 (④ 적용)
    "is_burst_damage":              False,  # burst_damage 스킬 (burst_dmg 가산)
    "is_aoe_burst":                 False,  # 그 버스트 대미지의 대상이 '적 전체'인 경우
                                            # (burst_dmg_aoe_pct 추가 가산. is_burst_damage 전제)
    "is_pierce_damage":             False,  # pierce_damage 스킬 (pierce_dmg 가산)
    "is_armor_break_damage":        False,  # armor_break_damage 스킬 (armor_break_dmg_pct 가산, ②에서 적 방어력 0)
    "is_dot":                       False,  # dot_damage 스킬 (dot_dmg 가산)
    "is_projectile_explosion":      False,  # projectile_explosion_damage (projectile_explosion_dmg 가산)
    "is_projectile_attachment":     False,  # projectile_attachment_damage (projectile_attachment_dmg 가산)
    "is_sequential":                False,  # sequential_damage (sequential_dmg 가산)
    "is_normal_atk":                True,   # 기본 무기 일반 공격 여부
                                            # True  → ① normal_atk_dmg_pct 적용
                                            #         ③ 적정거리/코어 가산 허용
                                            #         크리 시 normal_atk_crit 적용
                                            # False → 스킬 공격 (위 항목들 미적용)
    "core_prob":                    None,   # 코어히트 확률(0~1). 기대값 모드에서만 채운다 —
                                            # is_core 확률 판정 대신 이 확률로 ③ 코어 가산을 태운다
    "crit_override":                None,   # 크리 판정을 난수 대신 이 값(bool)으로 — 같은 발이 파츠에도
                                            # 들어가는 히트가 본체 히트의 판정을 그대로 쓴다(난수를 안 먹는다).
                                            # 기대값 모드에서는 안 읽는다 (boss_pattern.py §파츠 다중 타격)
    "coeff":                        None,   # 계수 override (None이면 weapon["damage_coeff"] 사용)
    "is_final_atk":                 False,  # "최종 공격력 X% 대미지" 스킬이면 True
                                            # 차이 없음(공식 동일), 향후 구분용으로 보존
  }
"""

from __future__ import annotations

import random

DEFAULT_ENEMY_DEF = 31784.0

# ── 코드 상성 ─────────────────────────────────────────────────────────────

_CODE_ADVANTAGE: dict[str, str] = {
    "전격": "수냉",
    "수냉": "작열",
    "작열": "풍압",
    "풍압": "철갑",
    "철갑": "전격",
}

def is_element_match(char_code: str, enemy_code: str) -> bool:
    """캐릭터 코드가 적 코드에 우월한지 반환."""
    return _CODE_ADVANTAGE.get(char_code, "") == enemy_code

# ── 기본 hit_type ─────────────────────────────────────────────────────────

def default_hit_type(**overrides) -> dict:
    ht = {
        "is_core":          False,
        "core_prob":        None,
        "is_full_burst":    False,
        "is_optimal_range": False,
        "is_full_charge":   False,
        "is_burst_damage":              False,
        "is_aoe_burst":                 False,
        "is_single_burst":              False,
        "is_pierce_damage":             False,
        "is_armor_break_damage":        False,
        "is_dot":                       False,
        "is_projectile_explosion":      False,
        "is_projectile_attachment":     False,
        "is_sequential":                False,
        "is_split":                     False,
        "is_part":                      False,
        "is_intercept":                 False,
        "crit_override":                None,
        "is_core_damage":               False,
        "is_normal_atk":                True,
        "is_weapon_mode_skill":         False,
        "coeff":            None,
        "is_final_atk":     False,
    }
    ht.update(overrides)
    return ht


# ── DealForm 각 항목 ──────────────────────────────────────────────────────

def _factor1(weapon: dict, buffs: dict, hit_type: dict) -> float:
    """① 계수 × (1 + 일반 공격 대미지 배율 %▲)"""
    coeff = hit_type["coeff"]
    if coeff is None:
        coeff = weapon["damage_coeff"]

    # normal_atk_dmg_pct는 기본 무기 일반 공격에만 적용
    if hit_type["is_normal_atk"]:
        normal_bonus = buffs.get("normal_atk_dmg_pct", 0.0) / 100.0
    else:
        normal_bonus = 0.0

    return coeff * (1.0 + normal_bonus)


def _factor2(base_atk: float, enemy_def: float, buffs: dict, hit_type: dict) -> float:
    """② {기본공격력 × (1 + atk_pct%) + atk_flat}
       – {(적방어력 × (1 + enemy_def_down_pct%) + enemy_def_down_flat) × (1 – def_ignore_pct%)}
    enemy_def_down_pct: 적 방어력 감소 버프 합(음수).
    enemy_def_down_flat: 적 방어력 **정액** 감소 합(음수) — 적 대상 `def_caster_based_pct`를
      시전자 기본 방어력 × N%로 환산한 것(마스트 `해풍`). 비율 감소를 먹인 **뒤**에 뺀다.
    armor_break_damage는 적 방어력을 0으로 계산."""
    atk_term = base_atk * (1.0 + buffs.get("atk_pct", 0.0) / 100.0) \
               + buffs.get("atk_flat", 0.0)
    if hit_type.get("is_armor_break_damage"):
        def_term = 0.0
    else:
        eff_def = max(enemy_def * (1.0 + buffs.get("enemy_def_down_pct", 0.0) / 100.0)
                      + buffs.get("enemy_def_down_flat", 0.0), 0.0)
        def_term = eff_def * (1.0 - buffs.get("def_ignore_pct", 0.0) / 100.0)
    return max(atk_term - def_term, 0.0)


def _factor3(weapon: dict, buffs: dict, hit_type: dict,
             expected: bool = False) -> tuple[float, bool, float]:
    """
    ③ 보너스 배율 반환 및 크리티컬 판정.
    반환: (factor3, is_crit, crit_frac)

    crit_frac은 이 히트가 낸 크리 "횟수"다 — 확률 판정 모드에서는 0.0/1.0,
    기대값 모드(expected=True)에서는 크리 확률 그 자체(0~1).
    `crit_hit` 이벤트를 소수 누적으로 발화시키는 데 쓴다(timeline.py).

    ③의 가산 항목은 전부 **더해지므로** 각 항을 확률로 가중한 값이 곧 기댓값이다
    (크리·코어가 곱해지는 자리였다면 이런 치환이 성립하지 않는다).

    가산 항목:
      크리티컬: (0.5 + crit_dmg%) — 확률 판정, 기대값 모드에서는 확률을 곱한 기여분
      풀버스트 타임: +0.5
      적정거리: +0.3 (is_normal_atk=True인 경우만)
      코어 대미지: (core_dmg_mult% − 100%) + core_dmg% (is_normal_atk=True인 경우만)
                   기대값 모드에서 hit_type["core_prob"]가 있으면 그 확률로 가중
    """
    bonus = 1.0
    is_crit = False

    # 크리티컬 확률·배율 판정
    # `normal_atk_crit_rate` / `normal_atk_crit_dmg`(원문 `[일반 공격 크리티컬 확률 n% ▲]`,
    # `[일반 공격 크리티컬 대미지 n% ▲]` — 헬름 진두지휘 등)는 일반 공격에만 실린다.
    # get_buffs가 그 기여를 뺀 합을 `crit_rate_skill` / `crit_dmg_skill`로 따로 내므로
    # 스킬 딜 히트는 그쪽을 쓴다. 크리확률 쪽은 둘 다 기본 15%를 이미 포함한 값이다.
    if hit_type["is_normal_atk"]:
        crit_rate = buffs.get("crit_rate", 0.15)
        crit_dmg = buffs.get("crit_dmg", 0.0)
    else:
        crit_rate = buffs.get("crit_rate_skill", buffs.get("crit_rate", 0.15))
        crit_dmg = buffs.get("crit_dmg_skill", buffs.get("crit_dmg", 0.0))

    # 0 아래로는 안 내려간다 — 보스 디버프 「크리티컬 대미지 ▼」가 크면 크리가 딜을 깎게 된다
    crit_bonus = max(0.0, 0.5 + crit_dmg / 100.0)
    if expected:
        # 확률 판정 대신 기대값: 크리 기여분 = min(크리확률, 1) × (0.5 + crit_dmg%)
        # (확률 판정 경로는 crit_rate > 1이면 항상 크리라 100%로 잘린다 — 여기서도 맞춘다)
        crit_frac = min(crit_rate, 1.0)
        bonus += crit_frac * crit_bonus
    elif hit_type.get("crit_override") is not None:
        # 같은 발의 파츠 히트 — 본체 히트의 판정을 그대로 쓴다. 난수를 먹지 않아 뒤의 판정이 안 밀린다
        is_crit = bool(hit_type["crit_override"])
        crit_frac = 1.0 if is_crit else 0.0
        if is_crit:
            bonus += crit_bonus
    elif random.random() < crit_rate:
        is_crit = True
        crit_frac = 1.0
        bonus += crit_bonus
    else:
        crit_frac = 0.0

    # 풀버스트 타임
    if hit_type["is_full_burst"]:
        bonus += 0.5

    # 적정거리 (일반 공격에만)
    if hit_type["is_optimal_range"] and hit_type["is_normal_atk"]:
        bonus += 0.3

    # 코어 대미지 (일반 공격 + core_damage 스킬)
    # core_damage 스킬은 "코어 명중 대미지"가 명시된 확정 코어 히트라 is_normal_atk=False라도 태운다.
    core_prob = hit_type.get("core_prob")
    core_weight = float(core_prob) if (expected and core_prob is not None) \
                  else (1.0 if hit_type["is_core"] else 0.0)
    # 무기 변경 모드의 스킬 사격도 실제로 코어를 때린다 (유저 인게임 확인, 나유타 `기억 연소`).
    if core_weight and (hit_type["is_normal_atk"] or hit_type.get("is_core_damage")
                        or hit_type.get("is_weapon_mode_skill")):
        # 무기 코어 대미지(예: 200%)는 비코어 기본 100% 대비 추가분 → -100%
        core_base = (weapon.get("core_dmg_mult", 200.0) - 100.0) / 100.0
        core_extra = buffs.get("core_dmg_pct", 0.0) / 100.0
        bonus += core_weight * (core_base + core_extra)

    return bonus, is_crit, crit_frac


def _factor4(weapon: dict, buffs: dict, hit_type: dict) -> float:
    """
    ④ 차지 배율.
    풀 차지가 아니면 1.0.

    무기의 풀차지 배율과 「차지 대미지 N% ▲」(평문) 버프는 **가산**이다
    (유저 인게임 확인, 2026-08-25). RL 250% + 차지 대미지 87.05% = 337%로 인게임 표기
    335%와 맞는다. 곱연산이면 468%가 되어 차지 무기 전체가 부풀었다.

    「차지 대미지 N% **배율** ▲」(`charge_dmg_mag_pct`)는 별개 층인데, 곱하는 대상이
    합 전체가 아니라 **무기 기본 배율뿐**이다. 배율끼리는 서로 가산된다:

        full_charge_mult% × (1 + Σ배율%) + Σ평문%

    근거는 헬름 실측 (유저 인게임 확인, 2026-08-28 — GAMEPLAY.md §차지 배율).
    기본 250% · 오버로드 평문 11.11% · 소장품 SR15 배율 9.47% · 버스트 배율 158.4%:

        평시   250 × (1 + 0.0947)         + 11.11 = 284.79  ← 인게임 285
        버스트 250 × (1 + 0.0947 + 1.584) + 11.11 = 680.79  ← 인게임 681

    버스트가 더하는 396은 평시 표기(285)가 아니라 **기본 배율 250**의 158.4%다.
    합 전체에 곱했다면 699가 되어 버스트 구간이 통째로 부푼다.
    """
    if not hit_type["is_full_charge"]:
        return 1.0

    full_charge_mult = weapon.get("full_charge_mult", 100.0) / 100.0
    charge_dmg_pct = buffs.get("charge_dmg_pct", 0.0) / 100.0
    charge_dmg_mag_pct = buffs.get("charge_dmg_mag_pct", 0.0) / 100.0

    return full_charge_mult * (1.0 + charge_dmg_mag_pct) + charge_dmg_pct


def _factor5(buffs: dict, hit_type: dict) -> float:
    """
    ⑤ 유형별 버프.
    100% + 공격대미지▲ [+ 대미지 유형별 버프 선택 합산]
    분배 대미지(split_dmg)는 ⑥에 합산 — 여기서는 제외.
    """
    val = 1.0 + buffs.get("atk_dmg_pct", 0.0) / 100.0

    if hit_type.get("is_burst_damage"):
        val += buffs.get("burst_dmg_pct", 0.0) / 100.0
        # 대상이 '적 전체'인 버스트 대미지에만 추가 가산 (트리나 뻗은 뿌리).
        # 같은 clause의 bonus_damage·dot_damage는 대상 아님 → is_burst_damage 안에 둔다.
        if hit_type.get("is_aoe_burst"):
            val += buffs.get("burst_dmg_aoe_pct", 0.0) / 100.0
        # 대상 설명이 '~ 적 1기에게'인 버스트 대미지에만 추가 가산 (자칼 크레이지 자칼).
        # 위 AoE판과 **배타** — 같은 히트가 둘 다 받지 않는다.
        if hit_type.get("is_single_burst"):
            val += buffs.get("burst_dmg_single_pct", 0.0) / 100.0
    if hit_type.get("is_pierce_damage"):
        val += buffs.get("pierce_dmg_pct", 0.0) / 100.0
    if hit_type.get("is_armor_break_damage"):
        val += buffs.get("armor_break_dmg_pct", 0.0) / 100.0
    if hit_type.get("is_dot"):
        val += buffs.get("dot_dmg_pct", 0.0) / 100.0
    if hit_type.get("is_projectile_explosion"):
        val += buffs.get("projectile_explosion_dmg", 0.0) / 100.0
    if hit_type.get("is_projectile_attachment"):
        val += buffs.get("projectile_attachment_dmg", 0.0) / 100.0
    if hit_type.get("is_sequential"):
        val += buffs.get("sequential_dmg_pct", 0.0) / 100.0

    # 파츠 대미지 — hit_type["is_part"]로 제어
    if hit_type.get("is_part"):
        val += buffs.get("part_dmg_pct", 0.0) / 100.0
    if hit_type.get("is_intercept"):
        val += buffs.get("intercept_dmg_pct", 0.0) / 100.0

    return val


def _factor6(buffs: dict, hit_type: dict) -> float:
    """
    ⑥ 적 받는 대미지.
    100% + received_dmg▲ [+ split_dmg▲]
    분배 대미지(split_dmg)는 received_dmg와 함께 ⑥에서 합산.
    """
    val = 1.0 + buffs.get("received_dmg", 0.0) / 100.0

    if hit_type.get("is_split"):
        val += buffs.get("split_dmg_pct", 0.0) / 100.0

    return val


def _factor7(buffs: dict) -> float:
    """⑦ 우월 코드. 100% [+ 10% + element_bonus%▲]"""
    if not buffs.get("is_element_match", False):
        return 1.0
    return 1.0 + 0.1 + buffs.get("element_bonus_pct", 0.0) / 100.0


# ── 메인 함수 ─────────────────────────────────────────────────────────────

def calc_damage(
    base_atk: float,
    buffs: dict,
    weapon: dict,
    hit_type: dict | None = None,
    enemy_def: float = DEFAULT_ENEMY_DEF,
    expected: bool = False,
) -> dict:
    """
    단일 히트 대미지 계산.

    Parameters
    ----------
    base_atk  : calc_base_stats()["atk"]
    buffs     : buff_manager.get_buffs() 결과
    weapon    : parsed_nikke.json의 캐릭터 항목
    hit_type  : default_hit_type(**overrides) 로 생성. None이면 기본값 사용.
    enemy_def : 적 방어력 (기본 31784)
    expected  : True면 난수 판정 대신 기대값으로 태운다.
                크리는 확률로 가중되고(is_crit은 항상 False, crit_frac에 확률이 담긴다),
                코어는 hit_type["core_prob"]가 있으면 그 확률로 가중된다.

    Returns
    -------
    {"damage": int, "is_crit": bool, "crit_frac": float}
    """
    if hit_type is None:
        hit_type = default_hit_type()

    f1 = _factor1(weapon, buffs, hit_type)
    f2 = _factor2(base_atk, enemy_def, buffs, hit_type)
    f3, is_crit, crit_frac = _factor3(weapon, buffs, hit_type, expected)
    f4 = _factor4(weapon, buffs, hit_type)
    f5 = _factor5(buffs, hit_type)
    f6 = _factor6(buffs, hit_type)
    f7 = _factor7(buffs)

    # ① × ② × ③ × ④ × ⑤ × ⑥ × ⑦
    # ①의 계수는 %이므로 /100
    damage = (f1 / 100.0) * f2 * f3 * f4 * f5 * f6 * f7

    if hit_type.get("_debug_factors"):
        print(
            f"  ①계수={f1:.4f}%  ②공방차={f2:,.1f}"
            f"  ③보너스={f3:.4f}(크리={f'기대 {crit_frac:.3f}' if expected else is_crit})"
            f"  ④차지={f4:.4f}  ⑤유형={f5:.4f}  ⑥받는={f6:.4f}  ⑦코드={f7:.4f}"
            f"  → {max(round(damage), 1):,}"
        )

    # 공격력 < 방어력이면 f2=0 → 최소 1 보장
    return {"damage": max(round(damage), 1), "is_crit": is_crit, "crit_frac": crit_frac}


def calc_damage_avg(
    base_atk: float,
    buffs: dict,
    weapon: dict,
    hit_type: dict | None = None,
    enemy_def: float = DEFAULT_ENEMY_DEF,
) -> float:
    """
    크리티컬 확률을 기댓값으로 처리한 평균 대미지.
    시뮬레이션 없이 기댓값을 빠르게 검산할 때 사용.
    (시뮬 전체를 기대값으로 돌리려면 `simulate(config={"rng_mode": "expected"})`)
    """
    if hit_type is None:
        hit_type = default_hit_type()

    f1 = _factor1(weapon, buffs, hit_type)
    f2 = _factor2(base_atk, enemy_def, buffs, hit_type)
    f3, _, _ = _factor3(weapon, buffs, hit_type, expected=True)
    f4 = _factor4(weapon, buffs, hit_type)
    f5 = _factor5(buffs, hit_type)
    f6 = _factor6(buffs, hit_type)
    f7 = _factor7(buffs)

    return max((f1 / 100.0) * f2 * f3 * f4 * f5 * f6 * f7, 1.0)


# ── 단위 테스트 ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")

    # 버프 없는 기본 상태 (buff_manager._BUFFS_ZERO 모방)
    zero_buffs = {
        "atk_pct": 0.0, "atk_flat": 0.0, "def_ignore_pct": 0.0,
        "crit_rate": 0.15, "crit_dmg": 0.0, "core_dmg_pct": 0.0,
        "atk_dmg_pct": 0.0, "burst_dmg_pct": 0.0, "pierce_dmg_pct": 0.0,
        "dot_dmg_pct": 0.0, "armor_break_dmg_pct": 0.0,
        "projectile_explosion_dmg": 0.0, "projectile_attachment_dmg": 0.0,
        "sequential_dmg_pct": 0.0,
        "charge_dmg_pct": 0.0, "charge_dmg_mag_pct": 0.0,
        "received_dmg": 0.0, "split_dmg_pct": 0.0,
        "element_bonus_pct": 0.0, "is_element_match": False,
        "def_pct": 0.0, "charge_speed_pct": 0.0, "max_ammo_pct": 0.0,
        "accuracy_pct": 0.0, "normal_atk_dmg_pct": 0.0, "reload_speed_pct": 0.0,
        "part_dmg_pct": 0.0, "burst_dmg_aoe_pct": 0.0,
    }

    # 라피 AR 기본 스펙 (parsed_nikke.json 값 대신 임시값)
    weapon_ar = {
        "weapon_type": "AR",
        "damage_coeff": 13.65,
        "core_dmg_mult": 200.0,
    }

    base_atk = 50000  # 임의 공격력

    # ── 검산 1: 버프 없음, 크리 없음 (avg으로 검산)
    avg = calc_damage_avg(base_atk, zero_buffs, weapon_ar, enemy_def=DEFAULT_ENEMY_DEF)
    # 수작업: (13.65/100) × (50000 - 31784) × (1 + 0.15×0.5) = 0.1365 × 18216 × 1.075
    expected = (13.65 / 100) * (50000 - 31784) * (1 + 0.15 * 0.5)
    print(f"검산 1 — 평균 대미지: {avg:.2f}  (수작업: {expected:.2f})")
    assert abs(avg - expected) < 1.0, f"불일치: {avg} vs {expected}"

    # ── 검산 2: atk_pct +100%, 크리 없음
    buffs2 = dict(zero_buffs)
    buffs2["atk_pct"] = 100.0
    avg2 = calc_damage_avg(base_atk, buffs2, weapon_ar, enemy_def=DEFAULT_ENEMY_DEF)
    expected2 = (13.65 / 100) * (50000 * 2.0 - 31784) * (1 + 0.15 * 0.5)
    print(f"검산 2 — atk +100%: {avg2:.2f}  (수작업: {expected2:.2f})")
    assert abs(avg2 - expected2) < 1.0, f"불일치: {avg2} vs {expected2}"

    # ── 검산 3: 코어 히트 (일반 공격), 크리 없음
    buffs3 = dict(zero_buffs)
    buffs3["crit_rate"] = 0.0
    ht3 = default_hit_type(is_core=True)
    avg3 = calc_damage_avg(base_atk, buffs3, weapon_ar, hit_type=ht3, enemy_def=DEFAULT_ENEMY_DEF)
    # f3 = 1.0 + 1.0(core 200% → +100% 추가분) + 0(crit) = 2.0
    expected3 = (13.65 / 100) * (50000 - 31784) * 2.0
    print(f"검산 3 — 코어 히트 (crit_rate=0): {avg3:.2f}  (수작업: {expected3:.2f})")
    assert abs(avg3 - expected3) < 1.0, f"불일치: {avg3} vs {expected3}"

    # ── 검산 4: SR 풀 차지, full_charge_mult=250%
    weapon_sr = {"weapon_type": "SR", "damage_coeff": 50.0,
                 "core_dmg_mult": 200.0, "full_charge_mult": 250.0}
    buffs4 = dict(zero_buffs)
    buffs4["crit_rate"] = 0.0
    ht4 = default_hit_type(is_full_charge=True)
    avg4 = calc_damage_avg(base_atk, buffs4, weapon_sr, hit_type=ht4, enemy_def=DEFAULT_ENEMY_DEF)
    # f1=50, f2=(50000-31784), f3=1.0, f4=2.5, f5=1.0, f6=1.0, f7=1.0
    expected4 = (50.0 / 100) * (50000 - 31784) * 1.0 * 2.5
    print(f"검산 4 — SR 풀 차지: {avg4:.2f}  (수작업: {expected4:.2f})")
    assert abs(avg4 - expected4) < 1.0, f"불일치: {avg4} vs {expected4}"

    # ── 검산 4-B: 차지 대미지 배율 층 — 헬름 인게임 표기 재현 (2026-08-28 유저 확인)
    # 기본 250% · 오버로드 평문 11.11% · 소장품 SR15 배율 9.47% · 버스트 배율 158.4%
    for mag, 인게임 in ((9.47, 284.785), (9.47 + 158.4, 680.785)):
        b4b = dict(zero_buffs)
        b4b["charge_dmg_pct"] = 11.11
        b4b["charge_dmg_mag_pct"] = mag
        f4b = _factor4(weapon_sr, b4b, ht4) * 100
        print(f"검산 4-B — 차지 배율(배율 {mag}%): {f4b:.2f}%  (인게임: {round(인게임)}%)")
        assert abs(f4b - 인게임) < 0.01, f"불일치: {f4b} vs {인게임}"

    # ── 검산 5: 풀버스트 + 우월코드
    buffs5 = dict(zero_buffs)
    buffs5["crit_rate"] = 0.0
    buffs5["is_element_match"] = True
    buffs5["element_bonus_pct"] = 10.0
    ht5 = default_hit_type(is_full_burst=True)
    avg5 = calc_damage_avg(base_atk, buffs5, weapon_ar, hit_type=ht5, enemy_def=DEFAULT_ENEMY_DEF)
    # f3=1.5, f7=1.2(10%+10%)
    expected5 = (13.65 / 100) * (50000 - 31784) * 1.5 * 1.0 * 1.0 * 1.2
    print(f"검산 5 — 풀버스트 + 우월코드: {avg5:.2f}  (수작업: {expected5:.2f})")
    assert abs(avg5 - expected5) < 1.0, f"불일치: {avg5} vs {expected5}"

    # ── 검산 6: core_damage 스킬 (is_normal_atk=False인데도 코어 배율이 실려야 함)
    buffs6 = dict(zero_buffs)
    buffs6["crit_rate"] = 0.0
    buffs6["core_dmg_pct"] = 26.0
    ht6 = default_hit_type(is_normal_atk=False, is_core=True, is_core_damage=True, coeff=833.79)
    avg6 = calc_damage_avg(base_atk, buffs6, weapon_ar, hit_type=ht6, enemy_def=DEFAULT_ENEMY_DEF)
    # f3 = 1.0 + (200-100)/100 + 26/100 = 2.26
    expected6 = (833.79 / 100) * (50000 - 31784) * 2.26
    print(f"검산 6 — core_damage 스킬: {avg6:.2f}  (수작업: {expected6:.2f})")
    assert abs(avg6 - expected6) < 1.0, f"불일치: {avg6} vs {expected6}"

    # 같은 히트에서 is_core_damage를 빼면 코어 배율이 빠져야 한다 (스킬은 기본적으로 코어 미적용)
    ht6b = default_hit_type(is_normal_atk=False, is_core=True, coeff=833.79)
    avg6b = calc_damage_avg(base_atk, buffs6, weapon_ar, hit_type=ht6b, enemy_def=DEFAULT_ENEMY_DEF)
    expected6b = (833.79 / 100) * (50000 - 31784) * 1.0
    assert abs(avg6b - expected6b) < 1.0, f"불일치: {avg6b} vs {expected6b}"

    # ── 검산 7: part_dmg_pct는 is_part 히트에만 ⑤로 가산
    buffs7 = dict(zero_buffs)
    buffs7["crit_rate"] = 0.0
    buffs7["part_dmg_pct"] = 26.21
    ht7 = default_hit_type(is_normal_atk=False, is_part=True, coeff=1189.66)
    avg7 = calc_damage_avg(base_atk, buffs7, weapon_ar, hit_type=ht7, enemy_def=DEFAULT_ENEMY_DEF)
    expected7 = (1189.66 / 100) * (50000 - 31784) * (1.0 + 26.21 / 100)
    print(f"검산 7 — part_dmg_pct (is_part): {avg7:.2f}  (수작업: {expected7:.2f})")
    assert abs(avg7 - expected7) < 1.0, f"불일치: {avg7} vs {expected7}"

    ht7b = default_hit_type(is_normal_atk=False, coeff=1189.66)
    avg7b = calc_damage_avg(base_atk, buffs7, weapon_ar, hit_type=ht7b, enemy_def=DEFAULT_ENEMY_DEF)
    expected7b = (1189.66 / 100) * (50000 - 31784)
    assert abs(avg7b - expected7b) < 1.0, f"불일치: {avg7b} vs {expected7b}"

    # ── 검산 8: burst_dmg_aoe_pct — '적 전체' 버스트에만 가산 (트리나 뻗은 뿌리)
    buffs8 = dict(zero_buffs)
    buffs8["crit_rate"] = 0.0
    buffs8["burst_dmg_pct"] = 50.0
    buffs8["burst_dmg_aoe_pct"] = 435.6
    ht8_aoe = default_hit_type(is_normal_atk=False, is_burst_damage=True, is_aoe_burst=True)
    ht8_st = default_hit_type(is_normal_atk=False, is_burst_damage=True)          # 단일 대상 버스트
    ht8_bonus = default_hit_type(is_normal_atk=False, is_aoe_burst=True)          # bonus_damage 취급
    a8 = calc_damage_avg(base_atk, buffs8, weapon_ar, hit_type=ht8_aoe, enemy_def=DEFAULT_ENEMY_DEF)
    b8 = calc_damage_avg(base_atk, buffs8, weapon_ar, hit_type=ht8_st, enemy_def=DEFAULT_ENEMY_DEF)
    c8 = calc_damage_avg(base_atk, buffs8, weapon_ar, hit_type=ht8_bonus, enemy_def=DEFAULT_ENEMY_DEF)
    base8 = (13.65 / 100) * (50000 - 31784)
    print(f"검산 8 — AoE 버스트: {a8:.2f} (수작업 {base8 * (1 + 0.5 + 4.356):.2f}) / "
          f"단일 버스트: {b8:.2f} (수작업 {base8 * 1.5:.2f}) / bonus: {c8:.2f} (수작업 {base8:.2f})")
    assert abs(a8 - base8 * (1 + 0.5 + 4.356)) < 1.0, f"불일치: {a8}"
    assert abs(b8 - base8 * 1.5) < 1.0, f"불일치: {b8}"          # aoe 미적용
    assert abs(c8 - base8) < 1.0, f"불일치: {c8}"                # is_burst_damage 아니면 둘 다 미적용

    # ── 검산 9: burst_dmg_single_pct — '~ 적 1기' 버스트에만 가산 (자칼 크레이지 자칼).
    #    AoE판과 배타다 — 한 히트가 둘 다 받지 않는다.
    buffs9 = dict(zero_buffs)
    buffs9["crit_rate"] = 0.0
    buffs9["burst_dmg_pct"] = 50.0
    buffs9["burst_dmg_aoe_pct"] = 435.6
    buffs9["burst_dmg_single_pct"] = 38.91
    ht9_st = default_hit_type(is_normal_atk=False, is_burst_damage=True, is_single_burst=True)
    ht9_aoe = default_hit_type(is_normal_atk=False, is_burst_damage=True, is_aoe_burst=True)
    ht9_bonus = default_hit_type(is_normal_atk=False, is_single_burst=True)       # bonus_damage 취급
    a9 = calc_damage_avg(base_atk, buffs9, weapon_ar, hit_type=ht9_st, enemy_def=DEFAULT_ENEMY_DEF)
    b9 = calc_damage_avg(base_atk, buffs9, weapon_ar, hit_type=ht9_aoe, enemy_def=DEFAULT_ENEMY_DEF)
    c9 = calc_damage_avg(base_atk, buffs9, weapon_ar, hit_type=ht9_bonus, enemy_def=DEFAULT_ENEMY_DEF)
    print(f"검산 9 — 단일 버스트: {a9:.2f} (수작업 {base8 * (1 + 0.5 + 0.3891):.2f}) / "
          f"AoE 버스트: {b9:.2f} (수작업 {base8 * (1 + 0.5 + 4.356):.2f}) / bonus: {c9:.2f}")
    assert abs(a9 - base8 * (1 + 0.5 + 0.3891)) < 1.0, f"불일치: {a9}"   # aoe 미적용
    assert abs(b9 - base8 * (1 + 0.5 + 4.356)) < 1.0, f"불일치: {b9}"    # single 미적용
    assert abs(c9 - base8) < 1.0, f"불일치: {c9}"                        # is_burst_damage 아니면 미적용

    print("\n모든 검산 통과.")
